-- phpMyAdmin SQL Dump
-- version 2.9.1.1
-- http://www.phpmyadmin.net
-- 
-- 主机: localhost
-- 生成日期: 2008 年 12 月 12 日 09:52
-- 服务器版本: 5.0.27
-- PHP 版本: 5.2.0
-- 
-- 数据库: `phpdtb`
-- 

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_adminuser`
-- 

CREATE TABLE `phpdtb_adminuser` (
  `admin_id` tinyint(3) unsigned NOT NULL auto_increment,
  `user_name` varchar(24) NOT NULL,
  `user_pass` varchar(32) NOT NULL,
  `user_comp` text NOT NULL,
  `user_lastip` varchar(32) NOT NULL,
  `user_lasttime` int(10) unsigned NOT NULL,
  `user_logincount` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- 导出表中的数据 `phpdtb_adminuser`
-- 

INSERT INTO `phpdtb_adminuser` (`admin_id`, `user_name`, `user_pass`, `user_comp`, `user_lastip`, `user_lasttime`, `user_logincount`) VALUES 
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'all', '127.0.0.1', 1229073806, 10);

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_cart`
-- 

CREATE TABLE `phpdtb_cart` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `goods_id` int(10) unsigned NOT NULL,
  `sessid` varchar(255) NOT NULL,
  `count` int(10) unsigned NOT NULL,
  `price` decimal(8,2) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL default '0',
  `enprice` decimal(8,2) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `goods_id` (`goods_id`),
  KEY `sessid` (`sessid`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- 导出表中的数据 `phpdtb_cart`
-- 


-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_categroy`
-- 

CREATE TABLE `phpdtb_categroy` (
  `cid` int(10) unsigned NOT NULL auto_increment,
  `cnname` varchar(255) NOT NULL,
  `enname` varchar(255) NOT NULL,
  `cndes` text NOT NULL,
  `endes` text NOT NULL,
  `ispass` tinyint(3) unsigned NOT NULL default '0',
  `order` int(10) unsigned NOT NULL default '0',
  `categoryid` int(10) unsigned NOT NULL default '0',
  `class_img` varchar(200) NOT NULL,
  `is_hot` tinyint(3) unsigned NOT NULL default '0',
  `cnkeywords` varchar(80) NOT NULL,
  `enkeywords` varchar(80) NOT NULL,
  `cndescription` varchar(200) NOT NULL,
  `endescription` varchar(200) NOT NULL,
  PRIMARY KEY  (`cid`),
  KEY `ispass` (`ispass`,`order`),
  KEY `categoryid` (`categoryid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

-- 
-- 导出表中的数据 `phpdtb_categroy`
-- 

INSERT INTO `phpdtb_categroy` (`cid`, `cnname`, `enname`, `cndes`, `endes`, `ispass`, `order`, `categoryid`, `class_img`, `is_hot`, `cnkeywords`, `enkeywords`, `cndescription`, `endescription`) VALUES 
(1, '直升飞机', 'Helicopters', 'Helicopters', '直升飞机', 1, 3, 0, 'upload/class_img/1220714547786307741.gif', 1, '直升飞机', '直升飞机', '直升飞机', '直升飞机'),
(2, '飞机一', 'A plane', 'A plane', 'A plane', 1, 3, 1, 'upload/class_img/1220714547786307741.gif', 1, 'A plane', 'A plane', 'A plane', 'A plane'),
(5, '电脑', 'Computer', '电脑', 'Computer', 1, 2, 0, 'upload/class_img/1220714547786307741.gif', 1, '', '', '', ''),
(3, '文具百货', 'Stationery Stores', 'Stationery Stores', '文具百货', 1, 3, 0, 'upload/class_img/1229067223245534980.jpg', 1, '文具百货', '文具百货', '文具百货', '文具百货'),
(4, '分类4', 'class four', '', '', 1, 4, 0, 'upload/class_img/1220714547786307741.gif', 1, '', '', '', ''),
(6, 'DELL', 'DELL', 'DELL', 'DELL', 1, 2, 5, 'upload/class_img/1220714547786307741.gif', 1, '', '', '', ''),
(7, 'test', 'test', 'test', 'test', 1, 3, 3, 'upload/class_img/1220714547786307741.gif', 1, '', '', '', ''),
(8, 'test2', 'test2', 'test', 'test', 1, 3, 3, 'upload/class_img/1220714547786307741.gif', 1, '', '', '', ''),
(9, 'test3', 'test3', 'test', 'test', 1, 3, 3, 'upload/class_img/1220714547786307741.gif', 1, '', '', '', ''),
(10, 'test4', 'test4', 'test', 'test', 1, 3, 3, 'upload/class_img/1220714547786307741.gif', 1, '', '', '', ''),
(11, '联想', 'Lenovo', 'Lenovo', 'Lenovo', 1, 1, 5, 'upload/class_img/1229066673446543571.jpg', 1, '', '', '', ''),
(12, '神舟', 'Hasee', 'Hasee', '神舟', 0, 0, 5, '', 0, '', '', '', ''),
(13, '神舟', 'Hasee', '神舟', '神舟', 1, 1, 5, 'upload/class_img/1229066592451855436.jpg', 1, '', '', '', '');

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_color`
-- 

CREATE TABLE `phpdtb_color` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cnname` varchar(100) NOT NULL,
  `enname` varchar(100) NOT NULL,
  `cndes` text NOT NULL,
  `endes` text NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `ispass` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- 导出表中的数据 `phpdtb_color`
-- 

INSERT INTO `phpdtb_color` (`id`, `cnname`, `enname`, `cndes`, `endes`, `order`, `ispass`) VALUES 
(1, '黄色', 'orgeage', 'fdsafdsa', 'fdsafdsafdsa', 3, 1),
(2, '红色', 'red', 'sdafd', 'safdsafdsa', 1, 1),
(3, '蓝色', 'blue', 'fdsafdsa', 'fdsafdsafa', 2, 1);

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_freeback`
-- 

CREATE TABLE `phpdtb_freeback` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default 'Guest',
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `recontent` text NOT NULL,
  `tel` varchar(20) NOT NULL,
  `postcode` varchar(15) NOT NULL,
  `moblie` varchar(20) NOT NULL,
  `msn` varchar(100) NOT NULL,
  `skype` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `referer` varchar(255) NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='留言表' AUTO_INCREMENT=6 ;

-- 
-- 导出表中的数据 `phpdtb_freeback`
-- 

INSERT INTO `phpdtb_freeback` (`id`, `name`, `title`, `content`, `recontent`, `tel`, `postcode`, `moblie`, `msn`, `skype`, `email`, `address`, `referer`, `addtime`) VALUES 
(1, 'Guest', '谢谢你们提供了这么多的商品！', '谢谢你们提供了这么多的商品！这个网站真漂亮!', 'fdsafdsa', '0467-98383983', '9832423', '13999999999999', 'xuwu125@hotmail.com', 'xuwu125', 'xuwu125@gmail.com', '浙江义乌前成小区', '', 0),
(2, 'Guest', '谢谢你们提供了这么多的商品！', '谢谢你们提供了这么多的商品！这个网站真漂亮!', '', '0467-98383983', '9832423', '13999999999999', 'xuwu125@hotmail.com', 'xuwu125', 'xuwu125@gmail.com', '浙江义乌前成小区', '', 0),
(3, 'Guest', '谢谢你们提供了这么多的商品！', '谢谢你们提供了这么多的商品！这个网站真漂亮!', '谢谢！', '0467-98383983', '9832423', '13999999999999', 'xuwu125@hotmail.com', 'xuwu125', 'xuwu125@gmail.com', '浙江义乌前成小区', '', 0),
(4, 'dsf', 'sdaf', 'dsafdsa', '', 'afdsa', 'fds', 'fd', 'saf', 'dsafds', 'afdsa', 'fdsafdsa', 'http://127.0.0.1/newwell/index.php?act=freeback&lang=zh::cn', 1220897006),
(5, '姓名', '标题', '内容', 'fdsafd', '电话', '邮编', '手机', 'MSN', 'Skype', '电子邮件', '地址', 'http://127.0.0.1/newwell/index.php?act=freeback&lang=zh::cn', 1220897118);

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_goods`
-- 

CREATE TABLE `phpdtb_goods` (
  `goods_id` int(10) unsigned NOT NULL auto_increment,
  `goods_cnanme` varchar(255) NOT NULL,
  `goods_enname` varchar(255) NOT NULL,
  `goods_sn` varchar(255) NOT NULL,
  `goods_cate_id` int(10) unsigned NOT NULL default '0',
  `goods_encontent` text NOT NULL,
  `goods_cncontent` text NOT NULL,
  `order` int(10) unsigned NOT NULL default '0',
  `ispass` tinyint(3) unsigned NOT NULL default '0',
  `addtime` int(10) unsigned NOT NULL default '0',
  `goods_number` int(10) unsigned NOT NULL default '0',
  `mini_order` int(10) unsigned NOT NULL default '0',
  `color` varchar(100) NOT NULL,
  `meta` varchar(100) NOT NULL,
  `price` int(10) unsigned NOT NULL default '0',
  `bigimage` varchar(255) NOT NULL,
  `smallimage` varchar(255) NOT NULL,
  `goods_keywords` varchar(80) NOT NULL,
  `goods_des` varchar(200) NOT NULL,
  `goods_enkeywords` varchar(80) NOT NULL,
  `goods_endes` varchar(200) NOT NULL,
  `goods_price` decimal(8,2) unsigned NOT NULL default '0.00',
  `is_hot` tinyint(1) unsigned NOT NULL default '0',
  `goods_oldprice` decimal(8,2) unsigned NOT NULL,
  `order_count` int(10) unsigned NOT NULL default '0',
  `related_goods` varchar(255) NOT NULL,
  `goods_click` int(10) unsigned NOT NULL,
  `goods_length` varchar(255) NOT NULL COMMENT '长度',
  `goods_weight` varchar(255) NOT NULL COMMENT '重量',
  `goods_height` varchar(255) NOT NULL COMMENT '宽度',
  `goods_pack` varchar(255) NOT NULL COMMENT '包装',
  `goods_enpack` varchar(255) NOT NULL,
  `goods_ennumber` int(10) unsigned NOT NULL,
  `goods_enprice` decimal(5,2) unsigned NOT NULL,
  `mini_enorder` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`goods_id`),
  KEY `goods_cate_id` (`goods_cate_id`),
  KEY `goods_cnanme` (`goods_cnanme`),
  KEY `goods_enname` (`goods_enname`),
  KEY `order` (`order`),
  KEY `ipass` (`ispass`),
  KEY `color` (`color`,`meta`,`price`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

-- 
-- 导出表中的数据 `phpdtb_goods`
-- 

INSERT INTO `phpdtb_goods` (`goods_id`, `goods_cnanme`, `goods_enname`, `goods_sn`, `goods_cate_id`, `goods_encontent`, `goods_cncontent`, `order`, `ispass`, `addtime`, `goods_number`, `mini_order`, `color`, `meta`, `price`, `bigimage`, `smallimage`, `goods_keywords`, `goods_des`, `goods_enkeywords`, `goods_endes`, `goods_price`, `is_hot`, `goods_oldprice`, `order_count`, `related_goods`, `goods_click`, `goods_length`, `goods_weight`, `goods_height`, `goods_pack`, `goods_enpack`, `goods_ennumber`, `goods_enprice`, `mini_enorder`) VALUES 
(1, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 1, '2,3,1', '1', 1, 'upload/goods/big/1224226405422756732.jpg', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', 'goods', 'goods des', 1.00, 1, 0.00, 0, '29,30,31,32,33,34', 56, '15MM', '1.5KG', '23CM', '大', 'enpacker', 1, 0.10, 1),
(3, 'goods_cnanme', 'goods_enname', 'goods_sn', 3, '<p>goods_encontent</p>', '<p>goods_cncontent</p>', 0, 1, 0, 10, 0, '2', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'keywords', 'des', '', '', 1.20, 1, 1.00, 0, '', 13, '', '', '', '', '', 0, 0.00, 0),
(4, 'fdsafdsa', 'fdsafdsa', 'dsafdsa', 1, '<p>fdsafdsa</p>', '<p>fdsafdsa</p>', 0, 1, 0, 100, 0, '2', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsafds', 'fdsafdsa', '', '', 5.00, 1, 1.00, 0, '', 0, '', '', '', '', '', 0, 0.00, 0),
(5, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '2,3,1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 0, '', '', '', '', '', 0, 0.00, 0),
(6, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 0, '', '', '', '', '', 0, 0.00, 0),
(7, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 1, '', '', '', '', '', 0, 0.00, 0),
(9, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 0, '', '', '', '', '', 0, 0.00, 0),
(10, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 0, '', '', '', '', '', 0, 0.00, 0),
(11, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 1, '', '', '', '', '', 0, 0.00, 0),
(12, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 1, '', '', '', '', '', 0, 0.00, 0),
(13, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 0, '', '', '', '', '', 0, 0.00, 0),
(14, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 1, '', '', '', '', '', 0, 0.00, 0),
(15, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 0, '', '', '', '', '', 0, 0.00, 0),
(16, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 0, '', '', '', '', '', 0, 0.00, 0),
(17, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 0, '', '', '', '', '', 0, 0.00, 0),
(18, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 1, '', '', '', '', '', 0, 0.00, 0),
(19, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 3, '', '', '', '', '', 0, 0.00, 0),
(20, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 1, '', '', '', '', '', 0, 0.00, 0),
(21, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 1, '', 1, '', '', '', '', '', 0, 0.00, 0),
(22, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 11, '', '', '', '', '', 0, 0.00, 0),
(23, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 5, '', '', '', '', '', 0, 0.00, 0),
(24, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 0, '', 5, '', '', '', '', '', 0, 0.00, 0),
(25, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 1, 0.00, 1, '', 9, '', '', '', '', '', 0, 0.00, 0),
(26, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 0, 0.00, 0, '', 0, '', '', '', '', '', 0, 0.00, 0),
(27, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 0, 0.00, 0, '', 3, '', '', '', '', '', 0, 0.00, 0),
(28, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 0, 0.00, 0, '', 1, '', '', '', '', '', 0, 0.00, 0),
(29, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 0, 0.00, 0, '', 6, '', '', '', '', '', 0, 0.00, 0),
(30, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 0, 0.00, 0, '', 1, '', '', '', '', '', 0, 0.00, 0),
(31, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 0, 0.00, 1, '', 5, '', '', '', '', '', 0, 0.00, 0),
(32, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 0, 0.00, 0, '', 2, '', '', '', '', '', 0, 0.00, 0),
(33, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 0, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', '', '', 1.00, 0, 0.00, 1, '', 20, '', '', '', '', '', 0, 0.00, 0),
(34, 'afdsa', 'fdsafds', 'fdsafdsafdsa', 2, '<p>fdsafdsafdsafdsa</p>', '<p>fdasfdsafdsafdsafdssafdsa</p>', 0, 1, 0, 10, 1, '1', '1', 1, 'upload/goods/big/1220712966442636456.gif', 'upload/goods/small/1220712966669581503.gif', 'fdsaafdsafdsa', 'fdsafdsa', 'KEYKEY', 'ksksks', 1.00, 0, 0.20, 6, '', 41, '100CM', '200KG', '20CM', '包装', 'pack', 1, 0.50, 1);

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_goods_photo`
-- 

CREATE TABLE `phpdtb_goods_photo` (
  `photo_id` int(10) unsigned NOT NULL auto_increment,
  `goods_id` int(10) unsigned NOT NULL,
  `image_url` varchar(255) NOT NULL COMMENT '大图片地址',
  `image_samllurl` varchar(255) NOT NULL COMMENT '小图片地址',
  PRIMARY KEY  (`photo_id`),
  KEY `goods_id` (`goods_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

-- 
-- 导出表中的数据 `phpdtb_goods_photo`
-- 

INSERT INTO `phpdtb_goods_photo` (`photo_id`, `goods_id`, `image_url`, `image_samllurl`) VALUES 
(23, 1, 'upload/goods_photo/1225184675353936772.png', 'upload/goods_photo/1225184675353936772.png');

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_meta`
-- 

CREATE TABLE `phpdtb_meta` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cnname` varchar(100) NOT NULL,
  `enname` varchar(100) NOT NULL,
  `cndes` text NOT NULL,
  `endes` text NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `ispass` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- 导出表中的数据 `phpdtb_meta`
-- 

INSERT INTO `phpdtb_meta` (`id`, `cnname`, `enname`, `cndes`, `endes`, `order`, `ispass`) VALUES 
(1, '铁制', 'meta', 'safdsafds', 'afdsafdsafdsa', 1, 1);

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_nav`
-- 

CREATE TABLE `phpdtb_nav` (
  `cid` int(10) unsigned NOT NULL auto_increment,
  `cntitle` varchar(255) NOT NULL,
  `cncontent` text NOT NULL,
  `entitle` varchar(255) NOT NULL,
  `encontent` text NOT NULL,
  `en_url` varchar(255) NOT NULL,
  `cn_url` varchar(255) NOT NULL,
  `nav_name` varchar(255) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL default '0',
  `ispass` tinyint(3) unsigned NOT NULL default '0',
  `style` text NOT NULL,
  `order` int(10) unsigned NOT NULL default '0',
  `system` tinyint(3) unsigned NOT NULL default '0',
  `blank` varchar(20) NOT NULL COMMENT '是否新窗口打开',
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- 
-- 导出表中的数据 `phpdtb_nav`
-- 

INSERT INTO `phpdtb_nav` (`cid`, `cntitle`, `cncontent`, `entitle`, `encontent`, `en_url`, `cn_url`, `nav_name`, `type`, `ispass`, `style`, `order`, `system`, `blank`) VALUES 
(1, '首页', '<p>首页</p>', 'Home', '<p>home</p>', 'auto', 'auto', 'index', 2, 1, '', 1, 1, ''),
(2, '所有产品', '<p>fdsafdsa</p>', 'Product', '<p>dafdsa</p>', 'auto', 'auto', 'product', 1, 1, ' ', 2, 1, ''),
(4, '关于我们', '<p>\r\n<table width="601">\r\n    <tbody>\r\n        <tr>\r\n            <td width="567"><span class="STYLE1"><strong><font color="#333333">About Well Done Fashion Jewelry</font></strong></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">Customers constantly refreshes their jewelry departments with new products. And we make</font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">sure they have plenty ofoptions, offering 1,500 new necklaces, bracelets and other jewelry</font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">designs every season.</font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td height="21">&nbsp;</td>\r\n        </tr>\r\n        <tr>\r\n            <td class="STYLE2">Experienced Designers</td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">Our 10 designers all have at least five years of experience. Led by a designer from Europe, </font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">our product development team will keep you up to date with the latest trends. If you have a</font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">custom product in mind, we will create your sample in just seven days. </font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td height="21">&nbsp;</td>\r\n        </tr>\r\n        <tr>\r\n            <td class="STYLE2">1.2 Million Pieces Monthly</td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">Our monthly capacity of 1.2 million pieces will keep your shelves stocked too. If you don''t</font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">have so much shelf space, we''ll gladly accept your orders for just 240 pieces. E-mail us </font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">today.</font></span></td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n</p>', 'About us', '<p>\r\n<table width="601">\r\n    <tbody>\r\n        <tr>\r\n            <td width="567"><span class="STYLE1"><strong><font color="#333333">About Well Done Fashion Jewelry</font></strong></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">Customers constantly refreshes their jewelry departments with new products. And we make</font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">sure they have plenty ofoptions, offering 1,500 new necklaces, bracelets and other jewelry</font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">designs every season.</font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td height="21">&nbsp;</td>\r\n        </tr>\r\n        <tr>\r\n            <td class="STYLE2">Experienced Designers</td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">Our 10 designers all have at least five years of experience. Led by a designer from Europe, </font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">our product development team will keep you up to date with the latest trends. If you have a</font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">custom product in mind, we will create your sample in just seven days. </font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td height="21">&nbsp;</td>\r\n        </tr>\r\n        <tr>\r\n            <td class="STYLE2">1.2 Million Pieces Monthly</td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">Our monthly capacity of 1.2 million pieces will keep your shelves stocked too. If you don''t</font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">have so much shelf space, we''ll gladly accept your orders for just 240 pieces. E-mail us </font></span></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span class="STYLE2"><font color="#333333">today.</font></span></td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n</p>', 'auto', 'auto', 'about_us', 2, 1, '', 7, 1, ''),
(5, '联系我们', '<p>Well Done Fashion Jewelry Co., Ltd. <br />\r\n&nbsp; Add: 4FL，1st of Building 67 Zongtang 2nd Village Yiwu Zhejiang China<br />\r\n&nbsp;<br />\r\n&nbsp; Tel: (86 579) 85633195 <br />\r\n&nbsp;<br />\r\n&nbsp; Fax: (86 579) 85201057<br />\r\n&nbsp;<br />\r\n&nbsp; Zip: 322000<br />\r\n&nbsp;<br />\r\n&nbsp; E-mail: <a href="mailto:welld@globalsources.com">welld@globalsources.com</a>&nbsp;&nbsp;&nbsp;&nbsp; <a href="mailto:zgj511@hotmail.com">zgj511@hotmail.com</a><br />\r\n&nbsp;<br />\r\n&nbsp; Contacter:&nbsp; Jimmy(Sales Manager)<br />\r\n&nbsp;<br />\r\n&nbsp; website: <a href="http://www.costume-jewel.com">Http://www.costume-jewel.com</a><br />\r\n&nbsp;</p>\r\n<p>&nbsp;</p>', 'Contact us', '<p>Well Done Fashion Jewelry Co., Ltd. <br />\r\n&nbsp; Add: 4FL，1st of Building 67 Zongtang 2nd Village Yiwu Zhejiang China<br />\r\n&nbsp;<br />\r\n&nbsp; Tel: (86 579) 85633195 <br />\r\n&nbsp;<br />\r\n&nbsp; Fax: (86 579) 85201057<br />\r\n&nbsp;<br />\r\n&nbsp; Zip: 322000<br />\r\n&nbsp;<br />\r\n&nbsp; E-mail: <a href="mailto:welld@globalsources.com">welld@globalsources.com</a>&nbsp;&nbsp;&nbsp;&nbsp; <a href="mailto:zgj511@hotmail.com">zgj511@hotmail.com</a><br />\r\n&nbsp;<br />\r\n&nbsp; Contacter:&nbsp; Jimmy(Sales Manager)<br />\r\n&nbsp;<br />\r\n&nbsp; website: <a href="http://www.costume-jewel.com">Http://www.costume-jewel.com</a><br />\r\n&nbsp;</p>\r\n<p>&nbsp;</p>', 'auto', 'auto', 'contact_us', 2, 1, ' ', 8, 1, ''),
(6, '在线留言', '<p>在线留言</p>', 'Feedback', '<p>freeback</p>', 'auto', 'auto', 'freeback', 1, 1, '', 4, 1, ''),
(7, '购物车', '<p>购物车</p>', 'My cart', '<p>购物车</p>', 'auto', 'auto', 'cart', 1, 1, '', 5, 1, ''),
(8, '推荐产品', '', 'Hot Product', '', 'auto', 'auto', 'hotproduct', 1, 1, '', 3, 1, ''),
(9, '博客', '', 'Blog', '', 'blog', 'blog', 'blog', 1, 1, '', 11, 0, '_blank'),
(10, '服务', '<p>\r\n<table width="90%" cellspacing="0" cellpadding="0" border="0" align="center">\r\n    <tbody>\r\n        <tr>\r\n            <td width="43%">\r\n            <table width="99%" cellpadding="0" border="0">\r\n                <tbody>\r\n                    <tr>\r\n                        <td>\r\n                        <div align="center">\r\n                        <table width="190" cellspacing="1" cellpadding="0" border="0">\r\n                            <tbody>\r\n                                <tr>\r\n                                    <td><img width="180" height="145" src="images/service_clip_image001.jpg" alt="" /></td>\r\n                                </tr>\r\n                            </tbody>\r\n                        </table>\r\n                        Our trade team</div>\r\n                        </td>\r\n                    </tr>\r\n                    <tr>\r\n                        <td>\r\n                        <div align="center">\r\n                        <table width="190" cellspacing="1" cellpadding="0" border="0">\r\n                            <tbody>\r\n                                <tr>\r\n                                    <td>\r\n                                    <p align="center"><img width="180" height="148" src="images/service_clip_image002.jpg" alt="" /></p>\r\n                                    </td>\r\n                                </tr>\r\n                            </tbody>\r\n                        </table>\r\n                        Ready to serve you</div>\r\n                        </td>\r\n                    </tr>\r\n                    <tr>\r\n                        <td>\r\n                        <div align="center">\r\n                        <table width="190" cellspacing="1" cellpadding="0" border="0">\r\n                            <tbody>\r\n                                <tr>\r\n                                    <td>\r\n                                    <p align="center"><img width="180" height="146" src="images/service_clip_image003.jpg" alt="" /></p>\r\n                                    </td>\r\n                                </tr>\r\n                            </tbody>\r\n                        </table>\r\n                        We will quickly reply to your inquiry</div>\r\n                        </td>\r\n                    </tr>\r\n                </tbody>\r\n            </table>\r\n            </td>\r\n            <td width="57%" valign="top">\r\n            <ul type="disc">\r\n                <li><strong>Sample Availability &amp; Policy</strong><br />\r\n                <br />\r\n                We offer samples of this product, with sample costs, shipping and taxes paid by the customer. To help us process your sample order, please include detailed information about your business, the reasons for your request and your preferred method of shipment.<br />\r\n                <br />\r\n                <br />\r\n                <br />\r\n                &nbsp;</li>\r\n                <li><strong>Guarantees/Warranties/Terms and Conditions</strong><br />\r\n                <br />\r\n                We guarantee high-quality products without any defects. Liability under this warranty is limited to the replacing of any product found to be defective under normal use.<br />\r\n                <br />\r\n                <br />\r\n                <br />\r\n                &nbsp;</li>\r\n                <li><strong>Export/Import Processing Support</strong><br />\r\n                <br />\r\n                Our company provides export/import services, including insurance, shipping, customs and export documents. <br />\r\n                <br />\r\n                <br />\r\n                <br />\r\n                &nbsp;</li>\r\n                <li><strong>After Sales Service</strong><br />\r\n                <br />\r\n                Our customer service personnel are experienced product specialists who can answer your questions six days a week from 9am to 5:30am (Beijing t</li>\r\n            </ul>\r\n            </td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n</p>', 'Service', '<p>\r\n<table width="90%" cellspacing="0" cellpadding="0" border="0" align="center">\r\n    <tbody>\r\n        <tr>\r\n            <td width="43%">\r\n            <table width="99%" cellpadding="0" border="0">\r\n                <tbody>\r\n                    <tr>\r\n                        <td>\r\n                        <div align="center">\r\n                        <table width="190" cellspacing="1" cellpadding="0" border="0">\r\n                            <tbody>\r\n                                <tr>\r\n                                    <td><img width="180" height="145" src="images/service_clip_image001.jpg" alt="" /></td>\r\n                                </tr>\r\n                            </tbody>\r\n                        </table>\r\n                        Our trade team</div>\r\n                        </td>\r\n                    </tr>\r\n                    <tr>\r\n                        <td>\r\n                        <div align="center">\r\n                        <table width="190" cellspacing="1" cellpadding="0" border="0">\r\n                            <tbody>\r\n                                <tr>\r\n                                    <td>\r\n                                    <p align="center"><img width="180" height="148" src="images/service_clip_image002.jpg" alt="" /></p>\r\n                                    </td>\r\n                                </tr>\r\n                            </tbody>\r\n                        </table>\r\n                        Ready to serve you</div>\r\n                        </td>\r\n                    </tr>\r\n                    <tr>\r\n                        <td>\r\n                        <div align="center">\r\n                        <table width="190" cellspacing="1" cellpadding="0" border="0">\r\n                            <tbody>\r\n                                <tr>\r\n                                    <td>\r\n                                    <p align="center"><img width="180" height="146" src="images/service_clip_image003.jpg" alt="" /></p>\r\n                                    </td>\r\n                                </tr>\r\n                            </tbody>\r\n                        </table>\r\n                        We will quickly reply to your inquiry</div>\r\n                        </td>\r\n                    </tr>\r\n                </tbody>\r\n            </table>\r\n            </td>\r\n            <td width="57%" valign="top">\r\n            <ul type="disc">\r\n                <li><strong>Sample Availability &amp; Policy</strong><br />\r\n                <br />\r\n                We offer samples of this product, with sample costs, shipping and taxes paid by the customer. To help us process your sample order, please include detailed information about your business, the reasons for your request and your preferred method of shipment.<br />\r\n                <br />\r\n                <br />\r\n                <br />\r\n                &nbsp;</li>\r\n                <li><strong>Guarantees/Warranties/Terms and Conditions</strong><br />\r\n                <br />\r\n                We guarantee high-quality products without any defects. Liability under this warranty is limited to the replacing of any product found to be defective under normal use.<br />\r\n                <br />\r\n                <br />\r\n                <br />\r\n                &nbsp;</li>\r\n                <li><strong>Export/Import Processing Support</strong><br />\r\n                <br />\r\n                Our company provides export/import services, including insurance, shipping, customs and export documents. <br />\r\n                <br />\r\n                <br />\r\n                <br />\r\n                &nbsp;</li>\r\n                <li><strong>After Sales Service</strong><br />\r\n                <br />\r\n                Our customer service personnel are experienced product specialists who can answer your questions six days a week from 9am to 5:30am (Beijing t</li>\r\n            </ul>\r\n            </td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n</p>', 'auto', 'auto', 'service', 2, 1, '', 8, 0, ''),
(11, '站点地图', '', 'Site-map', '', 'auto', 'auto', 'site_map', 2, 1, '', 10, 0, ''),
(12, '会员中心', '', 'User center', '', 'auto', 'auto', 'user', 1, 1, '', 6, 1, '');

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_order`
-- 

CREATE TABLE `phpdtb_order` (
  `order_id` int(10) unsigned NOT NULL auto_increment,
  `user_id` int(10) unsigned NOT NULL default '1',
  `order_sn` varchar(32) NOT NULL COMMENT '订单号',
  `money` decimal(8,2) unsigned NOT NULL default '0.00' COMMENT '商品金额',
  `addtime` int(10) unsigned NOT NULL default '0' COMMENT '订单时间',
  `order_stats` tinyint(3) unsigned NOT NULL default '0' COMMENT '订单状态',
  `pay_stats` tinyint(3) unsigned NOT NULL default '0' COMMENT '支付状态',
  `post_methods` int(10) unsigned NOT NULL default '0' COMMENT '配送方式',
  `pay_methods` int(10) unsigned NOT NULL default '0' COMMENT '支付方式',
  `money_all` decimal(8,2) unsigned NOT NULL default '0.00' COMMENT '总金额',
  `linkmeninfo` text NOT NULL COMMENT '联系人等信息',
  `goods_count` int(10) unsigned NOT NULL default '1' COMMENT '商品总数',
  `fee_money` decimal(5,2) NOT NULL default '0.00' COMMENT '邮费',
  `orther_money` decimal(8,2) NOT NULL default '0.00' COMMENT '折扣金额',
  `admin_user` varchar(255) NOT NULL COMMENT '最后的操作人员',
  `payfees` decimal(5,2) NOT NULL default '0.00' COMMENT '支付手续费',
  `lang` varchar(10) NOT NULL default 'zh-cn',
  PRIMARY KEY  (`order_id`),
  UNIQUE KEY `order_sn` (`order_sn`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

-- 
-- 导出表中的数据 `phpdtb_order`
-- 

INSERT INTO `phpdtb_order` (`order_id`, `user_id`, `order_sn`, `money`, `addtime`, `order_stats`, `pay_stats`, `post_methods`, `pay_methods`, `money_all`, `linkmeninfo`, `goods_count`, `fee_money`, `orther_money`, `admin_user`, `payfees`, `lang`) VALUES 
(1, 1, '200809020102', 5.00, 1219939494, 1, 1, 0, 0, 0.00, '联系人：徐武', 1, 0.00, 1.00, 'admin', 0.00, 'zh-cn'),
(2, 1, '200809020108', 5.00, 1219939494, 1, 1, 2, 3, 0.00, '联系人：徐武', 1, 0.00, 1.00, 'admin', 0.00, 'zh-cn'),
(3, 1, '68062461221496204', 51.00, 1221496406, 0, 0, 4, 1, 51.00, '姓名:fdsa<br />\n电话:saf<br />\n地址:safd<br />\n传真:dsafd<br />\n电子邮件:f<br />\n备注:fdsa', 11, 0.00, 0.00, '', 0.00, 'zh-cn'),
(4, 1, '97362451221497151', 8.00, 1221497601, 0, 0, 2, 1, 8.00, '姓名:vfdsa<br />\n电话:fdsafd<br />\n地址:safds<br />\n传真:fdsafd<br />\n电子邮件:safds<br />\n备注:afdsafdsafds', 4, 0.00, 0.00, '', 0.00, 'zh-cn'),
(5, 1, '87476951221497650', 8.00, 1221497650, 0, 0, 2, 1, 8.00, '姓名:vfdsa<br />\n电话:fdsafd<br />\n地址:safds<br />\n传真:fdsafd<br />\n电子邮件:safds<br />\n备注:afdsafdsafds', 4, 0.00, 0.00, '', 0.00, 'zh-cn'),
(6, 1, '73207641221497749', 8.00, 1221497749, 0, 0, 2, 1, 8.00, '姓名:vfdsa<br />\n电话:fdsafd<br />\n地址:safds<br />\n传真:fdsafd<br />\n电子邮件:safds<br />\n备注:afdsafdsafds', 4, 0.00, 0.00, '', 0.00, 'zh-cn'),
(7, 1, '31526611221498036', 3.20, 1221498105, 0, 0, 3, 1, 3.20, '姓名:徐武<br />\n电话:07985792498732<br />\n地址:中国浙江<br />\n传真:0571-888888<br />\n电子邮件:xw-09@163.com<br />\n备注:备注', 3, 0.00, 0.00, '', 0.00, 'zh-cn'),
(8, 1, '12072841221498256', 62.00, 1221498265, 0, 0, 1, 1, 62.00, '姓名:fdsafdsa<br />\n电话:fdsa<br />\n地址:fdsa<br />\n传真:fdsaf<br />\n电子邮件:fdsa<br />\n备注:fdsafdsa', 62, 0.00, 0.00, 'admin', 0.00, 'zh-cn'),
(9, 1, '72920621221667869', 78.60, 1221667914, 1, 1, 3, 1, 78.60, '姓名:姓名<br />\n电话:电话<br />\n地址:地址<br />\n传真:传真<br />\n电子邮件:电子邮件<br />\n备注:备注', 56, 0.00, 0.00, 'admin', 0.00, 'zh-cn'),
(10, 1, '33263821224421965', 1.00, 1224421994, 0, 0, 2, 1, 1.00, '姓名:fdsafdsa<br />\n电话:fdsafdsa<br />\n地址:fdsaf<br />\n传真:dsafdsa<br />\n电子邮件:fdsa<br />\n备注:fdsafdsafdsa', 1, 0.00, 0.00, '', 0.00, 'zh-cn'),
(11, 1, '90543511224774434', 16.60, 1224775379, 0, 0, 2, 4, 28.60, '姓名:徐武<br />\n电话:15068861035<br />\n地址:浙江杭州市滨江区<br />\n传真:0571-86961603<br />\n电子邮件:jing6676___@163.com<br />\n备注:飞机及发动机让顾客各方面开个会客户反馈', 16, 2.00, 0.00, '', 10.00, 'zh-cn'),
(12, 1, '36985991224777482', 2.20, 1224778604, 0, 0, 2, 4, 14.20, '姓名:xuwu125<br />\n电话:0579-83805668<br />\n地址:浙江省杭州市上城区<br />\n传真:sdafsa<br />\n电子邮件:xuwu125@gmail.com<br />\n备注:fdsafdsa', 2, 2.00, 0.00, '', 10.00, 'zh-cn'),
(13, 1, '90239051225642846', 0.00, 1225642988, 0, 0, 5, 3, 0.00, 'Name:xuwu125<br />\nPhone:0579-83805668<br />\nAddress:浙江省杭州市上城区<br />\nFax:0886r8682342f<br />\nE-mail:xuwu125@gmail.com<br />\nRemarks:dsafdsafdsafdsa', 11, 0.00, 0.00, '', 0.00, 'en-us'),
(14, 1, '54911461225726385', 0.50, 1225726429, 0, 0, 5, 3, 0.50, 'Name:xuwu125<br />\nPhone:0579-83805668<br />\nAddress:浙江省杭州市上城区<br />\nFax:234243243243<br />\nE-mail:xuwu125@gmail.com<br />\nRemarks:fdsafdsafdsafdsafdsa', 1, 0.00, 0.00, '', 0.00, 'en-us'),
(15, 1, '74164191225727287', 0.50, 1225727337, 0, 0, 2, 4, 12.50, 'Name:xuwu125<br />\nPhone:0579-83805668<br />\nAddress:浙江省杭州市上城区<br />\nFax:43543543543<br />\nE-mail:xuwu125@gmail.com<br />\nRemarks:fdsafdsa', 1, 2.00, 0.00, '', 10.00, 'en-us'),
(16, 1, '9022021225727383', 0.50, 1225727417, 0, 0, 1, 4, 2.50, 'Name:xuwu125<br />\nPhone:0579-83805668<br />\nAddress:浙江省杭州市上城区<br />\nFax:23432432<br />\nE-mail:xuwu125@gmail.com<br />\nRemarks:fdsafsfasdfdsafdsa', 1, 2.00, 0.00, '', 0.00, 'en-us');

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_order_goods`
-- 

CREATE TABLE `phpdtb_order_goods` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `order_sn` varchar(255) NOT NULL,
  `goods_id` int(11) unsigned NOT NULL default '0',
  `goods_sn` varchar(255) NOT NULL,
  `goods_price` decimal(8,2) NOT NULL default '0.00',
  `goods_count` int(11) unsigned NOT NULL default '0',
  `addtime` int(11) NOT NULL COMMENT '备注',
  `enprice` decimal(8,2) unsigned NOT NULL,
  `lang` varchar(6) NOT NULL default 'zh-cn',
  PRIMARY KEY  (`id`),
  KEY `goods_id` (`goods_id`,`goods_sn`),
  KEY `order_sn` (`order_sn`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

-- 
-- 导出表中的数据 `phpdtb_order_goods`
-- 

INSERT INTO `phpdtb_order_goods` (`id`, `order_sn`, `goods_id`, `goods_sn`, `goods_price`, `goods_count`, `addtime`, `enprice`, `lang`) VALUES 
(1, '200809020102', 1, 'fdsafdsafdsa', 1.00, 1, 0, 0.00, 'zh-cn'),
(2, '97362451221497151', 0, '', 0.00, 4, 1221497601, 0.00, 'zh-cn'),
(3, '97362451221497151', 0, '', 0.00, 4, 1221497601, 0.00, 'zh-cn'),
(4, '97362451221497151', 0, '', 0.00, 4, 1221497601, 0.00, 'zh-cn'),
(5, '97362451221497151', 0, '', 0.00, 4, 1221497601, 0.00, 'zh-cn'),
(6, '87476951221497650', 0, '', 0.00, 4, 1221497650, 0.00, 'zh-cn'),
(7, '87476951221497650', 0, '', 0.00, 4, 1221497650, 0.00, 'zh-cn'),
(8, '87476951221497650', 0, '', 0.00, 4, 1221497650, 0.00, 'zh-cn'),
(9, '87476951221497650', 0, '', 0.00, 4, 1221497650, 0.00, 'zh-cn'),
(10, '73207641221497749', 0, '', 0.00, 4, 1221497749, 0.00, 'zh-cn'),
(11, '73207641221497749', 0, '', 0.00, 4, 1221497749, 0.00, 'zh-cn'),
(12, '73207641221497749', 0, '', 0.00, 4, 1221497749, 0.00, 'zh-cn'),
(13, '73207641221497749', 0, '', 0.00, 4, 1221497749, 0.00, 'zh-cn'),
(14, '31526611221498036', 0, '', 0.00, 3, 1221498105, 0.00, 'zh-cn'),
(15, '31526611221498036', 0, '', 0.00, 3, 1221498105, 0.00, 'zh-cn'),
(16, '12072841221498256', 5, 'fdsafdsafdsa', 1.00, 5, 1221498265, 0.00, 'zh-cn'),
(17, '12072841221498256', 1, 'fdsafdsafdsa', 1.00, 57, 1221498265, 0.00, 'zh-cn'),
(18, '72920621221667869', 3, 'goods_sn', 1.20, 53, 1221667914, 0.00, 'zh-cn'),
(19, '72920621221667869', 4, 'dsafdsa', 5.00, 3, 1221667914, 0.00, 'zh-cn'),
(20, '33263821224421965', 1, 'fdsafdsafdsa', 1.00, 1, 1224421994, 0.00, 'zh-cn'),
(21, '90543511224774434', 3, 'goods_sn', 1.20, 3, 1224775379, 0.00, 'zh-cn'),
(22, '90543511224774434', 7, 'fdsafdsafdsa', 1.00, 5, 1224775379, 0.00, 'zh-cn'),
(23, '90543511224774434', 1, 'fdsafdsafdsa', 1.00, 8, 1224775379, 0.00, 'zh-cn'),
(24, '36985991224777482', 1, 'fdsafdsafdsa', 1.00, 1, 1224778604, 0.00, 'zh-cn'),
(25, '36985991224777482', 3, 'goods_sn', 1.20, 1, 1224778604, 0.00, 'zh-cn'),
(26, '90239051225642846', 34, 'fdsafdsafdsa', 1.00, 1, 1225642988, 0.00, 'en-us'),
(27, '90239051225642846', 31, 'fdsafdsafdsa', 1.00, 10, 1225642989, 0.00, 'en-us'),
(28, '54911461225726385', 34, 'fdsafdsafdsa', 1.00, 1, 1225726429, 0.00, 'en-us'),
(29, '74164191225727287', 34, 'fdsafdsafdsa', 1.00, 1, 1225727337, 0.00, 'en-us'),
(30, '9022021225727383', 34, 'fdsafdsafdsa', 1.00, 1, 1225727417, 0.00, 'en-us');

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_paymethod`
-- 

CREATE TABLE `phpdtb_paymethod` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cnname` varchar(100) NOT NULL,
  `enname` varchar(100) NOT NULL,
  `endes` text NOT NULL,
  `cndes` text NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `ispass` tinyint(3) unsigned NOT NULL default '0',
  `filename` varchar(50) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `payfees` decimal(5,2) unsigned NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_pass` varchar(50) NOT NULL,
  `pay_key` varchar(100) NOT NULL,
  `pay_orther` varchar(255) NOT NULL,
  `fee_money` decimal(5,2) NOT NULL COMMENT '配送运费',
  `user_id` int(10) unsigned NOT NULL default '0' COMMENT '用户ID',
  `enispass` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- 导出表中的数据 `phpdtb_paymethod`
-- 

INSERT INTO `phpdtb_paymethod` (`id`, `cnname`, `enname`, `endes`, `cndes`, `order`, `ispass`, `filename`, `class_name`, `payfees`, `user_name`, `user_pass`, `pay_key`, `pay_orther`, `fee_money`, `user_id`, `enispass`) VALUES 
(1, '贝宝中国', 'Paypal of china', 'Paypal of china', '宝是由上海网付易信息技术有限公司与世界领先的网络支付公司—— PayPal 公司通力合作为中国市场度身定做的网络支付服务。（网址：http://www.paypal.com/cn）', 2, 0, 'paypalcn.php', 'paypalcn', 0.00, '', '', '', '', 0.00, 0, 0),
(2, '财付通', 'Tenpay', 'Tenpay', '财付通网站 (www.tenpay.com) 作为功能强大的支付平台，是由中国最早、最大的互联网即时通信软件开发商腾讯公司创办，为最广大的QQ用户群提供安全、便捷、简单的在线支付服务。', 4, 0, 'tenpay.php', 'tenpay', 0.00, '', '', '', '', 0.00, 0, 0),
(3, '支付宝 ', 'Alipay', 'alipay', '支付宝，是支付宝公司针对网上交易而特别推出的安全付款服务，其运作的实质是以支付宝为信用中介，在买家确认收到商品前，由支付宝替买卖双方暂时保管货款的一种增值服务。（网址：http://www.alipay.com）', 3, 0, 'alipay.php', 'alipay', 0.00, 'xuwu125@gmail.com', '', '', '', 0.00, 0, 0),
(4, 'Paypal', 'Paypal', 'paypal ', 'PayPal 是在线付款解决方案的全球领导者，在全世界有超过七千一百六十万个帐户用户。PayPal 可在 56 个市场以 7 种货币（加元、欧元、英镑、美元、日元、澳元、港元）使用。（网址：http://www.paypal.com）', 1, 1, 'paypal.php', 'paypal', 2.00, 'test', 'test', 'fdsafdsa*^&^$%$#%$@', 'user_info=test', 0.00, 0, 1),
(5, '货到付款', 'Max Muster Straße 21-23 D', 'Max Muster Straße 21-23 D', '货到付款', 5, 0, 'muster.php', 'muster', 0.00, '', '', '', '', 0.00, 0, 0),
(6, '中国银行', 'China of bank', 'China of bank', '中国银行', 10, 1, 'ortherbank.php', 'ortherbank', 0.00, '', '', '', '', 0.00, 0, 0);

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_postmethod`
-- 

CREATE TABLE `phpdtb_postmethod` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cnname` varchar(100) NOT NULL,
  `enname` varchar(100) NOT NULL,
  `endes` text NOT NULL,
  `cndes` text NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `ispass` tinyint(3) unsigned NOT NULL default '0',
  `post_fees` decimal(5,2) unsigned NOT NULL default '0.00' COMMENT '邮费',
  `enispass` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

-- 
-- 导出表中的数据 `phpdtb_postmethod`
-- 

INSERT INTO `phpdtb_postmethod` (`id`, `cnname`, `enname`, `endes`, `cndes`, `order`, `ispass`, `post_fees`, `enispass`) VALUES 
(1, '邮局平邮', 'China e', 'China e', '邮局平邮', 5, 1, 0.00, 0),
(2, 'EMS', 'EMS', 'EMS websiete:http://www.ems.com.cn/english-main.jsp', 'EMS 网站:http://www.ems.com.cn/', 3, 1, 10.00, 0),
(3, 'UPS', 'UPS', 'UPS website:http://www.ups.com', 'UPS 中国网址：http://www.ups.com/content/cn/zh/index.jsx', 1, 1, 1.00, 0),
(4, 'DHL', 'DHL', 'DHL', 'DHL', 2, 1, 0.00, 0),
(5, 'Fedex', 'Fedex', 'Fedex website：http://fedex.com', 'Fedex 网址：http://fedex.com/cn/', 4, 1, 0.00, 1),
(6, '圆通快递', 'Yuantong ', 'Yuantong ', '圆通快递', 6, 1, 0.00, 0),
(7, '顺风快递', 'Shunfeng', 'Shunfeng', '顺风快递', 7, 1, 0.00, 0),
(8, '申通快递', 'Shengtong', 'Shengtong', '申通快递', 8, 1, 0.00, 0),
(9, '中通速递', 'Zhongtong', 'Zhongtong', '中通速递', 9, 1, 0.00, 0),
(10, '运费到付', 'FPD', 'FPD', '运费到付', 10, 1, 0.00, 0),
(11, '上门取货 ', 'Cac', 'Cac', '上门取货 ', 11, 0, 0.00, 0);

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_price`
-- 

CREATE TABLE `phpdtb_price` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cnname` varchar(100) NOT NULL,
  `enname` varchar(100) NOT NULL,
  `cndes` text NOT NULL,
  `endes` text NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `ispass` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- 导出表中的数据 `phpdtb_price`
-- 

INSERT INTO `phpdtb_price` (`id`, `cnname`, `enname`, `cndes`, `endes`, `order`, `ispass`) VALUES 
(1, '1-2元', '1-2RMB', '1-2美元', '1-2美元', 1, 1);

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_privileges`
-- 

CREATE TABLE `phpdtb_privileges` (
  `comid` tinyint(4) NOT NULL auto_increment,
  `parent_index` varchar(30) NOT NULL COMMENT '权限名称',
  `node_index` varchar(30) NOT NULL COMMENT '上级权限',
  `name` varchar(255) NOT NULL COMMENT '名称',
  PRIMARY KEY  (`comid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=79 ;

-- 
-- 导出表中的数据 `phpdtb_privileges`
-- 

INSERT INTO `phpdtb_privileges` (`comid`, `parent_index`, `node_index`, `name`) VALUES 
(1, 'add_goods', '', '增加商品'),
(2, 'add_goods', 'list', '列表'),
(3, 'nav', '', '菜单栏目'),
(4, 'nav', 'list', '列表'),
(5, 'nav', 'add', '添加'),
(6, 'template', '', '模板管理'),
(7, 'template', 'list', '列表'),
(8, 'goods_manage', '', '商品管理'),
(9, 'goods_manage', 'list', '列表'),
(10, 'edit_goods', '', '编辑商品'),
(11, 'edit_goods', 'list', '列表'),
(12, 'del_goods', '', '删除商品'),
(13, 'del_goods', 'list', '列表'),
(14, 'user_manage', '', '会员管理'),
(15, 'user_manage', 'list', '列表'),
(16, 'user_manage', 'edit', '编辑'),
(17, 'cp', '', '后台中心'),
(18, 'cp', 'list', '列表'),
(19, 'wellcome', '', '欢迎中心'),
(20, 'wellcome', 'list', '列表'),
(21, 'adminuser_manage', '', '管理员管理'),
(22, 'adminuser_manage', 'list', '列表'),
(23, 'setting', '', '基础设定'),
(24, 'setting', 'list', '列表'),
(25, 'price_manage', '', '价格管理'),
(26, 'price_manage', 'list', '列表'),
(27, 'mate_manage', '', '材料管理'),
(28, 'mate_manage', 'list', '列表'),
(29, 'color_manage', '', '颜色管理'),
(30, 'color_manage', 'list', '列表'),
(31, 'categroy_manage', '', '商品分类'),
(32, 'categroy_manage', 'list', '列表'),
(33, 'categroy_manage', 'edit', '编辑'),
(34, 'categroy_manage', 'add', '添加'),
(35, 'color_manage', 'add', '添加'),
(36, 'color_manage', 'edit', '编辑'),
(37, 'adminuser_manage', 'edit', '编辑'),
(38, 'logs_manage', '', '日志管理'),
(39, 'logs_manage', 'list', '列表'),
(40, 'logs_manage', 'view', '查看'),
(41, 'nav', 'edit', '编辑'),
(43, 'nav', 'eidtsave', '编辑保存'),
(44, 'phpinfo', '', '显示PHP信息'),
(45, 'phpinfo', 'list', '显示PHP信息'),
(46, 'adminuser_manage', 'add', '添加'),
(47, 'order_manage', '', '订单管理'),
(48, 'order_manage', 'list', '列表'),
(49, 'comp_manage', '', '权限管理'),
(50, 'comp_manage', 'list', '列表'),
(51, 'comp_manage', 'add', '添加'),
(52, 'cache_manage', '', '缓存管理'),
(53, 'cache_manage', 'list', '列表'),
(54, 'cache_manage', 'del', '删除'),
(55, 'execute_sql', '', '执行SQL'),
(56, 'execute_sql', 'list', '列表'),
(57, 'freeback_manage', '', '在线留言管理员'),
(58, 'freeback_manage', 'list', '列表'),
(59, 'template_view', '', '模板管理'),
(60, 'template_view', 'list', '列表'),
(61, 'lang_manage', '', '语言包管理'),
(62, 'lang_manage', 'list', '列表'),
(63, 'freeback_manage', 'edit', '编辑'),
(64, 'paymethod_manage', '', '支付方式管理'),
(65, 'paymethod_manage', 'list', '列表'),
(66, 'paymethod_manage', 'edit', '编辑'),
(67, 'usa_manage', '', '汇率管理'),
(68, 'usa_manage', 'list', '列表'),
(69, 'postmethod_manage', '', '配送方式管理'),
(70, 'postmethod_manage', 'list', '列表'),
(71, 'postmethod_manage', 'edit', '编辑'),
(72, 'order_manage', 'action', '处理'),
(73, 'price_manage', 'edit', 'edit'),
(74, 'paymethod_manage', 'add', '增加'),
(75, 'order_manage', 'del', '删除'),
(76, 'status_script', '', '统计代码'),
(77, 'status_script', 'list', 'list'),
(78, 'user_manage', 'del', '删除');

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_sessions`
-- 

CREATE TABLE `phpdtb_sessions` (
  `sesskey` char(32) character set utf8 collate utf8_bin NOT NULL default '',
  `expiry` int(10) unsigned NOT NULL default '0',
  `userid` mediumint(8) unsigned NOT NULL default '0',
  `adminid` mediumint(8) unsigned NOT NULL default '0',
  `ip` char(15) NOT NULL default '',
  `data` char(255) NOT NULL default '',
  PRIMARY KEY  (`sesskey`),
  KEY `expiry` (`expiry`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- 
-- 导出表中的数据 `phpdtb_sessions`
-- 

INSERT INTO `phpdtb_sessions` (`sesskey`, `expiry`, `userid`, `adminid`, `ip`, `data`) VALUES 
(0x6231666635616166313032646331613165626364616263333631643836653539, 1229075536, 0, 1, '127.0.0.1', 'a:4:{s:9:"user_code";s:4:"0099";s:8:"admin_id";s:1:"1";s:9:"user_name";s:5:"admin";s:9:"user_comp";s:3:"all";}'),
(0x3961663266373135373338343161663234316261653866656465633731623964, 1229074792, 0, 0, '127.0.0.1', 'a:0:{}');

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_sessions_data`
-- 

CREATE TABLE `phpdtb_sessions_data` (
  `sesskey` varchar(32) character set utf8 collate utf8_bin NOT NULL default '',
  `expiry` int(10) unsigned NOT NULL default '0',
  `data` longtext NOT NULL,
  PRIMARY KEY  (`sesskey`),
  KEY `expiry` (`expiry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- 导出表中的数据 `phpdtb_sessions_data`
-- 


-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_setting`
-- 

CREATE TABLE `phpdtb_setting` (
  `setid` tinyint(3) unsigned NOT NULL auto_increment,
  `isoff` tinyint(3) unsigned NOT NULL default '0' COMMENT '网站开关',
  `isoff_des` text NOT NULL COMMENT '关闭站点的原因',
  `enname` varchar(255) NOT NULL,
  `endes` varchar(255) NOT NULL,
  `enkeyword` varchar(255) NOT NULL,
  `enheader` text NOT NULL,
  `enfooter` text NOT NULL,
  `cnname` varchar(255) NOT NULL,
  `cndes` varchar(255) NOT NULL,
  `cnkeyword` varchar(255) NOT NULL,
  `cnheader` text NOT NULL,
  `cnfooter` text NOT NULL,
  `code_type` tinyint(1) unsigned NOT NULL default '8',
  `edit_width` varchar(50) NOT NULL,
  `edit_height` varchar(50) NOT NULL,
  `edit_skin` varchar(50) NOT NULL,
  `edit_toolbar` varchar(50) NOT NULL,
  `sessionmaxtime` int(10) unsigned NOT NULL,
  `ip_no_access` varchar(255) NOT NULL,
  `plugins_onoff` tinyint(1) unsigned NOT NULL default '1' COMMENT '是否启用插件',
  `status_script` text NOT NULL,
  `template` varchar(20) NOT NULL default 'default',
  `language` varchar(20) NOT NULL default 'zh-cn',
  `tpl_cache` tinyint(1) NOT NULL default '0',
  `tpl_cachetime` int(11) NOT NULL default '0',
  `cache_data_dir` varchar(100) NOT NULL default 'Tmp/caches/',
  `session_cookie_path` varchar(100) NOT NULL default '/',
  `session_cookie_domain` varchar(100) NOT NULL,
  `cookies_prefix` varchar(10) NOT NULL default 'dtb_',
  `max_cache_time` int(11) NOT NULL default '300',
  `sql_logs_dir` varchar(200) NOT NULL default 'Tmp/logs',
  `rewrite_mod` tinyint(1) unsigned NOT NULL default '0',
  `goods_bigimg` varchar(255) NOT NULL,
  `goods_smallimg` varchar(255) NOT NULL,
  `class_img` varchar(255) NOT NULL,
  `status_off` tinyint(1) unsigned NOT NULL default '0',
  `status_small` tinyint(1) unsigned NOT NULL default '0',
  `goods_pagesize` int(10) unsigned NOT NULL default '12',
  `goods_photoview` tinyint(1) unsigned NOT NULL default '0' COMMENT '图片的显示方式',
  `online_pay` tinyint(1) NOT NULL default '0' COMMENT '是否开启在线支付功能。',
  `home_costume` tinyint(1) NOT NULL default '0' COMMENT '首页自定义',
  `home_costume_content` text NOT NULL COMMENT '首页自定义内容',
  `home_costumeen` tinyint(1) NOT NULL,
  `home_costume_contenten` text NOT NULL,
  PRIMARY KEY  (`setid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- 导出表中的数据 `phpdtb_setting`
-- 

INSERT INTO `phpdtb_setting` (`setid`, `isoff`, `isoff_des`, `enname`, `endes`, `enkeyword`, `enheader`, `enfooter`, `cnname`, `cndes`, `cnkeyword`, `cnheader`, `cnfooter`, `code_type`, `edit_width`, `edit_height`, `edit_skin`, `edit_toolbar`, `sessionmaxtime`, `ip_no_access`, `plugins_onoff`, `status_script`, `template`, `language`, `tpl_cache`, `tpl_cachetime`, `cache_data_dir`, `session_cookie_path`, `session_cookie_domain`, `cookies_prefix`, `max_cache_time`, `sql_logs_dir`, `rewrite_mod`, `goods_bigimg`, `goods_smallimg`, `class_img`, `status_off`, `status_small`, `goods_pagesize`, `goods_photoview`, `online_pay`, `home_costume`, `home_costume_content`, `home_costumeen`, `home_costume_contenten`) VALUES 
(1, 1, '网站升级中', 'PHPdtb website', 'PHPdtb website', 'PHPdtb website', '<!--PHPdtb website header-->', '<!--PHPdtb website footer-->', 'PHPdtb 开源网站系统演示', 'PHPdtb 开源网站系统演示', 'PHPdtb,开源网站系统演示', '<!--PHPdtb 开源网站系统演示header-->', '<!--PHPdtb 开源网站系统演示footer-->', 8, '100%', '500px', 'default', 'Default', 1800, '192.168.1.1\r\n192.168.18.*', 1, '<div title=''Stats script'' style=''display:none''>\r\n</div>', 'default', 'zh-cn', 0, 1800, 'Tmp/caches/', '/', '', 'dtb_', 10, 'Tmp/logs/', 0, 'upload/goods/big', 'upload/goods/small', 'upload/class_img', 0, 0, 12, 0, 0, 0, ' ', 0, ' ');

-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_status`
-- 

CREATE TABLE `phpdtb_status` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `ip` varchar(32) NOT NULL,
  `addtime` int(10) unsigned NOT NULL default '0',
  `referer` varchar(255) NOT NULL,
  `thisurl` varchar(255) NOT NULL,
  `browser` varchar(255) NOT NULL,
  `system` varchar(255) NOT NULL,
  `alexa` tinyint(3) unsigned NOT NULL default '0',
  `user_augrent` varchar(255) NOT NULL,
  `language` varchar(30) NOT NULL,
  `parent` varchar(30) NOT NULL,
  `orthers` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- 导出表中的数据 `phpdtb_status`
-- 


-- --------------------------------------------------------

-- 
-- 表的结构 `phpdtb_users`
-- 

CREATE TABLE `phpdtb_users` (
  `user_id` int(10) unsigned NOT NULL auto_increment,
  `user_name` varchar(24) NOT NULL,
  `user_truename` varchar(8) NOT NULL COMMENT '真实姓名',
  `user_pass` varchar(32) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_q` varchar(255) NOT NULL,
  `user_a` varchar(255) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_province` varchar(100) NOT NULL default '浙江省',
  `user_city` varchar(100) NOT NULL default '杭州市',
  `user_qq` int(10) unsigned NOT NULL,
  `user_orther` varchar(255) NOT NULL,
  `user_orther_num` varchar(255) NOT NULL,
  `user_tel` varchar(255) NOT NULL,
  `user_mob` varchar(255) NOT NULL,
  `user_money` decimal(8,2) NOT NULL default '0.00',
  `user_rank` tinyint(3) unsigned NOT NULL default '0',
  `user_integral` int(10) unsigned NOT NULL default '0',
  `user_regip` varchar(32) NOT NULL default '127.0.0.1',
  `user_regtime` int(10) unsigned NOT NULL default '0',
  `user_lastlogintime` int(10) unsigned NOT NULL default '0',
  `user_lastloginip` varchar(32) NOT NULL default '127.0.0.1',
  `user_logincount` int(10) unsigned NOT NULL default '1',
  `user_lock` tinyint(1) unsigned NOT NULL default '0' COMMENT '锁定会员',
  `companyname` varchar(255) NOT NULL,
  `user_address2` varchar(225) NOT NULL,
  `come_from` varchar(225) NOT NULL COMMENT '来自何处',
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `user_name` (`user_name`,`user_email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- 导出表中的数据 `phpdtb_users`
-- 

INSERT INTO `phpdtb_users` (`user_id`, `user_name`, `user_truename`, `user_pass`, `user_email`, `user_q`, `user_a`, `user_address`, `user_province`, `user_city`, `user_qq`, `user_orther`, `user_orther_num`, `user_tel`, `user_mob`, `user_money`, `user_rank`, `user_integral`, `user_regip`, `user_regtime`, `user_lastlogintime`, `user_lastloginip`, `user_logincount`, `user_lock`, `companyname`, `user_address2`, `come_from`) VALUES 
(1, 'xuwu125', '徐武', '7b75661080f25bfa3834407a9053278e', 'xuwu125@gmail.com', '123456', '654321', '浙江省杭州市上城区', '浙江省', '杭州市', 283573363, 'MSN', 'xuwu125@hotmail.com', '0579-83805668', '', 0.00, 0, 0, '127.0.0.1', 1223178058, 1223178058, '127.0.0.1', 1, 0, 'fdsafdsa', 'fdsafdsa', 'google');
