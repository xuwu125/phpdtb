<?php
/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */
/**
 * ========================================================================
 * Appname:     dtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-11-4
 * Filename:    index.php
 * Description:	支付接口返回文件 
 * ========================================================================
 * */
$install_lockfile="./tools/install.lock";
if(!file_exists($install_lockfile)){
    die("对不起，请先运行安装程序。<a href='install.php'>马上安装</a>");
}
define('IN_SITE',true);
define('SET_Smarty',true);
define('DEV_ACCESS',true);
define('NOSET_AJAX',true);
define('NOT_START',false);

include_once('include/init.php');
/*$tpl->assign();*/

/*开始*/

$publinks=array(
	array('text'=>$LANG['go_on'],"href"=>'index.php?act=user&lang='.$language),
	array('text'=>$LANG['go_home'],"href"=>"index.php")
	);

$code=$_GET['code'];
if(empty($code)){
    $dtb->sysbox($LANG['error'].$LANG['tips'],$LANG['param_error'],$publinks);
}else {
    
    $app=get_paymentname($code);
    if(file_exists(ROOT_PATH."tools/paymethod/".$app['filename'])){
        require_once(ROOT_PATH."tools/paymethod/".$app['filename']);
        $pay_respond=new $app['class_name']();
        $pay_status=$pay_respond->respond();
        if($pay_status){
           $dtb->sysbox($LANG['success'].$LANG['tips'],$LANG['pay_ok'],$publinks); 
        }else{
           $dtb->sysbox($LANG['error'].$LANG['tips'],$LANG['pay_err'],$publinks);  
        }
    }else{
        $dtb->sysbox($LANG['error'].$LANG['tips'],$LANG['param_error'],$publinks);
    }
}
?>