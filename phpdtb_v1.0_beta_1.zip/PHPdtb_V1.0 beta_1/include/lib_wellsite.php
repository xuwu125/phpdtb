<?php

/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */
/**
 +------------------------------------------------------------------------------
 * $Id$ lib_main.php PHPdtb 后台主体程序工具用类
 +------------------------------------------------------------------------------
 */
if (!defined('IN_SITE'))
{
    die('Hacking attempt');
}


/**
 * 获取分类的信息
 *
 * @param int $cate_id
 * @param string $fname
 * @return array and string
 */
function get_categroy($cate_id,$fname='*'){
    $sql="SELECT $fname FROM ".$GLOBALS['dtb']->table("categroy")." WHERE cid='$cate_id'";
    if($fname=="*"){
        return $GLOBALS['db']->getRow($sql);
    }else{
        return $GLOBALS['db']->getOne($sql);
    }
}

/**
 * 分页处理函数
 *
 * @param string $tabname
 * @param string $where
 * @param int $pages
 * @return array
 */
function get_page($tabname,$where='',$pages=array()){
    $sql="SELECT COUNT(*) FROM ".$GLOBALS['dtb']->table($tabname).$where;
    $pages['readcount']=$GLOBALS['db']->getOne($sql);
    $pages['pagecount']=ceil($pages['readcount']/$pages['pagesize']);
    if(!empty($pages['page'])){
        $pages['satrt']=intval(($pages['page'])-1)*$pages['pagesize'];
        
    }else{
        $pages['satrt']=0;
    }
    return $pages;
}

/*
* 获取所有无限级分类。
*/
function getcategroy_list($cate_id='0',$flag=1,$orthers=''){
    $sql="SELECT * FROM ".$GLOBALS['dtb']->table("categroy")." WHERE categoryid='$cate_id' AND ispass='$flag' $orthers ORDER BY `order` ASC";
    //echo $sql;
    $temp=$GLOBALS['db']->getAll($sql);
    if(!empty($temp)){
    for ($i=0;$i<count($temp);$i++) {
        $temp[$i]['en_url']=build_url(array("act"=>'product','cateid'=>$temp[$i]['cid']),"en-us");
        $temp[$i]['cn_url']=build_url(array("act"=>'product','cateid'=>$temp[$i]['cid']),"zh-cn");
        $temp[$i]['goods_count']=get_cate_goods_count($temp[$i]['cid']);
    	$temp[$i]['cate_two']=getcategroy_list($temp[$i]['cid'],$flag);
    }
    return $temp;
    }else {
        return false;
    }
}

/**
 * 获取 指定表的一行信息
 *
 * @param string $tabname
 * @param int $id
 * @return array
 */
function get_dbinfo($tabname,$id,$flag='*'){
    if(!empty($id)&&!empty($tabname)){
        $sql="SELECT $flag FROM ".$GLOBALS['dtb']->table($tabname)." WHERE `id`='$id'";
        return $GLOBALS['db']->getRow($sql);
    }
}
/**
 * 获取指定表，再安条件获取所有多条数据。
 *
 * @param string $tabname
 * @param string $flag
 * @return array
 */
function get_dball($tabname ,$flag="`ispass`='1'"){
    if(!empty($tabname)){
        $sql="SELECT * FROM ".$GLOBALS['dtb']->table($tabname)." WHERE $flag ORDER BY `order` ASC ";
        return $GLOBALS['db']->getAll($sql);
    }
}
/**
 * 获取订单中的商品。
 *
 * @param string $order_sn
 * @return array
 */
function get_order_goods($order_sn){
    $sql="SELECT * FROM ".$GLOBALS['dtb']->table("order_goods")." WHERE order_sn='$order_sn'";
    $glist=$GLOBALS['db']->getAll($sql);
    if(!empty($glist)){
        $imax=count($glist);
        for ($i=0;$i<$imax;$i++){
            $glist[$i]['goods_enname']=get_goods_info($glist[$i]['goods_id'],'goods_enname');
            $glist[$i]['goods_cnname']=get_goods_info($glist[$i]['goods_id'],'goods_cnanme');
            $glist[$i]['goods_detil']=($glist[$i]['goods_count']*$glist[$i]['goods_price']);
        }
        return $glist;
    }else{
        return false;
    }
}

function get_order_info($order_sn,$flag=0){
    if($flag==0){
    $sql="SELECT * FROM ".$GLOBALS['dtb']->table("order")." WHERE order_id='$order_sn'";
    }else{
    $sql="SELECT * FROM ".$GLOBALS['dtb']->table("order")." WHERE order_sn='$order_sn'";  
    }
    $olist=$GLOBALS['db']->getRow($sql);
    if(!empty($olist)){
        $olist['order_statustext']=$GLOBALS['order_status'][$olist['order_stats']];
        $olist['pay_statustext']=$GLOBALS['pay_status'][$olist['pay_stats']];
        $olist['adddate']=date("Y-m-d H:i:s",$olist['addtime']);
        return $olist;
    }else{
        return false;
    }
}

/*获取商品信息*/
function get_goods_info($goods_id,$flag="*",$ispass=0){
    $sql="SELECT $flag FROM ".$GLOBALS['dtb']->table("goods")." WHERE `goods_id`='$goods_id'";
    if(!empty($ispass)){
        $sql="SELECT $flag FROM ".$GLOBALS['dtb']->table("goods")." WHERE `ispass`='$ispass' AND `goods_id`='$goods_id'";
    }
    if($flag=='*'){
        $temp=$GLOBALS['db']->getRow($sql);
        if(!empty($temp)){
            $prames=array('act'=>"goods",
            'goods_id'=>$temp['goods_id']);
            $temp['cn_url']=build_url($prames,"zh-cn");
            $temp['en_url']=build_url($prames,"en-us");
        }
        return $temp;
    }else{
        return $GLOBALS['db']->getOne($sql);
    }
}

/*创建URL*/

/**
 * Enter description here...
 *
 * @param array     $param      要生成的URL参数
 * @return string               返回生成好的URL
 */
function build_url($param,$flag=0){
    if(empty($param)){
        $url="index.php";
    }else {
        if(!empty($flag)){
            $param['lang']=$flag;
        }
        if(empty($param['lang'])){
           $param['lang']=$GLOBALS['language'];
        }
        if(!empty($GLOBALS['siteconfig']['rewrite_mod'])){
            foreach ($param as $par=>$parval){
                if(!empty($par)){
                    $url2[]=$parval;
                }
            }
            $url.=implode("-",$url2).".html";
        }else {
            
            if(empty($flag)){
                $param['lang']=$GLOBALS['language'];
            }else{
                $param['lang']=$flag;
            }
            foreach ($param as $par=>$parval){
                if(!empty($par)){
                $urlt[]=$par."=".$parval;
                }
            }
           
            $url="index.php?".implode("&amp;",$urlt);
        }
    }
    return $url;
}


/**
 * 获取所有菜单 
 *
 * @return array
 */
function get_nav(){
    $sql="SELECT `cid`,`entitle`,`cntitle`,`en_url`,`cn_url`,`nav_name`,`style`,`blank` FROM ".
    $GLOBALS['dtb']->table("nav")." WHERE `ispass`='1' AND (`type`='1' OR  `type`='2') ORDER BY `order` ASC ";
    $nav=$GLOBALS['db']->getAll($sql);
    $navmax=count($nav);
    for ($i=0;$i<$navmax;$i++){
        if($nav[$i]['cn_url']=="auto"){$nav[$i]['cn_url']=build_url(array("act"=>$nav[$i]['nav_name']),"zh-cn");}
        if($nav[$i]['en_url']=="auto"){$nav[$i]['en_url']=build_url(array("act"=>$nav[$i]['nav_name']),"en-us");}
    }
    return $nav;
}


/**
 * 获取指定的栏目的数据。
 *
 * @param string $nav_name  栏目的名称
 * @return array
 */
function get_columns($nav_name){
    if(empty($nav_name)){return false;}
    $sql="SELECT * FROM ".
    $GLOBALS['dtb']->table("nav")." WHERE `ispass`='1' AND (`type`='0' OR  `type`='2') AND `nav_name`='$nav_name' LIMIT 0,1 ";
    $temp=$GLOBALS['db']->getRow($sql);
    if(!empty($temp)){
        foreach ($temp as $key=>$v){
            $temp[$key]=str_replace("public/template/","",$temp[$key]);
        }
    }
    return $temp;
}

/**
 * 获取所有统计信息
 *
 * @return array
 */
function get_site_status($where=null,$start=0,$ends=30){
    $sql="SELECT * FROM ".$GLOBALS['dtb']->table("status").$where." LIMIT $start, $ends ";
    $l=$GLOBALS['db']->getAll($sql);
    return $l;
}

/**
 * 获取所有自定义栏目数组
 *
 */
function get_navact(){
    $sql="SELECT `nav_name` FROM ".$GLOBALS['dtb']->table("nav")." WHERE `ispass`='1'  ";
    $list=$GLOBALS['db']->getALL($sql);
    foreach ($list as $list2){
        $list3[]=$list2['nav_name'];
    }
    return $list3;
}
/**
 * 获取所有自定义栏目数组
 *
 */
function get_nav_name($nav_name){
    $list3=$GLOBALS['language']=="zh-cn"?'cntitle':'entitle';
    $sql="SELECT $list3 FROM ".$GLOBALS['dtb']->table("nav")." WHERE `ispass`='1' AND nav_name='$nav_name'  ";
    return $GLOBALS['db']->getOne($sql);
}

function get_navarray(){
    $sql="SELECT `nav_name`,`cntitle`,`entitle` FROM ".$GLOBALS['dtb']->table("nav")." WHERE `ispass`='1'  ";
    $list=$GLOBALS['db']->getALL($sql);
    foreach ($list as $list2){
        $list3[$list2['nav_name']]=$GLOBALS['language']=="zh-cn"?$list2['cntitle']:$list2['entitle'];
    }
    return $list3;
}


function show_sys_nav(){
    $sys_action=$GLOBALS['sys_action'];
    $action=$GLOBALS['action'];
    $nav_action=get_navarray();
    $all_action=array_merge($nav_action,$sys_action);
    //print_r($all_action);
    $on_sys_nav=$GLOBALS['LANG']['on_nav'];
    $on_sys_nav.="&gt;&gt;".$all_action[$action];
    return $on_sys_nav;
}
function get_sys_navarray($action=''){
    $sys_action=$GLOBALS['sys_action'];
    $action=$GLOBALS['action'];
    $nav_action=get_navarray();
    $all_action=array_merge($nav_action,$sys_action);
    if(empty($action)){
    return $all_action;
    }else{
        return $all_action[$action];
    }
}

function upload_img($goods_img,$images_dir='upload'){
    include_once(ROOT_PATH . 'include/cls_image.php');
    $image = new cls_image($GLOBALS['_CFG']['bgcolor']); 
    $image->data_dir='';  
    if (isset($_FILES[$goods_img]['error'])) // php 4.2 版本才支持 error
    {
        // 最大上传文件大小
        $php_maxsize = ini_get('upload_max_filesize');
        $htm_maxsize = '2M';
        
        // 商品图片
        if ($_FILES[$goods_img]['error'] == 0)
        {
            if (!$image->check_img_type($_FILES[$goods_img]['type']))
            {
                return false;
            }
        }
        elseif ($_FILES[$goods_img]['error'] == 1)
        {
            return false;
        }
        elseif ($_FILES[$goods_img]['error'] == 2)
        {
            return false;
        }
    }

    $original_img   = $image->upload_image($_FILES[$goods_img],$images_dir); // 原始图片
    
    if ($original_img === false)
    {
        return false;
    }
    if(substr($original_img,0,1)=="/"){
        $original_img=substr($original_img,1,strlen($original_img));
    }
    return $original_img;
}

/**
 * 创建可以上传文件的目录 。
 *
 * @param string $dir   目录名字
 */
function make_dir($dir){
    
    //die($dir);
    if(!file_exists($dir)){
       @mkdir($dir,0777);
       return true;
    }else{
        return true;
    }
}

/**
 * 将数组转换为字符
 *
 * @param array     $array          数组和未知数组
 * @param string    $string_flg     分隔标识
 * @return array and string
 */
function array_tostring($array,$string_flg=','){
    if(!is_array($array)){
        return $array;
    }else{
        if(!empty($array)){
            return implode($string_flg,$array);
        }else{
            return $array;
        }
    }
}


/**
 * 获取分类下的商品数量
 *
 * @param int $cate_id  商品分类的ID
 * @return int  返回该分类下的商品数量
 */
function get_cate_goods_count($cate_id){
    $sql="SELECT COUNT(*) FROM ".$GLOBALS['dtb']->table("goods")." WHERE ispass='1' AND( goods_cate_id='$cate_id' OR  ".
        "goods_cate_id IN (SELECT cid FROM ".$GLOBALS['dtb']->table("categroy")." WHERE categoryid='$cate_id'  AND ispass='1'))";
    $goods_count=$GLOBALS['db']->getOne($sql);
    if(empty($goods_count)){
        return "0";
    }else{
        return $goods_count;
    }
}

function getgoodsinfo($goods_id){
    $sql="SELECT * FROM ".$GLOBALS['dtb']->table("goods")." WHERE goods_id='$goods_id' AND ispass='1' LIMIT 0,1";
    $list=$GLOBALS['db']->getRow($sql);
    if(!empty($list)){
    $prames['act']="goods";
    $prames['goods_id']=$list['goods_id'];
    $list['cn_url']=build_url($prames,"zh-cn");
    $list['en_url']=build_url($prames,"en-us");
    }
    return $list;
}

/**
 * 获取支持方式。
 *
 * @param int $id           支付方式ID，可以为空
 * @param string $flag      查询的字段,*可以查询所有字段
 * @return array            返回结果
 */
function get_paymethod($id=0,$flag='`id`,`cnname`,`enname`,`filename`,`class_name`'){
    $ispasswhere=" `ispass`='1' ";
        if($GLOBALS['language']!='zh-cn'){
            $ispasswhere=" `enispass`='1' ";
        }
    if($id==0){
        
        $sql="SELECT $flag FROM ".$GLOBALS['dtb']->table("paymethod")." WHERE $ispasswhere ORDER BY `order` ASC  ";
        $list=$GLOBALS['db']->getALL($sql);
         foreach ($list as $key=>$list2){
            $tmep=$GLOBALS['language']=="zh-cn"?$list2['cnname']:$list2['enname'];
            $list[$key]['post_name']=$tmep;
        }
        return $list;
    }else{
        $sql="SELECT $flag FROM ".$GLOBALS['dtb']->table("paymethod")." WHERE $ispasswhere AND id='$id' ";
        $info=$GLOBALS['db']->getRow($sql);
        if(!empty($info)){
        $tmep=($GLOBALS['language']=="zh-cn")?$info['cnname']:$info['enname'];
        $info['pay_name']=$tmep;
        }
        return $info;
    }
}

/**
 * 获取支持方式。
 *
 * @param int $id           支付方式ID，可以为空
 * @param string $flag      查询的字段,*可以查询所有字段
 * @return array            返回结果
 */
function get_paymentname($filename){
        $filename=$filename.".php";
        $sql="SELECT * FROM ".$GLOBALS['dtb']->table("paymethod")." WHERE `ispass`='1' AND `filename`='$filename' ";
        if($GLOBALS['language']!="zh-cn"){
        $sql="SELECT * FROM ".$GLOBALS['dtb']->table("paymethod")." WHERE `enispass`='1' AND `filename`='$filename' ";	
        
        }
        $info=$GLOBALS['db']->getRow($sql." LIMIT 1");
        $tmep=($GLOBALS['language']=="zh-cn")?$info['cnname']:$info['enname'];
        $info['pay_name']=$tmep;
        return $info;

}
/**
 * 获取物流配送方式
 *
 * @param int $id       配送方式ID，可以为空
 * @param string $flag  查询的字段,*可以查询所有字段
 * @return array        返回结果。
 */
function get_postmethod($id=0,$flag='`id`,`cnname`,`enname`'){
    $ispasswhere=" `ispass`='1' ";
        if($GLOBALS['language']!='zh-cn'){
            $ispasswhere=" `enispass`='1' ";
        }
    if($id==0){
        $sql="SELECT $flag FROM ".$GLOBALS['dtb']->table("postmethod")." WHERE $ispasswhere ORDER BY `order` ASC  ";
        $list=$GLOBALS['db']->getALL($sql);
        foreach ($list as $key=>$list2){
            $tmep=$GLOBALS['language']=="zh-cn"?$list2['cnname']:$list2['enname'];
            $list[$key]['post_name']=$tmep;
        }
        return $list;
    }else{
        $sql="SELECT $flag FROM ".$GLOBALS['dtb']->table("postmethod")." WHERE $ispasswhere AND id='$id' ";
        $info=$GLOBALS['db']->getRow($sql);
        $tmep=($GLOBALS['language']=="zh-cn")?$info['cnname']:$info['enname'];
        $info['post_name']=$tmep;
        return $info;
    }
}

/**
 * 获取可用的订单号。
 *
 * @return int
 */
function get_order_sn(){
    if(empty($_SESSION['order_sn'])){
        $order_sn=date("YmdHis",time()).rand(100000,9999999);
    }else{
        $order_sn=$_SESSION['order_sn'];
    }
    $sql="SELECT COUNT(*) FROM ".$GLOBALS['dtb']->table("order")." WHERE order_sn='$order_sn'";
    $yesorno=$GLOBALS['db']->getOne($sql);
    if(empty($yesorno)||$yesorno<=0){// 直到不重复了，就返回订单号。
        $_SESSION['order_sn']=$order_sn;
        return $order_sn;
    }else{
        $_SESSION['order_sn']=null;
        $order_sn=get_order_sn();// 重新生成。
        return $order_sn;
    }
}

/**
 * 获取购物车中的商品。
 *
 * @return array
 */
function get_cart_goods(){
    $sql="SELECT * FROM ".$GLOBALS['dtb']->table("cart")." WHERE sessid='".SESS_ID."' ";
    return $GLOBALS['db']->getAll($sql);
}
/**
 * 删除购物车中的商品。
 *
 * @return array
 */
function clean_cart_goods(){
    $sql="DELETE FROM ".$GLOBALS['dtb']->table("cart")." WHERE sessid='".SESS_ID."' ";
    return $GLOBALS['db']->query($sql);
}
/**
 * 获取购物车中商品的统计。
 *
 * @return unknown
 */
function get_cart_sum(){
    $sqlt=$GLOBALS['language']=='zh-cn'?'price':'enprice';
    $sql="SELECT SUM(count*$sqlt) AS allmoney,SUM(count) AS allcount,COUNT(*) AS goodscount FROM ".$GLOBALS['dtb']->table("cart")." WHERE sessid='".SESS_ID."' ";
    return $GLOBALS['db']->getRow($sql);
}

/**
 * 模板编辑时替换固定的对象。
 *
 * @param string $str
 * @param int $flag 0,1,2
 * @return string
 */
function textbox_code($str,$flag=0){
    $replace1=array('<textarea','</textarea>','<input');
    $replace2=array('[textarea','[/textarea]','[input');
    if($flag==1){
        return str_replace($replace2,$replace1,$str);
    }elseif ($flag==0){
        return str_replace($replace1,$replace2,$str);
    }else{
        for ($i=0;$i<3;$i++){
           $replaceall[$replace1[$i]]= $replace2[$i];
        }
        
        return $replaceall;
    }
}




function rmdirR($directory,$clear=false){
    //如果给定路径末尾包含"/",先将其删除
    if(substr($directory,-1)=="/"){
        $directory=substr($directory,0,-1);
    }
    else{
        //如给出的目录不存在或者不是一个有效的目录，则返回
        if(!file_exists($directory)||!is_dir($directory)){
            return false;
        }
        //如果目录不可读，则返回
        elseif(!is_readable($directory)){
            return false;
        }else {
            //打开目录，
            $dir= opendir($directory);
            //当目录不空时，删除目录里的文件
            while(false!==($entry=readdir($dir))){
                //过滤掉表示当前目录的"."和表示父目录的".."
                if($entry!="."&&$entry!=".."){
                    $path=$directory."/".$entry;
                    //为子目录，则递归调用本函数
                    if(is_dir($path)){
                        rmdirR($path);//为文件直接删除
                    }else{
                        if(is_file($path)&&$entry!='index.php'){
                        unlink($path);
                        }
                    }
                }
            }
            //关闭目录
            closedir($dir);
            //当目录为空，不选清空目录
            if(false==$clear){
                //删除目录
                //if(!rmdir($directory)){
               //     return false;
                //}
                return true;

            }
        }
    }
}

/**
 * 获取商品相册
 * */
function get_goods_photo($goods_id,$type=0){
    if($type!=1){
    $sql="SELECT * FROM ".$GLOBALS['dtb']->table("goods_photo")." WHERE goods_id='$goods_id'";
    return $GLOBALS['db']->getAll($sql);
    }else{
    $sql="SELECT * FROM ".$GLOBALS['dtb']->table("goods_photo")." WHERE photo_id='$goods_id'"; 
    return $GLOBALS['db']->getRow($sql);   
    }
    
}

function del_goods_photo($photo_id){
    $photoinfo=get_goods_photo($goods_id,1);
    if(!empty($photoinfo)){
        if(file_exists(ROOT_PATH.$photoinfo['image_url'])){
            @unlink(ROOT_PATH.$photoinfo['image_url']);
        }
        if(file_exists(ROOT_PATH.$photoinfo['image_samllurl'])){
            @unlink(ROOT_PATH.$photoinfo['image_samllurl']);
        }
    }
    return $GLOBALS['db']->query("DELETE FROM ".$GLOBALS['dtb']->table("goods_photo")." WHERE photo_id='$photo_id'");
}
function add_goods_photo($goods_id,$image_url,$image_samllurl=''){
    if(!empty($goods_id)&&!empty($image_url)){
        $image_samllurl=empty($image_samllurl)?$image_url:trim($image_samllurl);
        $sql="INSERT INTO ".$GLOBALS['dtb']->table("goods_photo")." (goods_id,image_url,image_samllurl)  VALUES('$goods_id','$image_url','$image_samllurl')";
        return $GLOBALS['db']->query($sql);
        
    }else{
        return false;
    }    
}

function del_goods_allphoto($goods_id){
    $photoinfo=get_goods_photo($goods_id);
    if(!empty($photoinfo)){
        for ($i=0;$i<count($photoinfo);$i++){
            if(file_exists(ROOT_PATH.$photoinfo[$i]['image_url'])){
                @unlink(ROOT_PATH.$photoinfo[$i]['image_url']);
            }
            if(file_exists(ROOT_PATH.$photoinfo[$i]['image_samllurl'])){
                @unlink(ROOT_PATH.$photoinfo[$i]['image_samllurl']);
            }
        }
    }
}

function upload_arrayimg($goods_img,$images_dir='upload/goods_photo'){
    include_once(ROOT_PATH . 'include/cls_image.php');
    $image = new cls_image($GLOBALS['_CFG']['bgcolor']); 
    $image->data_dir='';  
    $php_maxsize = ini_get('upload_max_filesize');
    $htm_maxsize = '2M';
    if(!file_exists(ROOT_PATH.$images_dir)){automkdir($images_dir);}
    $imagecount=count($_FILES[$goods_img]['name']);
    
    if(!empty($imagecount)){
    for ($i=0;$i<$imagecount;$i++){
    $upflase=true;
    if (isset($_FILES[$goods_img]['error'][$i])) // php 4.2 版本才支持 error
    {
        // 最大上传文件大小
        
        // 商品图片
        if ($_FILES[$goods_img]['error'][$i] == 0)
        {   $basename=basename($_FILES[$goods_img]['name'][$i]);
            if (!$image->check_img_type($_FILES[$goods_img]['type'][$i]))
            {
                $upflase= false;
            }
        }
        elseif ($_FILES[$goods_img]['error'][$i] == 1)
        {
            $upflase= false;
        }
        elseif ($_FILES[$goods_img]['error'][$i] == 2)
        {
            $upflase= false;
        }
    }
    if($upflase){
        $uploadfile=array(
        'error'=>$_FILES[$goods_img]['error'][$i],
         'name'=>$_FILES[$goods_img]['name'][$i],
         'type'=>$_FILES[$goods_img]['type'][$i],
         'size'=>$_FILES[$goods_img]['size'][$i],   
         'tmp_name'=>$_FILES[$goods_img]['tmp_name'][$i],  
        );
        $original_img[$i]   = $image->upload_image($uploadfile,$images_dir); // 原始图片
        
        if ($original_img[$i] === false)
        {
            $upflase=  false;
        }
        if(substr($original_img[$i],0,1)=="/"){
            $original_img[$i]=substr($original_img[$i],1,strlen($original_img[$i]));
        }
        
    }
    }
    }
    return $original_img;
}

function return_url($apiname){
    if(!empty($GLOBALS['language'])){$GLOBALS['language']='zh-en';}
    return $GLOBALS['_CFG']['site_url']."respond.php?code=".$apiname."&amp;lang=".$GLOBALS['language'];
}

function check_money($order_sn,$money){
    $orderinfo=get_order_info($order_sn,1);
    if($orderinfo['money_all']==$money){
        return true;
    }else{
        return false;
    }
}

function order_paid($order_sn,$pay_status=2){
    $order_info=get_order_info($order_sn,1);
    if(!empty($order_info)){
        if($pay_status==2){
            action_order($order_sn,2,2);
        }elseif ($pay_status==1){
            action_order($order_sn,1,1);
        }
    }else{
        return false;
    }
    
}
?>
