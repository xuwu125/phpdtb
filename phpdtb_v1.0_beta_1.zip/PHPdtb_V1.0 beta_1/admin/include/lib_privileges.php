<?php
/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */
/**
 * 权限类
 *
 */
class priv 
{
    var $admin_id=0;// 登录的ID
    var $uinfo=null;// 用户的详细信息
    /**
     * 构造函数，无意义
     *
     * @return priv
     */
    function priv(){
        $this->__construct();
    }
    /**
     * 构造函数，无意义
     *
     * @return priv
     */
    function __construct(){
        $this->admin_id=$_SESSION['admin_id'];
        
        $this->getuinfo();
    }
    
    /**
     * 检查权限是否存在，不存在，就自动添加！
     *
     * @param string $action    一级权限
     * @param string $type      二级权限
     */
    function com_exists($action,$type=''){
        if(!empty($type)){
            $sql="SELECT comid FROM ".$GLOBALS['dtb']->table("privileges")." WHERE parent_index='$action' AND node_index='$type'";
        }else{
            $sql="SELECT comid FROM ".$GLOBALS['dtb']->table("privileges")." WHERE parent_index='$action' ";
        }
        $info=$GLOBALS['db']->getOne($sql);
        if(!$info){
             if(!empty($type)){
                $this->com_add($action,$type); 
             }else {
                $this->com_add($action); 
             }
        }
    }
    
    function com_add($action,$type='',$des=''){
        if(!empty($type)){
            $farray=array('parent_index'=>$action,'node_index'=>$type,'name'=>$des);
            $comexists=$this->com_get($action,'','parent_index');
            if(empty($comexists)){
                $farray2=array('parent_index'=>$action,'name'=>$des);
                $GLOBALS['db']->autoExecute($GLOBALS['dtb']->table("privileges"),$farray2);
            }
        }else{
            $farray=array('parent_index'=>$action,'name'=>$des);
        }
        return $GLOBALS['db']->autoExecute($GLOBALS['dtb']->table("privileges"),$farray);
    }

    function com_get($action,$type='',$type='parent_index'){
        if($type=='node_index'){
            $sql="SELECT * FROM ".$GLOBALS['dtb']->table("privileges")." WHERE parent_index='$action' AND node_index='$type'";
        }elseif ($type=='comid'){
            $sql="SELECT * FROM ".$GLOBALS['dtb']->table("privileges")." WHERE comid='$action' ";
        }else{
            $sql="SELECT * FROM ".$GLOBALS['dtb']->table("privileges")." WHERE parent_index='$action' ";
        }
        return $GLOBALS['db']->getRow($sql);
    }
    
    function getallcom($action=''){
        global  $db;
        if(empty($action)){
            $sql="SELECT * FROM ".$GLOBALS['dtb']->table("privileges")." WHERE node_index=''";
        }else{
            $sql="SELECT * FROM ".$GLOBALS['dtb']->table("privileges")." WHERE parent_index='$action' AND node_index!=''";
        }
        $temp=$db->getAll($sql);
        if(!empty($temp)&&empty($action)){
            $tempmax=count($temp);
            for ($i=0;$i<$tempmax;$i++){
                $temp[$i]['twocom']=$this->getallcom($temp[$i]['parent_index']);
            }
        }

        return $temp;
    }
    
    function getuinfo(){
        $sql="SELECT * FROM ".$GLOBALS['dtb']->table("adminuser")." WHERE admin_id='$this->admin_id'";
        $this->uinfo=$GLOBALS['db']->getRow($sql);
    }
    
    function check_priv($action,$type=''){
        $priv=$_SESSION['user_comp'];
        
        if(empty($this->uinfo)||empty($priv)){
            $this->getuinfo(); // 如果没有值就重新获取值。
        }
        if(empty($priv)){
            $priv=$this->uinfo['user_comp'];
        }

        if(!empty($action)&&!empty($priv)){
            if($priv=='all'){
                return true;
            }else{
                
                $privarr=explode(",",$priv);
                if(in_array($action,$privarr)&&in_array($action."->".$type,$privarr)){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
        }else {
            return false;
        }
        
    }
}
?>