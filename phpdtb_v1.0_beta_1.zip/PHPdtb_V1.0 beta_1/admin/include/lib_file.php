<?php
/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */
/**
 * 获取一个目录的扑实际大小小
 *
 * @param string $dir
 * @return int
 */
class sundir
{
    function total_size($dir)
    {
        $filepoint = opendir($dir);
        static $total_size;
        while($file = readdir($filepoint))
        {
            if($file=="."||$file=="..")continue;
            $target = "$dir/$file";
            if(is_dir($target))
            {
                $this->total_size($target);
            }
            else
            {
                $total_size+= @filesize($target);
            }
        }
        return $total_size;
    }
    function size_show($dir)
    {
        $total_size = $this->total_size($dir);
        if($total_size<"1024")
            $size_show = ($total_size*8)." byte";
        if($total_size>"1024"&&$total_size<"1048576")
            $size_show = sprintf("%1.2f",($total_size/1024))." K";
        if($total_size>"1048576")
            $size_show = sprintf("%1.2f",($total_size/1048576))." M";
        return $size_show;
    }
}
?>