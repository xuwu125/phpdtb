<?php
/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */

/*
 +------------------------------------------------------------------------------
 *  * PHPdtb 后台主体程序
 +------------------------------------------------------------------------------
 */
if (!defined('IN_SITE'))
{
    die('Hacking attempt');
}
if (__FILE__ == '')
{
    die('Fatal error code: 0');
}

/*初始化相关常量*/
define("DEBUG_MODE",true);
define("TPL_caching",false);
define("GZIP_PAGE",true);
define("GZIP_LEV",9);
define("PHPDTB_VISION","1.0.1280");
$HTTP_ACCEPT_ENCODING="gzip";

$_CFG=include('../config.inc.php');// 首先加载配置文件。
if (PHP_VERSION >= '5.1' && !empty($timezone))
{
    date_default_timezone_set($timezone);
}

$_CFG['site_url']=dirname($_SERVER['SCRIPT_NAME']);
$_CFG['site_url']=str_replace(str_replace('/',"",$_CFG['adminpath']),"",$_CFG['site_url']);

define('ROOT_PATH', str_replace($_CFG['adminpath'].'include/init.php', '', str_replace('\\', '/', __FILE__)));
define("ADMIN_PATH",ROOT_PATH.$_CFG['adminpath']);
define("ADMIN_template_PATH",ADMIN_PATH."public/template");
define("ADMIN_compile_PATH",ROOT_PATH."Tmp/compile/admin");
define("ADMIN_cache_PATH",ROOT_PATH."Tmp/cache/admin");

/*初始化相关变量 */
$action=strtolower(trim($_GET['act']));
$type=strtolower(trim($_GET['type']));
$data=strtolower(trim($_GET['data']));
$savepost=empty($_POST['save'])?"no":trim($_POST['save']);
$savepost=strtolower(trim($savepost));
$type=empty($type)?"list":trim($type);
$action=empty($action)?"login":trim($action);  // CP等于管理首页
$admin_need=array('__TPLPUBLIC__');
$admin_replace=array('public/template/');
/*加载系统文件 */
include_once(ROOT_PATH.'include/lib_main.php');
include_once(ROOT_PATH.'include/lib_common.php');
include_once(ROOT_PATH.'include/cls_mysql.php');
include_once(ROOT_PATH.'include/lib_time.php');
include_once(ROOT_PATH.'include/cls_sql_executor.php');
include_once(ROOT_PATH.'include/lib_wellsite.php');
include_once(ROOT_PATH.'include/lib_arraybase.php');
include_once(ADMIN_PATH.'include/lib_data.inc.php');
include_once(ADMIN_PATH.'include/lib_file.php');
include_once(ADMIN_PATH.'include/lib_privileges.php');
include_once(ADMIN_PATH.'include/lib_admin_common.php');
$dtb=new dtb($_CFG['db_database'],$_CFG['db_prefix']);
$db = new cls_mysql($_CFG['db_host'], $_CFG['db_user'], $_CFG['db_pwd'], $_CFG['db_database']);
$ip=real_ip();
$siteconfig=$dtb->load_config();
/* 初始化设置 */
@ini_set('memory_limit',          '32M');
@ini_set('session.cache_expire',  $siteconfig['sessionmaxtime']);
@ini_set('session.use_trans_sid', 0);
@ini_set('session.use_cookies',   1);
@ini_set('session.auto_start',    0);
@ini_set('display_errors',        1);
$language=empty($_GET['lang'])?$siteconfig['language']:trim($_GET['lang']);
$language=strtolower($language);
$languagewrite=$language;
$languagefile=ROOT_PATH ."tools/language/".$language.".php";
/*加载语言包*/
if(!file_exists($languagefile)){
    $language=$siteconfig['language'];
    
    $languagefile=LANG_PATH.$language.".php"; 
}
$LANG=require($languagefile);
if (!defined('INIT_NO_USERS'))
{
    /* 初始化session */
    include(ROOT_PATH . 'include/cls_session.php');
    $cookie_path="/";
    $sess = new cls_session($db, $dtb->table('sessions'), $dtb->table('sessions_data'));
    $sess->max_life_time=$siteconfig['sessionmaxtime'];
    define('SESS_ID', $sess->get_session_id());
    $admin_user=$_SESSION['user_name'];
    $user_comp=$_SESSION['user_comp'];
    $admin_id=$_SESSION['admin_id'];
}
// 第一次运行先建立对应的程序目录
if(!file_exists(ADMIN_compile_PATH)){
    mkdir(ADMIN_compile_PATH,0777);
}
if(!file_exists(ADMIN_template_PATH)){
    mkdir(ADMIN_cache_PATH,0777);
}

//  加载Smarty 模板引擎
if(SET_Smarty){
    $save=trim($_REQUEST['save']);
    if(GZIP_PAGE){
	    ob_start();
	}
    header('Cache-control: private');
	header("Content-Type:text/html; charset=utf-8");
    include_once ROOT_PATH.'include/SmartyTemplate/Smarty.class.php';
	$tpl = new Smarty();
    $tpl->caching = TPL_caching;
    $tpl->template_dir = ADMIN_template_PATH ;
    $tpl->compile_dir = ADMIN_compile_PATH ;
    $tpl->cache_dir = ADMIN_cache_PATH ;
    $tpl->assign('TIME',date('Y-M-D H:i:s'));
    $tpl->assign('CFG',$_CFG);
    $tpl->assign('SESSION',$_SESSION);
    $tpl->assign('action',$action);
    $tpl->assign('type',$type);
    $tpl->assign('ip',$ip);
    $tpl->assign('save',$save);
    $tpl->assign('siteconfig',$siteconfig);
}
$checknotloginarray=array('login','actlogin','loginout');
if(NOSET_AJAX){
	
    if(!in_array($action,$checknotloginarray)){
       
        if(!$dtb->check_user_login()){
            $links=array('href'=>"admin.php?act=login&gourl=".$action,"text"=>"我要重新登录");
            $dtb->sysbox("错误提示","<li>你可能还没有登录！</li><li>或者你已经登录超时！</li><li>对不起，请选择登录后再进行操作！</li>",$links);
        }/*else{
            $action="cp";
            $tpl->assign('action',$action);
        }*/
        $publinks=array('href'=>'admin.php?act=login','text'=>'返回继续操作');
        $publinks['href']=$_SERVER['HTTP_REFERER'];
        if(!empty($publinks['href'])){
            $publinks['href']="admin.php?act=setting";
        }
        $priv = new priv();
        $priv->com_exists($action,$type);
        $privlist=$priv->getallcom();
        //print_r($privlist);
        // 检查登录用户的权限
        if(!$priv->check_priv($action,$type)){
            $dtb->sysbox("错误提示 - 操作权限不足","<li>对不起，你没有此操作权限！</li><li>你可以联系管理员以解决权限不足的问题！</li><li>如果是刚加上的权限，请重新登录一次！</li>",$links);
        }
        
    }
}else{
   if($action=='login'){$action="ajaxerror";}
   header("Content-Type:text/javascript; charset=utf-8"); 
   if(!in_array($action,$checknotloginarray)){
       	include_once(ROOT_PATH."include/cls_json.php");
       	$json=new JSON();
       	
       	$result=array("error"=>"0","message"=>"","content"=>"");
        if(!$dtb->check_user_login()){
			$result=array("error"=>"1","message"=>"对不起，请先登录！");
			die($json->encode($result));
		}
	}
   
}

if($type=='edit'||$type=='add'||strpos($action,"edit_")!=-1||strpos($action,"add_")!=-1){
    include_once(ROOT_PATH."tools/fckeditor/fckeditor.php");
}
if($type=='list'||strpos($action,"manage")!=-1){
    require_once(ROOT_PATH.'include/page.class.php');
}

if(!function_exists('iconv')){
    function iconv($in_charset='GB2312',$out_chart='UTF-8',$str){
        if(file_exists("mb_convert_encoding")){
            return mb_convert_encoding($str,$in_charset,$out_chart);
        }else{
            // 如果函数都不存在就直接输出。
            return $str;
        }
    }
}


?>
