<?php
/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */
return array (
  'user_id' => '用户ID',
  'user_name' => '用户名',
  'user_pass' => '用户密码',
  'user_email' => 'E-mail',
  'user_q' => '提示问题',
  'user_a' => '密码答案',
  'user_address' => '地址',
  'user_address2' => '地址2',
  'user_province' => '所在省',
  'user_city' => '所在市',
  'user_qq' => 'QQ号',
  'user_orther' => '其它号类型：',
  'user_orther_num' => '其它号',
  'user_tel' => '电话',
  'user_mob' => '手机',
  'user_money' => '用户余额',
  'user_rank' => '会员级别',
  'user_integral' => '会员积分',
  'user_regip' => '注册IP',
  'user_regtime' => '注册时间',
  'user_lastlogintime' => '最后登录时间',
  'user_lastloginip' => '最后登录IP',
  'user_logincount' => '总登录次数',
  'user_truename' => '真实姓名',
  'user_lock' => '当前状态',
  'login_yes'=>'登录成功',
  'notlogin'=>'对不起，此操作需要先进行登录',
  'companyname'=>'公司名称',
  'come_from'=>'从何找到我们的',
);
?>
