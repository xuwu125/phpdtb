<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_freeback`;");
E_C("CREATE TABLE `well_freeback` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default 'Guest',
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `recontent` text NOT NULL,
  `tel` varchar(20) NOT NULL,
  `postcode` varchar(15) NOT NULL,
  `moblie` varchar(20) NOT NULL,
  `msn` varchar(100) NOT NULL,
  `skype` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `referer` varchar(255) NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='留言表'");
E_D("replace into `well_freeback` values('1','Guest','谢谢你们提供了这么多的商品！','谢谢你们提供了这么多的商品！这个网站真漂亮!','fdsafdsa','0467-98383983','9832423','13999999999999','xuwu125@hotmail.com','xuwu125','xuwu125@gmail.com','浙江义乌前成小区','','0');");
E_D("replace into `well_freeback` values('2','Guest','谢谢你们提供了这么多的商品！','谢谢你们提供了这么多的商品！这个网站真漂亮!','','0467-98383983','9832423','13999999999999','xuwu125@hotmail.com','xuwu125','xuwu125@gmail.com','浙江义乌前成小区','','0');");
E_D("replace into `well_freeback` values('3','Guest','谢谢你们提供了这么多的商品！','谢谢你们提供了这么多的商品！这个网站真漂亮!','谢谢！','0467-98383983','9832423','13999999999999','xuwu125@hotmail.com','xuwu125','xuwu125@gmail.com','浙江义乌前成小区','','0');");
E_D("replace into `well_freeback` values('4','dsf','sdaf','dsafdsa','','afdsa','fds','fd','saf','dsafds','afdsa','fdsafdsa','http://127.0.0.1/newwell/index.php?act=freeback&lang=zh::cn','1220897006');");
E_D("replace into `well_freeback` values('5','姓名','标题','内容','fdsafd','电话','邮编','手机','MSN','Skype','电子邮件','地址','http://127.0.0.1/newwell/index.php?act=freeback&lang=zh::cn','1220897118');");

@include("../../inc/footer.php");
?>