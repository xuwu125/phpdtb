<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_adminuser`;");
E_C("CREATE TABLE `well_adminuser` (
  `admin_id` tinyint(3) unsigned NOT NULL auto_increment,
  `user_name` varchar(24) NOT NULL,
  `user_pass` varchar(32) NOT NULL,
  `user_comp` text NOT NULL,
  `user_lastip` varchar(32) NOT NULL,
  `user_lasttime` int(10) unsigned NOT NULL,
  `user_logincount` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8");
E_D("replace into `well_adminuser` values('1','admin','21232f297a57a5a743894a0e4a801fc3','all','127.0.0.1','1223472040','2');");

@include("../../inc/footer.php");
?>