<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_goods`;");
E_C("CREATE TABLE `well_goods` (
  `goods_id` int(10) unsigned NOT NULL auto_increment,
  `goods_cnanme` varchar(255) NOT NULL,
  `goods_enname` varchar(255) NOT NULL,
  `goods_sn` varchar(255) NOT NULL,
  `goods_cate_id` int(10) unsigned NOT NULL default '0',
  `goods_encontent` text NOT NULL,
  `goods_cncontent` text NOT NULL,
  `order` int(10) unsigned NOT NULL default '0',
  `ispass` tinyint(3) unsigned NOT NULL default '0',
  `addtime` int(10) unsigned NOT NULL default '0',
  `goods_number` int(10) unsigned NOT NULL default '0',
  `mini_order` int(10) unsigned NOT NULL default '0',
  `color` varchar(100) NOT NULL,
  `meta` varchar(100) NOT NULL,
  `price` int(10) unsigned NOT NULL default '0',
  `bigimage` varchar(255) NOT NULL,
  `smallimage` varchar(255) NOT NULL,
  `goods_keywords` varchar(80) NOT NULL,
  `goods_des` varchar(200) NOT NULL,
  `goods_enkeywords` varchar(80) NOT NULL,
  `goods_endes` varchar(200) NOT NULL,
  `goods_price` decimal(8,2) unsigned NOT NULL default '0.00',
  `is_hot` tinyint(1) unsigned NOT NULL default '0',
  `goods_oldprice` decimal(8,2) unsigned NOT NULL,
  `order_count` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`goods_id`),
  KEY `goods_cate_id` (`goods_cate_id`),
  KEY `goods_cnanme` (`goods_cnanme`),
  KEY `goods_enname` (`goods_enname`),
  KEY `order` (`order`),
  KEY `ipass` (`ispass`),
  KEY `color` (`color`,`meta`,`price`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8");
E_D("replace into `well_goods` values('1','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','1','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('3','goods_cnanme','goods_enname','goods_sn','3','<p>goods_encontent</p>','<p>goods_cncontent</p>','0','1','0','10','0','2','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','keywords','des','','','1.20','1','1.00','0');");
E_D("replace into `well_goods` values('4','fdsafdsa','fdsafdsa','dsafdsa','1','<p>fdsafdsa</p>','<p>fdsafdsa</p>','0','1','0','100','0','2','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsafds','fdsafdsa','','','5.00','1','1.00','0');");
E_D("replace into `well_goods` values('5','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('6','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('7','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('9','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('10','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('11','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('12','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('13','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('14','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('15','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('16','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('17','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('18','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('19','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('20','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('21','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('22','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('23','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('24','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('25','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','1','0.00','0');");
E_D("replace into `well_goods` values('26','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','0','0.00','0');");
E_D("replace into `well_goods` values('27','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','0','0.00','0');");
E_D("replace into `well_goods` values('28','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','0','0.00','0');");
E_D("replace into `well_goods` values('29','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','0','0.00','0');");
E_D("replace into `well_goods` values('30','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','0','0.00','0');");
E_D("replace into `well_goods` values('31','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','0','0.00','0');");
E_D("replace into `well_goods` values('32','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','0','0.00','0');");
E_D("replace into `well_goods` values('33','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','0','0.00','0');");
E_D("replace into `well_goods` values('34','afdsa','fdsafds','fdsafdsafdsa','2','<p>fdsafdsafdsafdsa</p>','<p>fdasfdsafdsafdsafdssafdsa</p>','0','1','0','10','0','2,3,1','1','1','upload/goods/big/1220712966442636456.gif','upload/goods/small/1220712966669581503.gif','fdsaafdsafdsa','fdsafdsa','','','1.00','0','0.00','0');");

@include("../../inc/footer.php");
?>