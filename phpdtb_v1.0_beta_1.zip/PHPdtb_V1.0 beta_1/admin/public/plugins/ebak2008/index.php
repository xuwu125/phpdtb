<?php
require("class/connect.php");
include("class/config.php");
include("class/functions.php");
include("lang/dbchar.php");
require LoadAdminTemp('eindex.php');
?>