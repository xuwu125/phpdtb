/**
* jQuery Api document
* @author xuwu125<xuwu125@gmail.com>
*/
// 定义变量
var formname="";
var ajax_id="";

// 函数开始
function Winobj(){
	var Winobjs = {
		"clientWidth": document.body.clientWidth,/*网页可见区域宽*/
		"clientHeight": document.body.clientHeight,/*网页可见区域高*/
		"offsetWidth": document.body.offsetWidth,/*网页可见区域宽(包括边线的宽)*/
		"offsetHeight": document.body.offsetHeight,/*网页可见区域高(包括边线的高)*/
		"scrollWidth": document.body.scrollWidth,/*网页正文全文宽*/
		"scrollHeight": document.body.scrollHeight,/*网页正文全文高*/
		"scrollTop": document.body.scrollTop,/*网页被卷去的高*/
		"scrollLeft": document.body.scrollLeft,/*网页被卷去的左*/
		"screenTop": window.screenTop,/*网页正文部分上*/
		"screenLeft": window.screenLeft,/*网页正文部分左*/
		"screen_height": window.screen.height,/*屏幕分辨率的高*/
		"screen_width": window.screen.width,/*屏幕分辨率的宽*/
		"availHeight": window.screen.availHeight,/*网页被卷去的左*/
		"availWidth": window.screen.availWidth /*网页被卷去的左*/
	};
	return Winobjs;
}
function replaceAll(str,need,rep){
	while(str.indexOf(need)!=-1){
	str.replace(need,rep);
	}
	return str;
}
function $$(id){return document.getElementById(id);}
function strleft(str,len){
	if(str.length>=len){
		return str.substring(0,len);
	}else{
		return str;
	}
}

function jsCopy(str,type)   
{   
  	clipboardData.setData('text',str);
  	if(type==1){
	alert("恭喜你，复制成功！\n内容如下：\n"+str);
	}
}

/// 自动选择菜单函数
function AutosetSel(idname,str){
var idx=document.getElementById(idname);
if(idx){
	for(var i=0;i<idx.options.length;i++){                
	if (idx.options[i].value==str){
	idx.selectedIndex=i;
	break;
	}
	}   
}
}

function set_checkbox(names,arrs){
	$("input[@name='"+names+"']").each(
		function(i){
			if($(this).attr("type")=="checkbox"){
				if(in_array($(this).val(),arrs)){
					$(this).attr('checked',true);
				}
			}
			
		}
	);
}

function in_array(needs,arr){
	var t=false;
	for(var i=0;i<arr.length;i++){
		if(arr[i]==needs){
			return true;
		}
	}
	return t;
}


function show_message(id){
	$(function(){
		var d=$("#"+id);
		if(d){
			$("#"+id+"_title").toggle(function(){
				$("#"+id+"_content").slideDown("slow");								 
			},function(){
				$("#"+id+"_content").slideUp("slow");								 
			});
			
			d.show("slow");
		}
	});
}
function chekemail(temail) {  
 var pattern = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;  
	 if(pattern.test(temail)) {  
	  return true;  
	 } 
}

function go_url(url){
	location.href=url;return false;
}
function dellink(){
	if(!confirm('你确定执行此操作吗？')){return false;}
	
}

function to2bits(flt) { 
	if(parseFloat(flt) == flt){
		return Math.round(flt * 100) / 100; 
	}else{ 
		return 0;
	}
} 

function set_tables(id){
	if(id&&id!=="undefined"){
		var tables="#"+id;
	}else{
		var tables="";
	}
	$(tables+" tr").each(function(i){
	if(this.title!='skip'){
		this.style.backgroundColor=['#F5F5F5','#FFFFFF'][i%2];
		$(this).hover(function(){
			if(this.style.backgroundColor.toLowerCase()=='#F5F5F5'.toLowerCase()){
				$(this).attr('rel','no');
			}
			this.style.backgroundColor='#C1FC91';
			
		},
		function(){
			if($(this).attr('rel')!='no'){
			this.style.backgroundColor='#FFFFFF';
			}else{this.style.backgroundColor='#F5F5F5';
			}
		}); 
		}
	});
}
$(document).ready(function(){
	//set_tables();
	$(".dellink").click(function(){
		if(!confirm('你确定执行此删除操作吗？')){return false;}
	});
	$("input").each(function(){
		var types=$(this).attr("type");
		if(types=="text"||types=="password"){
			$(this).hover(function(){
				$(this).css({"border":'1px solid #66CC00'});
			},
			function(){
				$(this).css({"border":'1px solid #666666'});
			});
		}
	});
	$("textarea").hover(function(){
				$(this).css({"border":'1px solid #66CC00'});
			},
			function(){
				$(this).css({"border":'1px solid #666666'});
			});
	$("input").each(function(){
		var types=$(this).attr("type");
		if(types=="text"||types=="password"){
			$(this).click(function(){
				$(this).css({"border":'1px solid #66CC00'});
				$(this).blur(function(){
					$(this).css({"border":'1px solid #666666'});
				});
			});
		}
	});
	$("textarea").click(function(){
		$(this).css({"border":'1px solid #66CC00'});
		$(this).blur(function(){
			$(this).css({"border":'1px solid #666666'});
		});
	});
	/*Add ajax action*/
    $("#ajax_message").ajaxComplete(function(){
		$("#ajax_message").html("Loaded.").hide("slow");ajax_id="";
	});
	$("#ajax_message").ajaxError(function(request, settings){
		Error_box(request);
	});
	$("#ajax_message").ajaxSend(function(){
		$("#ajax_message").html("loading...").show(0);
	});
});

function add_cart(goods_id){
	if(goods_id>0){
		if(goods_id==ajax_id){return false;}
		$("#ajax_message").html("Loading...").show("slow");
		ajax_id=goods_id;$("#ajax_messagebox").hide("slow");
		$.get("ajax.php?act=add_cart&goods_id="+goods_id+"&rnd="+Round(),function(data){
			if(data!="OK"&&data!="ERR"){
				return Error_box(data);
			}else{
				location.href="index.php?act=cart&lang="+$("#ajax_message").attr("rel")+"&goods_id="+ajax_id;
			}
		});
		
	}else{
		return false;
	}
}

function Round(){
	return Math.round(Math.random()*10000);
}
function Error_box(request){
	$("#ajax_messagebox").html("<dt onclick=\"$('#ajax_messagebox').hide('slow');\">"+ajax_messagebox_suser+"</dt>\n"+request).show("slow");ajax_id="";
	window.setTimeout("$('#ajax_messagebox').hide('slow');",20000);
	return false;
}

function cart_action(){
	$("#cartlist").find("tr").each(function(){
		if($(this).attr("class")!="skip"){
		$(this).find("td").each(function(i){
			if(i==7){
				$(this).find("input").each(function(ii){
					if(ii==0){
						$(this).click(function(){
							$(this).parents("tr").find("td").each(function(vi){
								if(vi==5){
									if($(this).find("input").val()<$(this).find("input").attr("data")){
										alert(goods_nominorder+":"+$(this).find("input").attr("data")+"\t");
										return false;
									}
								}
							});
							var goods_id=$(this).attr("data");
							if(ajax_id==goods_id){return false;}
							$(this).attr("disabled",true);
							$("#ajax_messagebox").hide("slow");
							ajax_id=goods_id;
							var sendurl="ajax.php?act=update_cart&goods_id="+goods_id+"&count="+parseInt($("#count_"+goods_id).val())+"&rnd="+Round();
							$.get(sendurl,
								function(data){
								$("#update_"+ajax_id).attr("disabled",false);
								if(data!="ERR"&&data!="OK"){
									return Error_box(data);
								}
								if(data!="OK"){
									return Error_box(action_failure);
								}else{
									update_cart();
									Error_box(action_success);
								}
							});
							
							
						});
					}
					if(ii==1){
						$(this).click(function(){
							var goods_id=$(this).prev().attr("data");
							if(ajax_id==goods_id){return false;}
							$(this).attr("disabled",true);
							$("#ajax_messagebox").hide("slow");
							ajax_id=goods_id;
							$.get("ajax.php?act=del_cart&goods_id="+goods_id+"&rnd="+Round(),
								function(data){
								$("#update_"+ajax_id).attr("disabled",false);
								if(data!="ERR"&&data!="OK"){
									return Error_box(data);
								}
								if(data!="OK"){
									return Error_box(action_failure);
								}else{
									Table_del_row("cartlist","cart_"+ajax_id);
									update_cart();
									Error_box(action_success);
								}
							});
							
						});
					}
				});
			}
		});
		}
	});
}

function update_cart(){
	var goods_price=0;
	var goods_count=0;
	var all_count=0;
	var all_amount=0;
	$("#cartlist").find("tr").each(function(){
		if($(this).attr("class")!="skip"){
		
		$(this).find("td").each(function(i){
			if(i==3){
				goods_price=parseFloat($(this).text());
			}
			if(i==5){
				goods_count=parseInt($(this).find("input").val());
			}
		});
		var alam=to2bits(parseFloat(goods_price*goods_count),2);
		//alert($(this).find("td").eq(4));
		$(this).find("td").eq(4).html(alam);
		all_count+=goods_count;
		all_amount+=alam;
		goods_price=0;goods_count=0;
		}
	});
	$("#all_amount").text(all_amount);
	$("#goods_count").text(all_count);
}


function Table_del_row(tableid,itemid){
	var mytable = document.getElementById(tableid);
	var n=mytable.rows.length;
	if( n<=2 )
 	{
		return;
 	}
	for(i=1;i < n;i++)
	{
		if(mytable.rows[i].id == itemid){
			mytable.deleteRow(i);
	//		rd_count(504,1,7);
	//		mytable.width-=200;
	//		toptable.width-=200;
			return;
		}
	}
}

function show_goods_pic(id,url,width,height){
	var obj=$("#"+id);
	if(obj){
			var html=new Array('<img src="'+url+'" width="'+width+'" height="'+height+'" class="show_goods_pic"  border="0" align="absmiddle" />','<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" id="photoimg"  width="'+width+'" height="'+height+'" codebase="http://fpdownload.macromedia.com/get/flashplayer/current/swflash.cab"><param name="movie" value="tools/flash/photoimg.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#869ca7" /><param name="allowFullScreen" value="true" /><param name="FlashVars" value="imageurl=../../'+url+'&info=no&max_height='+height+'&max_width='+width+'&screenfull=yes" /><embed src="tools/flash/photoimg.swf" quality="high" bgcolor="#869ca7" width="'+width+'" height="'+height+'" name="photoimg"  align="middle" play="true" loop="false"  quality="high" allowFullScreen="true" FlashVars="imageurl=../../'+url+'&info=no&max_height='+height+'&max_width='+width+'&screenfull=yes" pluginspage="http://www.adobe.com/go/getflashplayer"></embed></object>');
			obj.html(html[obj.attr("rel")]);
	}
}
