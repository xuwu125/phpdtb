<?php
/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */
/**
 * ========================================================================
 * Appname:     PHPdtb 开源网站系统install
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Filename:    install.php
 * ========================================================================
 * */

define('IN_SITE',true);
define('ROOT_PATH', str_replace('install.php', '', str_replace('\\', '/', __FILE__)));
define('TEMPPATH',ROOT_PATH."Tmp/orthers/");
$_CFG=include(ROOT_PATH.'config.inc.php');
header("Content-Type:text/html; charset=utf-8");
include_once(ROOT_PATH.'include/lib_main.php');
include_once(ROOT_PATH.'include/lib_common.php');
include_once(ROOT_PATH.'include/cls_mysql.php');
include_once(ROOT_PATH.'include/lib_wellsite.php');
$ip=real_ip();
if (PHP_VERSION >= '5.1' && !empty($timezone))
{
    date_default_timezone_set($timezone);
}

$install_lockfile="./tools/install.lock";
$sqlfile=$_CFG['db_update']."db.sql";
$setupcheck=true;
@ob_start();
echo '<style type="text/css">
<!--
*{font-size: 12px;}
body {font-family: Arial, Helvetica, sans-serif;line-height: 20px;color: #000000;text-decoration: none; margin:15px;}
table,tr,td{font-size: 12px;}
a{ color:#0000FF;}
a:hover{ color:#6666CC;}
b{ font:Verdana, Arial, Helvetica, sans-serif; color:#FF0000}
cite{ color:#009900; font-style:normal}
-->
</style>';
if(file_exists($install_lockfile)){
    die("对不起，你已经安装过了，不能再次安装。<br />你现在可以<br />\n1.<a href='index.php'>访问首页</a><br />\n 2.删除 $install_lockfile 文件后，重新安装。");
}else{
    $setup=empty($_GET['setup'])?0:intval($_GET['setup']);
    if(!empty($setup)){ 
    echo "<title>正在进行第 $setup 步安装...</title><h2>正在进行第 $setup 步安装...</h2><hr size=1>\n";
    }
    //第一步先提示进行安装。
    if(empty($setup)){ 
        $filec=file_get_contents(ROOT_PATH."tools/db/setup.html");
        ob_end_clean();
		die($filec);
    }elseif($setup==1){
    	
        $html='<table width="70%" border="0" align="center" cellpadding="4" cellspacing="1" bgcolor="#CCCCCC">
  <form id="form1" name="form1" method="post" action="?setup=2"><tr>
    <th colspan="3" bgcolor="#FFFFFF">数据库等信息安装设置</th>
  </tr>
  <tr>
    <th height="25" bgcolor="#FFFFFF"><font size="2">数据库服务器地址：</font></th>
    <td bgcolor="#FFFFFF">
      <font size="2">
      <label>
        <input name="db_host" type="text" id="db_host" value="'.$_CFG['db_host'].'" />
        </label>
      </font></td>
    <td bgcolor="#FFFFFF"><font color="#999999" size="2">&nbsp;* 服务器的地址，一般用localhost</font></td>
  </tr>
  <tr>
    <th height="25" bgcolor="#FFFFFF"><font size="2">数据库名称：</font></th>
    <td bgcolor="#FFFFFF"><font size="2">
      <input type="text" name="db_database" id="db_database" value="'.$_CFG['db_database'].'" />
    </font></td>
    <td bgcolor="#FFFFFF"><font color="#999999" size="2">&nbsp;* 数据库的名称，请填写正确。</font></td>
  </tr>
  <tr>
    <th height="25" bgcolor="#FFFFFF"><font size="2">数据库用户名：</font></th>
    <td bgcolor="#FFFFFF"><font size="2">
      <input type="text" name="db_user" id="db_user" value="'.$_CFG['db_user'].'" />
    </font></td>
    <td bgcolor="#FFFFFF"><font color="#999999" size="2">&nbsp;* 请正确填写，否则无法正常安装。</font></td>
  </tr>
  <tr>
    <th height="25" bgcolor="#FFFFFF"><font size="2">数据库密码：</font></th>
    <td bgcolor="#FFFFFF"><font size="2">
      <input type="text" name="db_pwd" id="db_pwd" value="'.$_CFG['db_pwd'].'" />
    </font></td>
    <td bgcolor="#FFFFFF"><font color="#999999" size="2">&nbsp;* 请正确填写，错误的密码将无法安装成功。</font></td>
  </tr>
  <tr>
    <th height="25" bgcolor="#FFFFFF"><font size="2">表名前缀：</font></th>
    <td bgcolor="#FFFFFF"><font size="2">
      <input type="text" name="db_prefix" id="db_prefix" value="'.$_CFG['db_prefix'].'" />
    </font></td>
    <td bgcolor="#FFFFFF"><font color="#999999" size="2">&nbsp;* 为了区别和别的程序之间表名，请输入一个前缀名。</font></td>
  </tr>
  <tr>
    <th height="25" bgcolor="#FFFFFF"><font size="2">后台目录：</font></th>
    <td bgcolor="#FFFFFF"><font size="2">
      <input type="text" name="adminpath" id="adminpath" value="'.$_CFG['adminpath'].'" />
    </font></td>
    <td bgcolor="#FFFFFF"><font color="#999999" size="2">&nbsp;* 默认是admin 当然也可以自行更改。</font></td>
  </tr>
  <tr>
    <td height="100" colspan="3" align="center" bgcolor="#FFFFFF">
      <font size="2">
<input type="submit" name="button" id="button" value="马上安装" />
&nbsp;&nbsp;&nbsp;&nbsp; 
      <input type="button" name="button2" id="button2" value="取消关闭" onclick="window.close();" /> *以上项目都不可以为空   
      </font></td>
  </tr></form>
</table>';
        echo($html);
        addlogfile();
    }elseif ($setup==2){
        $dbinfo=array(
                'db_host'=>$_POST['db_host'],
                'db_user'=>$_POST['db_user'],
                'db_pwd'=>$_POST['db_pwd'],
                'db_database'=>$_POST['db_database'],
                'db_prefix'=>$_POST['db_prefix'],
                'db_update'=>$_CFG['db_update'],
                'adminpath'=>$_POST['adminpath'],
                );
          echo "\n<br />开始检查新配置数据！\n<br />";
          echo "服务器系统版本：".PHP_OS."(<b>推荐使用 Linux</b>)<br />\n".
          		"PHP版本：".PHP_VERSION."(<b>推荐使用PHP 5.2.8</b>)<br />\n";
          		if(substr(PHP_VERSION,0,3)<5.0){
          			echo "对不起，您的服务器PHP版本太低了，无法继续安装和正常使用。<br />解决方案：请升级PHP版本到5.0以上。"; $setupcheck=false;
          		}
          $h="所有配置数据输入<cite>正确</cite>\n<br />";
          foreach ($dbinfo as $key =>$value){
              if(empty($dbinfo[$key])){
                  $h="配置[ $key ]数据<b>不可为空</b>.\n<br />";
                  $setupcheck=false;
              }
          }
          echo $h;
          $filelist=array("Tmp",'Tmp/cache','Tmp/orthers','Tmp/cache','Tmp/caches','Tmp/compile','Tmp/logs','Tmp/cookie_path',
                'tools/code','tools/code/tmp','tools/db','tools/backup','tools/language','upload','upload/edit_upload',
                'upload/goods','upload/goods/big','upload/goods/small','upload/class_img');
          echo "\n<br />开始检查文件权限！\n<br />";
          foreach ($filelist as $filedir){
              echo "正在检查 ./$filedir ... 结果:";
              if(!file_exists(ROOT_PATH.$filedir)){
                  echo "文件不存在，创建目录[ ./$filedir ] ";
                  if(mkdir(ROOT_PATH.$filedir,0777)){
                      echo " 成功 ";
                  }else{
                      echo " <b>失败</b> ";$setupcheck=false;
                  }
              }else{
                  echo " 目录存在 ";
              }
              $lok=is_writable(ROOT_PATH.$filedir);
              if($lok){
                  echo " 可写入，文件权限<cite>正确</cite>。<br />\n";
              }else{
                   echo " 文件权限不正确,无法写入,正在改变权限...";
                   $wfile=chmod(ROOT_PATH.$filedir,0777);
                    if($wfile){
                        echo " 修改权限<cite>成功</cite>！<br />\n";
                    }else{
                        echo " 修改权限<b>失败</b>！请用FTP软件手工修改<br />\n";$setupcheck=false;
                    }
              }
          }
          $dbinfofilename="<?php\nreturn ".var_export($dbinfo,true)."\n//Install config temp file.\n//The file write at time:".date("Y-m-d H:i:s",time())."\n?>";
          $cache=temp_file("config.tmp",'w',$dbinfofilename);
          if($cache){
              echo "数据库等配置写入缓存<cite>成功</cite>！\n";
          }else{
              echo("数据库等配置写入缓存<b>失败</b>！\n");$setupcheck=false;
          }
          if($setupcheck==false){
              echo("<hr size='1' />\n对不起，请检查以上错误,并修复，安装程序已停止！<br />\n<a href='?setup=1'>上一步</a> &nbsp;");
          }else{
              echo "<hr size='1' />\n<p>恭喜你，所有检查均已经通过，请点击<cite>下一步</cite>继续安装。<br />\n".
                    "<a href='?setup=1'>上一步</a> &nbsp; \n<a href='?setup=3'>下一步</a></p>";
          }
          addlogfile();
    }elseif ($setup==3){
    	
        $dbconfig=temp_file("config.tmp",'r');
        echo "正在载入配置文件...<br />\n";
        $dbexist=temp_file("config.tmp",'e');
        echo $dbexist?"<cite>文件存在</cite>":"<b>文件不存在</b>";
        if(empty($dbconfig)){
            echo "<br />对不起，配置参数<b>错误</b>，请返回重新配置。<br />\n";
            $setupcheck=false;
        }else{
            echo "<br />恭喜你，配置参数<cite>成功</cite>。<br />\n";
            $db_config=temp_file("config.tmp",'l');
            echo "配置内容如下：<div>\n";
            highlight_string($dbconfig);
            echo "</div>\n";
        }
        
        echo "检查数据库SQL文件 $sqlfile 结果:";
        if(file_exists(ROOT_PATH.$sqlfile)){
            echo " <cite>存在</cite>。<br />\n";
        }else{
            echo " <b>不存在</b>,安装将<b>停止</b>。<br />\n";$setupcheck=false;
        }
        
        $sqlcon=splitsql(ROOT_PATH.$sqlfile);
        if(empty($sqlcon)||count($sqlcon)<10){
        	die("<hr size='1' />\n对不起，请检查以上错误,并修复，安装程序已停止！<br />\n错误原因:安装SQL文件错误，请检查。<br />\n<a href='?setup=2'>上一步</a> &nbsp;");
        }
        $sqlcount=count($sqlcon);
        echo "共要执行 $sqlcount 条SQL语句,每句中间会暂停1秒。<br />\n";
        echo "正在检测数据库链接是否正确...";
        $dbcheck=@mysql_connect($db_config['db_host'], $db_config['db_user'], $db_config['db_pwd']);
        $selectdb=@mysql_select_db($db_config['db_database'],$dbcheck);
        if($dbcheck&&$selectdb){
            echo "数据库链接<b>正确</b>，安装将<cite>继续</cite>。<br />\n";
            mysql_close($dbcheck);
        }else{
            echo "数据库链接<b>不正确</b>，安装将<b>停止</b>。<br />\n";$setupcheck=false;
        }
        echo "正在生成数据库SQL缓存...";
        for ($i=1;$i<$sqlcount;$i++){
            $sqlcon[$i]=str_replace("`phpdtb_","`".$db_config['db_prefix'],$sqlcon[$i]);
        }
        echo " 生成结束.<br />\n";
        echo "写入数据库SQL缓存...";//stripslashes
        $sqlwirtecontent="<?php\n//This is temp install sql file \nreturn ".var_export($sqlcon,true)."\n?>";
        $sqlwirte=temp_file('install_sql.tmp','w',$sqlwirtecontent);
        if($sqlwirte){
            echo "写入缓存成功，安装将<cite>继续</cite>。<br />\n";
        }else{
            echo "写入缓存失败，安装将<b>停止</b>。<br />\n";$setupcheck=false;
        }
        //$db = cls_mysql($dbconfig['db_host'], $dbconfig['db_user'], $dbconfig['db_pwd'], $dbconfig['db_database']);
        if($setupcheck==false){
              echo("<hr size='1' />\n对不起，请检查以上错误,并修复，安装程序已停止！<br />\n<a href='?setup=2'>上一步</a> &nbsp;");
          }else{
              echo "<hr size='1' />\n<p>恭喜你，所有检查均已经通过，请点击<cite>下一步</cite>继续安装。<br />\n".
                    "<a href='?setup=2'>上一步</a> &nbsp; \n<a href='?setup=4'>下一步</a></p>";
          }
         
          
         addlogfile();
    }elseif ($setup==4){
        $sqltmp=temp_file('install_sql.tmp','l');
        //print_r($sqltmp);
        $db_config=temp_file("config.tmp",'l');
        echo "开始执行数据库安装....<br />\n";
        $db =new cls_mysql($db_config['db_host'], $db_config['db_user'], $db_config['db_pwd'], $db_config['db_database']);
        if(!$db){$setupcheck=false;
            echo "对不起，数据库链接<b>失败</b>，请返回检查。";
        }else{
            echo "恭喜你，数据库链接<cite>成功</cite>，程序将继续执行。<br />\n下面的数据可能要花掉一点时间，请等待...<br />\n";
        }
        if($setupcheck){
            $sqlcount=count($sqltmp);
            for ($i=1;$i<=$sqlcount;$i++){
            //$dboryes=autoexecute_sql($sqlcount[$i]);
            $dbinfoarr=explode("--",$sqltmp[$i]);
            echo "\n<br />正在创建->".$dbinfoarr[2]." ->".str_replace("导出","导入",$dbinfoarr[5]);
            $sqlone=explode(";\n\n--",$sqltmp[$i]);
            $dbinfo=autoexecute_sql($sqlone[0]);
            if(!empty($sqlone[1])){
                $dbinfo=autoexecute_sql($sqlone[1]);
            }
            unset($dbinfoarr);
                if($dbinfo){
                    echo " 结果：<cite>成功</cite>";
                }else{
                    echo " 结果：<b>失败</b>";
                    $setupcheck=false;
                }
            }
        }
        if($setupcheck==false){
              echo("<hr size='1' />\n对不起，请检查以上错误,并修复，安装程序已停止！<br />\n<a href='?setup=2'>上一步</a> &nbsp;");
          }else{
              echo "<hr size='1' />\n<p>恭喜你，所有检查均已经通过，请点击<cite>下一步</cite>继续安装。<br />\n".
                    "<a href='?setup=3'>上一步</a> &nbsp; \n<a href='?setup=5'>下一步</a></p>";
          }
         
          
         addlogfile();
    }elseif ($setup==5){
        $db_config=temp_file("config.tmp",'l');
        echo "<br />\n正在进行配置文件...";
        $configincfile=file_get_contents(ROOT_PATH."config.inc.php");
        $configinc=explode("return",$configincfile);
        $configinccontnet=str_replace("?>","",$configinc[1]);
        temp_file("confignew.tmp",'w',"<?php\n//new config temp file\nreturn $configinccontnet\n?>");
        $newconfig=temp_file("confignew.tmp",'l');
        foreach ($newconfig as $key=>$value){
            if(!empty($db_config[$key])){
                $newconfig[$key]=$db_config[$key];
            }
        }
        echo "<br />\n重新生成配置文件<cite>成功</cite>。";
        $newconfigfile=$configinc[0]."\n//time add:".date("Y-m-d H:i:s",time())."\nreturn ".var_export($db_config,true).";\n\n?>";
        $tfile=@file_put_contents(ROOT_PATH."config.inc.php",$newconfigfile);
        if($tfile){
            echo "<br />\n更新配置文件<cite>成功</cite>。";
        }else{
            echo "<br />\n更新配置文件<b>失败</b>。请<a href='?setup=0'>重新安装</a>。";
        }
        echo "<br />\n正在清理安装产生的临时文件(注意，./Tmp/orthers目录下的安装日志文件*.log 是不会删除的，如有需要请手工删除)。";
        $tempfile=array("config.tmp","confignew.tmp","install_sql.tmp");
        foreach ($tempfile as $delf){
            temp_file($delf,'d');
            echo "<br />\n正在清理文件 $delf ...";
        }
        echo "<br />\n正在清理临时文件完毕...";
        @touch($install_lockfile);
        @file_put_contents($install_lockfile,"Install time for autoinstall :".date("Y-m-d H:i:s",time())."\nunix_smtptime:".time());
        echo "<br />\n安装程序已经锁定<cite>成功</cite>。";
        echo "<hr size=1>安装已经全部完成。<br />\n";
        echo "文件已经鍞定，安装工作全部结束。<br />\n你现在可以 1.<a href='index.php' target='_blank'>访问首页</a> 2.访问后台 <a target='_blank' href='".$db_config['adminpath']."admin.php'>访问后台</a>";
        addlogfile();
    }
}

    
function temp_file($filename,$flag,$data=''){
    $flag=strtolower($flag);
    if(empty($flag)){$flag="w";}
    switch ($flag){
        case "w":return @file_put_contents(TEMPPATH.$filename,$data);break;// 写入文件
        case "r":return @file_get_contents(TEMPPATH.$filename);break;// 读取文件
        case "l":return require(TEMPPATH.$filename);break;// 读取文件
        case "t":return @touch(TEMPPATH.$filename);break;//建立空文件。
        case "m":return @mkdir(TEMPPATH.$filename,0777);break;//建立目录。
        case "d":return @unlink(TEMPPATH.$filename);break;// 删除文件
        case "e":return @file_exists(TEMPPATH.$filename);break;// 删除文件
        case 'a':return deldirfile(TEMPPATH.$filename);break;// 清除所有缓存
        case "c";return is_writable($filename);break;// 检查文件权限
        default:return false; break;
    }
}
function deldirfile($dir){
    if(file_exists($dir)){
        foreach (glob($dir) as $file){
            $f=$dir.$file;
            @unlink($f);
        }
    }
}
function addlogfile(){
    $filelogs=ob_get_contents();
    
    @ob_end_flush();
    $setup=$_GET['setup'];
    $filelogs="The log file of install\ntime:".date("Y-m-d H:i:s",time())."\nInstall setup:".$setup."\n\n".$filelogs;
    temp_file("install_logs_".$setup."_".time().".log",'w',$filelogs);die();
}
function splitsql($file){
    $files=@file_get_contents($file);
    if(empty($files)){
        return false;
    }else{
        $filesarr=explode("-- --------------------------------------------------------",$files);
        unset($filesarr[0]); // 去掉最开始的没有用的信息。
        return $filesarr;
    }
}



function autoexecute_sql($sql){
    if(empty($sql)){return false;}
    $sqltype=split(" ",$sql);
    if(strtoupper($sqltype[0])=="SELECT"){
        if(!in_array("LIMIT",$sqltype)&&!in_array("limit",$sqltype)){
            $sql.=" LIMIT 0,30";
        }
        return $GLOBALS['db']->getAll($sql);
    }else{
        return $GLOBALS['db']->query($sql);
    }
}
?>