<?php
/*
Date:2008-09-8  15:46
Author:xw-09@163.com 
*/

if (!defined('IN_SITE')){
header("Content-Type:text/html; charset=utf-8");
printf("对不起，此文件禁止访问.<br />\nSorry, this document prohibited visit.");
exit();
}
?>