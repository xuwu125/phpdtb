<?php
/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */
/*
 +------------------------------------------------------------------------------
 * PHPdtb 前台共用核心文件 
 +------------------------------------------------------------------------------
 */
if (!defined('IN_SITE'))
{
    die('Hacking attempt');
}
if (__FILE__ == '')
{
    die('Fatal error code: 0');
}
$action=strtolower(trim($_REQUEST['act']));
$action=empty($action)?"index":trim($action);
$savepost=empty($_POST['save'])?"no":strtolower(trim($_POST['save']));
define("DEBUG_MODE",true);
define("GZIP_PAGE",true);
define("GZIP_LEV",9);
$HTTP_ACCEPT_ENCODING="gzip";
define('ROOT_PATH', str_replace('include/init.php', '', str_replace('\\', '/', __FILE__)));
define('LANG_PATH',ROOT_PATH ."tools/language/");
$_CFG=include(ROOT_PATH.'config.inc.php');
$_CFG['site_url']=  "http://".$_SERVER ['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
if(substr($_CFG['site_url'],strlen($_CFG['site_url'])-1,1)!='/'){$_CFG['site_url'].='/';}

if (PHP_VERSION >= '5.1' && !empty($timezone))
{
    date_default_timezone_set($timezone);
}

include_once(ROOT_PATH.'include/lib_main.php');
include_once(ROOT_PATH.'include/lib_common.php');
include_once(ROOT_PATH.'include/cls_mysql.php');
include_once(ROOT_PATH.'include/lib_wellsite.php');

$dtb=new dtb($_CFG['db_database'],$_CFG['db_prefix']);
$db = new cls_mysql($_CFG['db_host'], $_CFG['db_user'], $_CFG['db_pwd'], $_CFG['db_database']);
/*设定数据库缓存 */
if(!empty($siteconfig['max_cache_time'])){
    $db->max_cache_time=$siteconfig['max_cache_time'];
    if(!empty($siteconfig['cache_data_dir'])){
        $db->cache_data_dir=$siteconfig['cache_data_dir'];
        automkdir($db->cache_data_dir);
    }
}
$ip=real_ip();
$siteconfig=$dtb->load_config();
$language=empty($_GET['lang'])?$siteconfig['language']:trim($_GET['lang']);
$language=strtolower($language);
$languagewrite=$language;
$param['act']=$action;

$languagefile=ROOT_PATH ."tools/language/".$language.".php";
@ini_set('memory_limit',          '32M');
@ini_set('session.cache_expire',  $siteconfig['sessionmaxtime']);
@ini_set('session.use_trans_sid', 0);
@ini_set('session.use_cookies',   1);
@ini_set('session.auto_start',    0);
@ini_set('display_errors',        1);
if (!defined('INIT_NO_USERS'))
{
    /* 初始化session */
    include(ROOT_PATH . 'include/cls_session.php');   
    $sess = new cls_session($db, $dtb->table('sessions'), $dtb->table('sessions_data'));
    $sess->max_life_time=$siteconfig['sessionmaxtime'];
    $sess->session_cookie_path=$siteconfig['session_cookie_path'];
    $sess->session_cookie_domain=$siteconfig['session_cookie_domain'];
    define('SESS_ID', $sess->get_session_id());
}
/*加载语言包*/
if(!file_exists($languagefile)){
    $language=$siteconfig['language'];
    
    $languagefile=LANG_PATH.$language.".php"; 
}
$siteconfig['public']="template/".$siteconfig['template']."/".$language."/";
$LANG=require($languagefile);
//  加载Smarty 模板引擎
if(SET_Smarty){
    if(GZIP_PAGE){
	    ob_start();
	}
    header('Cache-control: private');
	header("Content-Type:text/html; charset=utf-8");
	
	if(empty($_GET['act'])){
	   $_GET['act']=$action;
	   $_GET['lang']=$language;
	}
	$cache_id=implode("-",$_GET);
    include_once ROOT_PATH.'include/SmartyTemplate/Smarty.class.php';
	$tpl = new Smarty();
    /* 加载系统类的数组定义数据	*/
	include_once(ROOT_PATH.'include/lib_arraybase.php');
    /* 设定是否使用缓存 	*/
    
	if(!empty($siteconfig['tpl_cache'])){
        $tpl->caching = true;
        $tpl->cache_lifetime = $siteconfig['tpl_cachetime'];
	}
	if(empty($siteconfig['template'])){$siteconfig['template']="default";}
    $tpl->template_dir = ROOT_PATH."template/".$siteconfig['template']."/".$language;
    $tpl->compile_dir = ROOT_PATH."Tmp/compile/".$siteconfig['template']."/".$language ;
    $tpl->cache_dir = ROOT_PATH."Tmp/cache/".$siteconfig['template']."/".$language;
    /* 有可能目录不存在，则自动建立 。  */
    automkdir(ROOT_PATH."Tmp/compile/".$siteconfig['template']);
    automkdir(ROOT_PATH."Tmp/cache/".$siteconfig['template']);
    automkdir($tpl->compile_dir);
    automkdir($tpl->cache_dir);
    
    $tpl->assign('TIME',date('Y-M-D H:i:s'),time());
    $tpl->assign('CFG',$_CFG);
    $tpl->assign('LANG',$LANG);
    $tpl->assign('language',$language);
    $tpl->assign('action',$action);
    $tpl->assign('siteconfig',$siteconfig);
    $tpl->assign('_SERVER',$_SERVER);

}
/**
 * 加载所有插件
 * 自动加载。目标为：tools/plugins
 */
if(!empty($siteconfig['plugins_onoff'])){
    foreach (glob(ROOT_PATH."tools/plugins/*.php") as $plfile){
        if($plfile!='tools/plugins/index.php'&&file_exists($plfile)){
            require($plfile);
            $plugins[]=$plfile;
        }
    }
}

/*加载共用数据*/
if(NOSET_AJAX){
    $cateid=empty($_GET['cateid'])?0:intval($_GET['cateid']);
    /* 加载左侧分类数据  */
    $categroy_list=getcategroy_list();
    $tpl->assign("categroy_list",$categroy_list);
    $tpl->assign("cateid",$cateid);
    
    /* 加载顶部菜单   */
    $nav=get_nav();
    $tpl->assign("nav",$nav);
    $tpl->assign("selectnav",$action);
    $tpl->assign("englisturl",build_url($_GET,"en-us"));
    $tpl->assign("chineseurl",build_url($_GET,"zh-cn"));
    /* 加入统计功能   */
    if(!NOT_START&&!empty($siteconfig['status_off'])){// 有些地方是不需要加载统计的，如验证码等。
        if (get_cfg_var('browscap')){
            $browser=get_browser(null,true); //If available, use PHP native function
        }else{
            require_once(ROOT_PATH."include/php-local-browscap.php");
            $browser=get_browser_local(null,true);
        }
        
        $site_status=array (
            'ip' => $ip,
            'addtime' => time(),
            'referer' => $_SERVER['HTTP_REFERER'],
            'thisurl' => $_SERVER['REQUEST_URI'],
            'parent'  => $browser['parent'],
            'browser' =>$browser['browser'],
            'system' => $browser['platform'],
            'alexa' => strpos(strtolower($_SERVER['HTTP_USER_AGENT']),"alexa")?1:0,
            'user_augrent' => $_SERVER['HTTP_USER_AGENT'],
            'language' => $_SERVER['HTTP_ACCEPT_LANGUAGE'],
         );
         if(!empty($siteconfig['status_small'])){
         $site_status['orthers']=serialize($browser);
         }
         $db->autoExecute($dtb->table('status'),$site_status);
         unset($browser);
     }
    /* 系统导航   */
    $sys_onnav=show_sys_nav();
    $tpl->assign("sys_onnav",$sys_onnav);
    $nav_name=get_nav_name($action);
    if(!empty($nav_name)){
       $tpl->assign("page_title",$nav_name);
    }
    $get_cart_sum=get_cart_sum();
    if(!empty($get_cart_sum)){
        $tpl->assign("cart_sum",$get_cart_sum);
    }
    $attr=array("price",'meta','color');
    foreach ($attr as $att){
        $attrinfo[$att]=get_dball($att);
        if(!empty($attrinfo[$att])){
            $imax=count($attrinfo[$att]);
            for ($i=0;$i<$imax;$i++){
                $pramesx['act']="product";
                $pramesx['orthers']="attr-".$att."_".$attrinfo[$att][$i]['id'];
                $attrinfo[$att][$i]['cn_url']=build_url($pramesx,"zh-cn");
                $attrinfo[$att][$i]['en_url']=build_url($pramesx,"en-us");
            }
            $tpl->assign("googs_".$att,$attrinfo[$att]);
        }
    }
    $check_loginarray=array('cart_check');
    if(in_array($action,$check_loginarray)){
        include_once ROOT_PATH.'include/lib_member_user.php';
        $UO=new U();
        $UO->check_login();
        $user_info=$UO->get_userinfo($dtb->getcookies('user_name'));
        $tpl->assign('user_info',$user_info);
    }
}
else{
   header("Content-Type:text/javascript; charset=utf-8"); 
}

//print_r($GLOBALS); 输出所以变量。。
?>
