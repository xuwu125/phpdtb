<?php
/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */

/**
 * 用户类，注册，检查，添加，更新等。
 * */

class U {
	
	/**
	 * 会员类
	 * @access Public user
	 */
	function u(){
		
	}
	/**
	 * PHP构造类
	 *
	 */
	function __construct() {
		
	}
	
	function check($user_name){
		return $this->get_userinfo($user_name);
	}
	
	function adduser($user){
		if(is_array($user)){
			$sql="INSERT INTO ".$GLOBALS['dtb']->table('users')." (`user_name`,`user_pass`,`user_email`) ".
			"  VALUES('".$user['user_name']."','".$user['user_pass2']."','".$user['user_email']."')";
			return $GLOBALS['db']->query($sql);
		}else{
			return false;
		}
	}
	
	function get_userinfo($user_name,$flag='*'){
		
		$sql="SELECT $flag FROM ".$GLOBALS['dtb']->table('users')." WHERE user_name='$user_name' ";
		
		if($flag!='*'){
			$temp=$GLOBALS['db']->getOne($sql);    
		}else{
		    $temp=$GLOBALS['db']->getRow($sql);
		}
		return $temp;
	}
	function getuserinfo($user_id,$flag='*'){
		
		$sql="SELECT $flag FROM ".$GLOBALS['dtb']->table('users')." WHERE user_id='$user_id' ";
		
		if($flag!='*'){
			$temp=$GLOBALS['db']->getOne($sql);    
		}else{
		    $temp=$GLOBALS['db']->getRow($sql);
		}
		return $temp;
	}
	
	function user_login($user_name,$user_password){
		$usr=$this->get_userinfo($user_name);
		global $user_lang,$dtb,$LANG,$siteconfig,$language;
		$publinks=array('text'=>$LANG['login'],'href'=>'index.php?act=user&type=memberhome&lang='.$language);
		if(!empty($_GET['url'])){
		    $publinks['href']=rawurldecode($_GET['url']);
		}
		if(empty($user_lang)){
		$user_lang=require(ROOT_PATH.'tools/language/user_'.$language.".php");
		}
		if(empty($usr)){
			$dtb->sysbox($LANG['error'].$LANG['tips'],$user_lang['usernotfound']);
		}else{
			if($usr['user_pass']!=md5($user_password)){
				$dtb->sysbox($LANG['error'].$LANG['tips'],$user_lang['loginpasserror']);
			}else{
				if($usr['user_lock']!=0){
					$dtb->sysbox($LANG['error'].$LANG['tips'],$user_name.$user_lang['islock'],$publinks);
				}else{
				    
				    foreach ($usr as $key=>$vals){
				        $dtb->setcookies($key,$vals);
				    }
					$publinks['text']=$LANG['go_on'];
				    $dtb->setcookies('user_name',$usr['user_name']);
				    $dtb->setcookies('user_id',$usr['user_id']);
					$dtb->sysbox($LANG['error'].$LANG['tips'],$user_name.$user_lang['login_yes'],$publinks);
				}
				
			}
			
		}
	}
	
	function check_login(){
	    global $dtb;
	    $user_id=$dtb->getcookies("user_id");
	    $user_name=$dtb->getcookies("user_name");
	    //print_r($_COOKIE);
	    //print_r($user_name);
	    if(!empty($user_id)&&!empty($user_name)){
	        return true;
	    }else{
	        global $dtb,$LANG,$user_lang,$language;
	        if(empty($user_lang)){
        		$user_lang=require(ROOT_PATH.'tools/language/user_'.$language.".php");
        	}
        	$_SERVER['HTTP_REFERER']=rawurlencode($_SERVER['HTTP_REFERER']);
	        $dtb->sysbox($LANG['error'].$LANG['tips'],$user_lang['notlogin'],array('text'=>$user_lang['relogin'],'href'=>'index.php?act=user&type=login&lang='.$GLOBALS['language']."&url=".$_SERVER['HTTP_REFERER']));
	    }
	}
	
	function check_useranme($user_name){
	    $user_name_match=explode(",",'a,b,c,d,e,f,g,h,i,g,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,_,@,.,1,2,3,4,5,6,7,8,9,0');
	    $usize=strlen($user_name);$user_name=strtolower($user_name);
	    if(!empty($usize)){
	       for ($i=0;$i<$usize;$i++){
	            if(!in_array(substr($user_name,$i,1),$user_name_match)){
	                return false;
	            }
	       }
	       return $user_name;
	    }else{
	        return false;
	    }
	    
	}
	
	
}



?>
