<?php

/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */

/**
 *  PHPdtb 主体类
 * 	主要维护人：xuwu<xuwu125@gmail.com>
 * */

if (!defined('IN_SITE'))
{
    die('Hacking attempt');
}

class dtb {
    var $db_name='';
    var $db_prefix='dtb_';
	/**
	 * 返回表全名
	 *
	 * @param string $tbname	简单表名
	 * @return string			全名
	 */
	function __construct($db_name,$db_prefix){
	    $this->dtb($db_name,$db_prefix);
	}
	function dtb($db_name,$db_prefix){
	    $this->db_name=$db_name;
	    $this->db_prefix=$db_prefix;
	}
	/**
	 * 构造表名
	 *
	 * @param string $tbname
	 * @return string
	 */
	function table($tbname){
		return "`".$this->db_name."`.`".$this->db_prefix."$tbname`";
	}
	/**
	 * 构造一组由数组组成的完整数据库字段
	 *
	 * @param array $arr		名部数组
	 * @return string			返回一个完整的多个数据库字段名
	 */
	function fieldin($arr){
		if(count($arr)>0){
		$temp=array();
		foreach ($arr as $list){
			$temp[]="`$list`";
		}
		return implode(", ",$temp);
		}else{
		return "";
		}
	}
	
	/**
	 * 自动数据组的值转换成一个SQL字符串
	 *
	 * @param array $arr
	 * @return string
	 */
	function array_autodata($arr){
	    if(count($arr)>0){
		$temp=array();
		foreach ($arr as $list){
			$temp[]="'$list'";
		}
		return implode(", ",$temp);
		}else{
		return "";
		}
	}
    
	function autoupdate($table,$arrays,$where=''){
	    if(!empty($table)&&!empty($arrays)){
	    $temp=array();
	    $sql="UPDATE ".$this->table($table)." SET ";
	       foreach ($arrays as $key=>$value){
	           if($value!=''){
	               $temp[]="`$key`='$value'";
	           }
	       }
	       
	       $sql.=implode(",",$temp);
	       if(!empty($where)){
	       $sql.=" WHERE ".$where;
	       }
	       
	       return $GLOBALS['db']->query($sql);
	    }
	}
	/**
	 * 装指定的数组作为数组的键转换成一个新的二维数据组
	 *
	 * @param array $arr
	 * @param string $type
	 * @return array
	 */
	function array_data($arr,$type='post'){
	    if(count($arr)>0){
	    $type=strtolower($type);
		$temp=array();
		foreach ($arr as $list){
		    switch ($type){
		        case "post":
		        $temp[]=$_POST[$list]; break;
		        case "get":
		        $temp[]=$_GET[$list]; break;
		        case "request":
		        $temp[]=$_REQUEST[$list]; break;
		        case "env":
		        $temp[]=$_ENV[$list]; break;
		        case "server":
		        $temp[]=$_SERVER[$list]; break;
		        case "session":
		        $temp[]=$_SESSION[$list]; break;
		        case "cookies":
		        $temp[]=$_COOKIE[$list]; break;
		        case "files":
		        $temp[]=$_FILES[$list]; break;
		    }
		}
		return $temp;
		}else{
		return array();
		}
	}
	function auto_array($arr,$type='post'){
	    if(count($arr)>0){
	    $type=strtolower($type);
		$temp=array();
		foreach ($arr as $list){
		    switch ($type){
		        case "post":
		        $temp[$list]=$_POST[$list]; break;
		        case "get":
		        $temp[$list]=$_GET[$list]; break;
		        case "request":
		        $temp[$list]=$_REQUEST[$list]; break;
		        case "env":
		        $temp[$list]=$_ENV[$list]; break;
		        case "server":
		        $temp[$list]=$_SERVER[$list]; break;
		        case "session":
		        $temp[$list]=$_SESSION[$list]; break;
		        case "cookies":
		        $temp[$list]=$_COOKIE[$list]; break;
		        case "files":
		        $temp[$list]=$_FILES[$list]; break;
		    }
		}
		return $temp;
		}else{
		return array();
		}
	}
	/**
	 * 自动插入数据到指定的表
	 *
	 * @param array $user_fildes
	 * @param string $tableanme
	 * @return bolle
	 */
	function inser_into($user_fildes,$tableanme){
	    $sql="INSERT INTO ".$this->table($tableanme)." (".$this->fieldin($user_fildes).") ".
        " VALUES (".$this->array_autodata($this->array_data($user_fildes,'post')).")";
        return $GLOBALS['db']->query($sql);
	}
	
	/**
	 * 系统提示信息
	 *
	 * @param string $title
	 * @param string $message
	 * @param array $link
	 */
	function sysbox($title,$message,$link=array()){
	    $num=3;
	    if(!empty($link)){
    	    if(!empty($link['href'])){
    	       $linkhtml="<a href='".$link['href']."'>".$link['text']."</a>";
    	       $refererhtml='<meta http-equiv="Refresh" content="'.$num.';URL='.$link['href'].'" /><script type="text/javascript">window.setTimeout("location.href=\''.$link['href'].'\'",'.$num.'001);</script>';
    	    }else{
    	        foreach ($link as $links){
        	        $linkhtml.="<a href='".$links['href']."'>".$links['text']."</a>   ";
        	        if(empty($refererhtml)){
        	        $refererhtml='<meta http-equiv="Refresh" content="'.$num.';URL='.$links['href'].'" /><script type="text/javascript">window.setTimeout("location.href=\''.$links['href'].'\'",'.$num.'001);</script>';
        	        }
    	        }
    	        
    	    }
	    }
	    if(!is_array($GLOBALS['LANG'])){
	        echo $GLOBALS['LANG'];
	       $go_referer=empty($GLOBALS['LANG']['go_referer'])?"返回上一页":trim($GLOBALS['LANG']['go_referer']);
	       $auto_goto=empty($GLOBALS['LANG']['auto_goto'])?"浏览器将会在{$num}秒钟后自动转向，如果浏览器没有自动转向，请点击下面链接。":trim($GLOBALS['LANG']['auto_goto']);
	    }else{
	        $go_referer=$GLOBALS['LANG']['go_referer'];$auto_goto=$GLOBALS['LANG']['auto_goto'];
	    }
		die('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>'.$GLOBALS['siteconfig']['cnname']." ".$title.'</title>
<link href="'.$GLOBALS['_CFG']['site_url'].'images/css/default.css" rel="stylesheet" type="text/css" />
'.$refererhtml.'
</head>

<body>'.
		"<div id='error_message'>
		<dt id='error_message_title'>".$GLOBALS['siteconfig']['cnname']."   {$title}</dt><dt id='error_message_content'>{$message}
		<li><span  style='color:red'>{$auto_goto}</span></li></dt>
		<dt id='error_message_link'><a href='#' title='Go to back!' onclick='history.back();'>{$go_referer}</a>  {$linkhtml}</dt>
		</div></body>
</html>");
	}
	/**
	 * 整理模板,输出最终内容
	 *
	 * @param maxdata $data
	 * @param array string $needstr
	 * @param array string $replacestr
	 */
	function outhtml($data,$needstr=null,$replacestr=null){
	    if(!empty($data)){
	        if(DEV_ACCESS){
	        $data=str_replace(' src="images/',' src="'.$GLOBALS['siteconfig']['public'].'images/',$data);
	        $data=str_replace(' url("style/',' url("'.$GLOBALS['siteconfig']['public'].'style/',$data);
	        $data=str_replace('link href="style/','link href="'.$GLOBALS['siteconfig']['public'].'style/',$data);
	        $data=str_replace(' src="javascript/',' src="'.$GLOBALS['siteconfig']['public'].'javascript/',$data);
	        $data=str_replace('orther/',$GLOBALS['siteconfig']['public'].'orther/',$data);
			$data=str_replace('__PUBLIC__',$GLOBALS['siteconfig']['public'],$data);
	        }
    	    if(empty($needstr)||empty($replacestr)){
    	       echo $data;
    	    }else{
    	    echo str_replace($needstr,$replacestr,$data);
    	    }
    	    include_once(ROOT_PATH.'include/gzip.class.php');
    	    if(GZIP_PAGE&& function_exists('ob_gzhandler')){
    	        $gziphttp=new gzip_encode();
        	    if(!GZIP_LEV){
        	        $gziphttp->gzip_encode(5);
        	    }else{
        	        $gziphttp->gzip_encode(GZIP_LEV);
        	    }
    	    }
	    }
	}
	/**
	 * 写成HTML文件
	 *
	 * @param unknown_type $data
	 * @param unknown_type $path
	 */
	function write_html($data,$path){
	    $handle = @fopen($path, 'a');
        @fwrite($handle, $data);
        @fclose($handle);
	}
	
	/**
	 * 自动检查所有字段是否为空
	 *
	 * @param array $a1    原始数组
	 * @param array $a2    要检查的字段
	 * @return bolle       完全通过返回真
	 */
	function check_null($a1,$a2){
	    foreach ($a2 as $f){
	        if(!isset($a1[$f])){
	            return false;
	        }
	    }
	    return true;
	}
	
	/**
	 * 功能同上，只是0也不算有数据。 empty
	 *
	 * @param array $a1    原始数组
	 * @param array $a2    要检查的字段
	 * @return bool        完全通过返回真
	 */
	function check_empty($a1,$a2){
	    foreach ($a2 as $f){
	        if(empty($a1[$f])){
	            return false;
	        }
	    }
	    return true;
	}
	
	
	function check_user_login(){
	    if(empty($_SESSION['admin_id'])){
	        @unlink(ADMIN_PATH."public/data/database_yes.tmp");
	        return false;
	    }else{
	        return true;
	    }
	}
	
	
	/**
	 * 会员退出
	 *
	 */
	function login_out(){
	    @unlink(ADMIN_PATH."public/data/database_yes.tmp");
	    $_SESSION['admin_id']="";
	    $_SESSION['admin_name']="";
	}
	
	
	function fopen($fileurl){
	    if(empty($fileurl)){
	        return false;
	    }else{
	        $c=@file_get_contents($fileurl);
	        if($c){
	            return $c;
	        }else{
	            return false;
	        }
	    }
	}
	function fwrite($fileurl,$contents){
	    if(empty($fileurl)){
	        return false;
	    }else{
	        $c=file_put_contents($fileurl,$contents);
	        if($c){
	            return true;
	        }else{
	            return false;
	        }
	    }
	}
	
	function load_config($APPNAME="*"){
	    $sql="SELECT $APPNAME FROM ".$GLOBALS['dtb']->table("setting")." WHERE setid='1' ";
	    $temp=$GLOBALS['db']->getRow($sql);
	    if(empty($temp)){
	        return false;
	    }else{
	        return $temp;
	    }
	}
    
	/**
	 * 获取一个数组。
	 *
	 * @param array $arrays
	 * @param array $noarray
	 * @param array $datamax
	 * @param string $type
	 * @return array
	 */
	function get_newarray($arrays,$noarray,$datamax,$type='key'){
	    
	        foreach ($arrays as $key=>$v){
               if(!in_array($key,$noarray)){
                if($type=='key'){
                    $temp[]=$key;
                }elseif($type=='keyval'){
                    $temp[$key]=$datamax[$key];
                }elseif ($type=='val'){
                    $temp[]=$datamax[$key];
                }elseif ($type=='oldval'){
                    $temp[]=$v;
                }
               }
            }
	    return $temp;
	}
	
	function create_html_editer($FCKeditorname,$Value,$orthers=array()){
	    if(empty($orthers)){
	        global $siteconfig;
	        $orthers['height']=$siteconfig['edit_height'];
	        $orthers['width']=$siteconfig['edit_width'];
	        $orthers['toolbar']=$siteconfig['edit_toolbar'];
	        $orthers['skin']=$siteconfig['edit_skin'];
	    }
	    $sBasePath = $_SERVER['PHP_SELF'] ;
        $sBasePath = substr( $sBasePath, 0, strpos( $sBasePath, "admin" ) ) ;
        $sBasePath.="tools/fckeditor/";
        $oFCKeditor = new FCKeditor($FCKeditorname) ;
        $oFCKeditor->BasePath	= $sBasePath ;
        $oFCKeditor->Value		= $Value ;
        $oFCKeditor->Height=empty($orthers['height'])?"500px":$orthers['height'];
        $oFCKeditor->Width=empty($orthers['width'])?"100%":$orthers['width'];
        $oFCKeditor->ToolbarSet=empty($orthers['toolbar'])?"Default":$orthers['toolbar'];
        $oFCKeditor->Config['SkinPath']= $sBasePath . 'editor/skins/' . htmlspecialchars(empty($orthers['skin'])?"default":$orthers['skin']) . '/' ;
        return $oFCKeditor->CreateHtml() ;
	}
	
	/**
	 * 获取一个表的所以字段再过滤掉指定的字段。
	 *
	 * @param string $tabname
	 * @param array $noarray
	 * @return array
	 */
	function getfiles($tabname,$noarray=array()){
	    $sql="SELECT * FROM ".$this->table($tabname)." LIMIT 0,1";
	    $temp=$GLOBALS['db']->getRow($sql);
	    if(!empty($temp)){
	        $tt=array();
	        foreach ($temp as $key=>$val){
	            if(!empty($noarray)){
    	            if(!in_array($key,$noarray)){
    	               $tt[]=$key;
    	            }
	            }else {
	              $tt[]=$key;  
	            }
	        }
	        return $tt;
	    }else {
	        return false;
	    }
	}
	
	function get_cate_googs_count($datas=0){
	    $sql="SELECT COUNT(*) FROM ".$GLOBALS['dtb']->table("goods")." WHERE goods_cate_id='$datas'";
        return $GLOBALS['db']->getOne($sql);
	}
	function getcount($table,$where){
	    $sql="SELECT COUNT(*) FROM ".$GLOBALS['dtb']->table($table)." WHERE $where";
        return $GLOBALS['db']->getOne($sql);
	}
	
	/**
	 * 将一个数姐转换为具体的字符值。
	 *
	 * @param array $array
	 */
	function array_key_val($array){
	   if(!empty($array)){
	       
	       foreach ($array as $key=>$val){
	           $temp[]=$key."=".$val;
	       }
	       return implode("\n",$temp);
	   }else{return false;}
	}
	
	function cookiesname($name){
	    return $GLOBALS['siteconfig']['cookies_prefix'].$name;
	}
	
	function setcookies($name,$values=null,$expires=null,$path=null,$domain=null,$secure=null,$htttponly=null){
	    //echo $this->cookiesname($name)."=$values".$GLOBALS['siteconfig']['session_cookie_path'].$GLOBALS['siteconfig']['session_cookie_domain']." \n";
	    setcookie($this->cookiesname($name),$values,time()+604800,$GLOBALS['siteconfig']['session_cookie_path'],$GLOBALS['siteconfig']['session_cookie_domain'],$secure,$htttponly);
	}
	
	function getcookies($name){
	    return $_COOKIE[$this->cookiesname($name)];
	}
}

?>
