<?php
/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */
/**
 * 支付宝插件
 */

if (!defined('IN_SITE'))
{
    die('Hacking attempt');
}

/* 模块的基本信息 */
if (isset($set_modules) && $set_modules == TRUE)
{
    $i = isset($modules) ? count($modules) : 0;

    /* 代码 */
    $modules[$i]['code']    = basename(__FILE__, '.php');

    /* 描述对应的语言项 */

    /* 是否支持货到付款 */
    $modules[$i]['is_cod']  = '0';

    /* 是否支持在线支付 */
    $modules[$i]['is_online']  = '1';

    /* 作者 */
    $modules[$i]['author']  = 'Dtb TEAM';

    /* 网址 */
    $modules[$i]['website'] = 'http://www.alipay.com';

    /* 版本号 */
    $modules[$i]['version'] = '1.0.1';

    /* 配置信息 */
    $modules[$i]['config']  = array(
        array('name' => 'alipay_account',           'type' => 'text',   'value' => ''),
        array('name' => 'alipay_key',               'type' => 'text',   'value' => ''),
        array('name' => 'alipay_partner',           'type' => 'text',   'value' => ''),
        array('name' => 'alipay_real_method',       'type' => 'select', 'value' => '0'),
        array('name' => 'alipay_virtual_method',    'type' => 'select', 'value' => '0'),
        array('name' => 'is_instant',               'type' => 'select', 'value' => '0')
    );

    return;
}

/**
 * 类
 */
class alipay
{

    /**
     * 构造函数
     *
     * @access  public
     * @param
     *
     * @return void
     */
    function alipay()
    {
    }

    function __construct()
    {
        $this->alipay();
    }

    /**
     * 生成支付代码
     * @param   array   $order      订单信息
     * @param   array   $payment    支付方式信息
     */
    function get_code($order, $payment)
    {
        $service='create_direct_pay_by_user';// 'trade_create_by_buyer'
        


        $parameter = array(
            'service'           => $service,
            //'partner'           => $payment['alipay_partner'],
            'partner'           => ALIPAY_ID,
            '_input_charset'    => 'utf-8',
            'return_url'        => return_url(basename(__FILE__, '.php')),
            /* 业务参数 */
            'subject'           => $order['order_sn'],
            'out_trade_no'      => $order['order_sn'],
            'price'             => $order['money_all'],
            'quantity'          => 1,
            'payment_type'      => 1,
            /* 物流参数 */
            'logistics_type'    => 'EXPRESS',
            'logistics_fee'     => 0,
            'logistics_payment' => 'BUYER_PAY_AFTER_RECEIVE',
            /* 买卖双方信息 */
            'seller_email'      => $payment['user_name']
        );

        ksort($parameter);
        reset($parameter);

        $param = '';
        $sign  = '';

        foreach ($parameter AS $key => $val)
        {
            $param .= "$key=" .urlencode($val). "&";
            $sign  .= "$key=$val&";
        }

        $param = substr($param, 0, -1);
        //$sign  = substr($sign, 0, -1). $payment['alipay_key'];
        $sign  = substr($sign, 0, -1). ALIPAY_AUTH;

        $button = '<div style="text-align:center"><input type="button" onclick="window.open(\'https://www.alipay.com/cooperate/gateway.do?'.$param. '&sign='.md5($sign).'&sign_type=MD5\')" value="' .$GLOBALS['LANG']['pay_button']. '" /></div>';

        return $button;
    }

    /**
     * 响应操作
     */
    function respond()
    {
        $payment  = get_paymentname($_GET['code']);
        $seller_email = rawurldecode($_GET['seller_email']);
        $order_sn = trim($_GET['out_trade_no']);

        /* 检查支付的金额是否相符 */
        if (!check_money($order_sn, $_GET['total_fee']))
        {
            return false;
        }

        /* 检查数字签名是否正确 */
        ksort($_GET);
        reset($_GET);

        $sign = '';
        foreach ($_GET AS $key=>$val)
        {
            if ($key != 'sign' && $key != 'sign_type' && $key != 'code')
            {
                $sign .= "$key=$val&";
            }
        }

        //$sign = substr($sign, 0, -1) . $payment['alipay_key'];
        $sign = substr($sign, 0, -1) . ALIPAY_AUTH;
        if (md5($sign) != $_GET['sign'])
        {
            return false;
        }

        if ($_GET['trade_status'] == 'WAIT_SELLER_SEND_GOODS')
        {
            /* 改变订单状态 */
            order_paid($order_sn, 1); // 付款中。

            return true;
        }
        elseif ($_GET['trade_status'] == 'TRADE_FINISHED')
        {
            /* 改变订单状态 */
            order_paid($order_sn); // pay end
            return true;
        }
        else
        {
            return false;
        }
    }
}

?>
