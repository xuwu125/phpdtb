<?php
return array(
    'order_status'=>'订单状态',
    'order_status_0'=>'未处理',
    'order_status_1'=>'已确认',
    'order_status_2'=>'已完成',
    'order_status_3'=>'已取消',
    'pay_status'=>'支付状态',
    'pay_status_0'=>'未支付',
    'pay_status_1'=>'付款中',
    'pay_status_2'=>'已付款',
    'pay_status_3'=>'已退款',
    'all_goods_bar'=>'共有%s个商品',
);
?>