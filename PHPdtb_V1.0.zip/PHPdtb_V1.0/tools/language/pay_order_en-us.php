<?php
return array(
    'order_status'=>'Order Status',
    'order_status_0'=>'Untreated',
    'order_status_1'=>'Confirmed',
    'order_status_2'=>'completed',
    'order_status_3'=>'canceled',
    'pay_status'=>'To pay state',
    'pay_status_0'=>'Unpaid',
    'pay_status_1'=>'Payment in',
    'pay_status_2'=>'Paid',
    'pay_status_3'=>'Refund',
    'all_goods_bar'=>'A total of %s commodities',
);
?>