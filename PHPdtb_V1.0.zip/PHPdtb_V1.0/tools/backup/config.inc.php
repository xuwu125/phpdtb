<?php
/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */


/*	配置文件 	*/
/**
 * 配置说明
 * array (
	  'db_host' => 'localhost', 	// 数据库服务器地址
	  'db_user' => 'phpdtb',		// 数据用户名
	  'db_pwd' => 'phpdtb',			// 数据库用户密码
	  'db_database' => 'phpdtb',	// 数据库名
	  'db_prefix' => 'phpdtb_',		// 数据库前缀
	  'db_update' => 'tools/db/',	// 安装与更新数据目录(没特殊情况，请不要修改)
	  'adminpath' => 'admin/',		// 后台目录如更改请先FTP修改目录
	);
 */
// 

//time add:2008-12-12 01:13:23

//time add:2008-12-12 01:22:08

//time add:2008-12-12 06:19:44
return array (
  'db_host' => 'localhost',
  'db_user' => 'phpdtb',
  'db_pwd' => 'phpdtb',
  'db_database' => 'phpdtb',
  'db_prefix' => 'phpdtb_',
  'db_update' => 'tools/db/',
  'adminpath' => 'admin/',
);

?>