<?php
/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */

/*
 +------------------------------------------------------------------------------
 * PHPdtb 前台主体程序(Front of the main program)
 +------------------------------------------------------------------------------
 */
$install_lockfile="./tools/install.lock";
if(!file_exists($install_lockfile)){
	header("Content-Type:text/html; charset=utf-8");
    die("对不起，请先运行安装程序。<a href='install.php'>马上安装</a>\n<br />".
    "Sorry, you run the installer.<a href='install.php'>Immediately installed</a>");
}
define('IN_SITE',true);
define('SET_Smarty',true);
define('DEV_ACCESS',true);
define('NOSET_AJAX',true);
define('NOT_START',false);

include_once('include/init.php');
/*$tpl->assign();*/

/*开始*/

$publinks=array(array('text'=>$LANG['go_on'],"href"=>$_SERVER['HTTP_REFERER']),array('text'=>$LANG['go_home'],"href"=>"index.php"));
if($action=='index'){
    //print_r($LANG);
    //print_r($siteconfig);
    if(!$tpl->is_cached("$action.html",$cache_id)){
        $indexcategroy_list=getcategroy_list(0,1," AND is_hot='1' ");
        $tpl->assign("indexcategroy_list",$indexcategroy_list);
        $tpl->assign("hot_goods",get_hack_goods(12));
    }
    $outhtml=$tpl->fetch("$action.html",$cache_id);
    $dtb->outhtml($outhtml);
/*返回首页*/
}elseif($action=='gotoindex'){
    header('Location:index.php');
/*信息反馈*/
}elseif($action=='freeback'){
    $serverpost=array(
            "name"=>$_POST['name'],
            "title"=>$_POST['title'],
            "content"=>$_POST['content'],
            "tel"=>$_POST['tel'],
            "postcode"=>$_POST['postcode'],
            "moblie"=>$_POST['moblie'],
            "msn"=>$_POST['msn'],
            "skype"=>$_POST['skype'],
            "email"=>$_POST['email'],
            "address"=>$_POST['address'],
            "referer"=>$_SERVER['HTTP_REFERER'],
            "addtime"=>time(),
        );

    if($savepost=='yes'){
        $checkarray=array("name","title","content","email");
        
        if(!$dtb->check_empty($serverpost,$checkarray)){
            foreach ($checkarray as $li){
                $errors[]="[".$LANG[$li]."]";
            }
            $dtb->sysbox($LANG['error'].$LANG['tips'],"<li>".implode(",",$errors).$LANG['no_empty']."</li>",$publinks);
        }
        $insert=$db->autoExecute($dtb->table("freeback"),$serverpost);
        if($insert){
            $dtb->sysbox($LANG['success'].$LANG['tips'],"<li>".$LANG['submit'].$LANG['success']."</li>",$publinks);
        }else{
            $dtb->sysbox($LANG['error'].$LANG['tips'],"<li>".$LANG['submit'].$LANG['failure']."</li>",$publinks);
        }
    }
    if(!$tpl->is_cached("$action.html",$cache_id)){
        $fileds=$dtb->get_newarray($serverpost,array("referer","addtime"),$_POST);
        $tpl->assign("fdata",$fileds);
    }
    $outhtml=$tpl->fetch("$action.html",$cache_id);
    $dtb->outhtml($outhtml);
/*商品列表*/
}elseif($action=='product'||$action=='hotproduct'||$action=='search'){
    $categroy=$cateid;
    $keywords=trim($_REQUEST['keywords']);
    $goodsattr=trim($_REQUEST['orthers']);
    if(!$tpl->is_cached("product_list.html",$cache_id)||empty($keywords)){
        $sql="SELECT * FROM ".$GLOBALS['dtb']->table("goods");
        if(!empty($categroy)){
            $sqlwhere="  WHERE ispass='1' AND ( goods_cate_id='$categroy' OR ".
            " goods_cate_id IN (SELECT cid FROM ".$GLOBALS['dtb']->table("categroy")." WHERE categoryid='$categroy' AND ispass='1') )";
            $categroyinfo=get_categroy($cateid);
            $nav_sys_this=$language=='zh-cn'?$categroyinfo['cnname']:$categroyinfo['enname'];
            $tpl->assign("page_title",$nav_sys_this);
            $tpl->assign("page_keywords",$sys_onnav.$language=='zh-cn'?$categroyinfo['cnkeywords']:$categroyinfo['enkeywords']);
            $tpl->assign("page_des",$sys_onnav.$language=='zh-cn'?$categroyinfo['cndescription']:$categroyinfo['endescription']);
            $tpl->assign("sys_onnav",$sys_onnav."&gt;&gt;".$nav_sys_this);
        }else{
            $sqlwhere="  WHERE ispass='1' ";
        }
        $sort_byarray=array('sort_price_asc','sort_price_desc','sort_goods_sn_asc','sort_goods_sn_desc','sort_mini_order_asc','sort_mini_order_desc','sort_goods_id_asc',"sort_goods_id_desc");
        $sort_by=$_GET['sort'];
        $orderby_sql=" ORDER BY `goods_id` DESC ";
        if(!empty($sort_by)&&in_array($sort_by,$sort_byarray)){
            $sort_byfields=str_replace(array('sort_','_asc','_desc'),"",$sort_by);
            $sortarray=explode("_",$sort_by);
            $sortorderby=empty($sortarray[3])?trim($sortarray[2]):trim($sortarray[3]);
            if($sortorderby=='DESC'){
                $orderby_sql=" ORDER BY `$sort_byfields` DESC ";
            }else{
                $orderby_sql=" ORDER BY `$sort_byfields` ASC ";
            }
            
        }
       if(!empty($keywords)){
           if($language=="zh-cn" ){
                $sqlwhere.="  AND LOWER(`goods_cnanme`) LIKE LOWER('%$keywords%') ";
           }else{
                $sqlwhere.="  AND LOWER(`goods_enname`) LIKE LOWER('%$keywords%') ";
           }
           $tmptitle=$language=='zh-cn'?$categroyinfo['cnname']:$categroyinfo['enname'];
           $tpl->assign("page_title",$tmptitle.$LANG['search']."&gt;&gt;[".$keywords."]");
           $tpl->assign("sys_onnav",$sys_onnav.$LANG['search']."&gt;&gt;[".$keywords."]");
       }
       if($action=='hotproduct'){
           $sqlwhere.=" AND is_hot='1' ";
           
           //$tpl->assign("sys_onnav",$sys_onnav);
       }
      
       if(!empty($goodsattr)){
           $attrarray=explode("_",str_replace("attr-","",$goodsattr));
           if(in_array($attrarray[0],$attr)){
           $attrdata=get_dbinfo($attrarray[0],$attrarray[1]);
           if(!empty($attrdata)){
               $sqlwhere.=" AND `".$attrarray[0]."` LIKE '%".$attrarray[1]."%' ";
           }
           //print_r($attrdata);
           $attrdata['name']=$language=='zh-cn'?$attrdata['cnname']:$attrdata['enname'];
           $tpl->assign("page_title",$sys_onnav."&gt;&gt;".$LANG[$attrarray[0]]."&gt;&gt;".$attrdata['name']);
           $tpl->assign("sys_onnav",$sys_onnav."&gt;&gt;".$LANG[$attrarray[0]]."&gt;&gt;<span style='color:'>".$attrdata['name']."</span>");
           }
       }
        $pager['page']=intval($_GET['page']);
        $pager['pagesize']=empty($siteconfig['goods_pagesize'])?12:intval($siteconfig['goods_pagesize']);
        $pager=get_page("goods",$sqlwhere,$pager);
        
        $sql=$sql.$sqlwhere." $orderby_sql LIMIT ".$pager['satrt']." , ".$pager['pagesize'];
        $list=$db->getAll($sql);
        $mainarr=$_GET;
        unset($mainarr['page']);// 去掉page 参数。
        foreach ($mainarr as $keys=>$values){
            if(!empty($mainurls)){
                $mainurls.="&$keys=$values";
            }else{
                $mainurls="$keys=$values";
            }
        }
        
        $main_url="index.php?".$mainurls;
            /* 分页功能          */
            $page_arg=array('total'=>$pager['readcount'],
            'perpage'=>$pager['pagesize'],
            'page_name'=>'page',
            'url'=>$main_url);
            require_once(ROOT_PATH.'include/page.class.php');
            $pagex=new page($page_arg);
            $pagex->first_page=$LANG['first_page'];
            $pagex->next_page=$LANG['next_page'];
            $pagex->pre_page=$LANG['pre_page'];
            $pagex->last_page=$LANG['last_page'];
            $tpl->assign('page',$pagex->show(5));
                
        $listmax=count($list);
        for ($i=0;$i<$listmax;$i++){
            //$list[$i]['good_catename']=get_categroy($list[$i]['goods_cate_id'],'cnname');
            $prames=array('act'=>"goods",
            'goods_id'=>$list[$i]['goods_id']);
            $list[$i]['cn_url']=build_url($prames,"zh-cn");
            $list[$i]['en_url']=build_url($prames,"en-us");
        }
        $tpl->assign('keywords',$keywords);
        $tpl->assign('pageinfo',$page);
        $tpl->assign("list",$list);
        $tpl->assign("sort_byarray",$sort_byarray);
    }
    $outhtml=$tpl->fetch("product_list.html",$cache_id);
    $dtb->outhtml($outhtml);
/*商品详细信息*/
}elseif ($action=='goods'){
    
    $goods_id=empty($_GET['goods_id'])?0:intval($_GET['goods_id']);
    if(empty($goods_id)){
        $dtb->sysbox($LANG['error'].$LANG['tips'],"<li>".$LANG['param_error']."!</li>",$publinks);
    }
    if(!$tpl->is_cached("goods.html",$cache_id)){
        $goods_info=get_goods_info($goods_id,"*",1);
        
        if(empty($goods_info)){
            $dtb->sysbox($LANG['error'].$LANG['tips'],"<li>".$LANG['goods'].$LANG['not_found']."!</li>",$publinks);
        }else{
            if(!empty($goods_info['bigimage'])){
                $goods_info['bigimage_imagesize']=@getimagesize($goods_info['bigimage']);
            }
            if(!empty($goods_info['bigimage'])){
                $goods_info['smallimage_imagesize']=@getimagesize($goods_info['smallimage']);
            }
            if(!empty($goods_info['goods_keywords'])){
            $siteconfig['cnkeyword']=$goods_info['goods_keywords'];
            }
            if(!empty($goods_info['goods_des'])){
            $siteconfig['cndes']=$goods_info['goods_des'];
            }
            if(!empty($goods_info['goods_enkeywords'])){
            $siteconfig['enkeyword']=$goods_info['goods_enkeywords'];
            }
            if(!empty($goods_info['goods_endes'])){
            $siteconfig['endes']=$goods_info['goods_endes'];
            }
            if(!empty($goods_info['meta'])){
                $where=" ispass='1' AND `id` IN (".$goods_info['meta'].") ";
                $goods_info['meta_list']=get_dball('meta',$where);
            }
            if(!empty($goods_info['color'])){
                $where=" ispass='1' AND `id` IN (".$goods_info['color'].") ";
                $goods_info['color_list']=get_dball('color',$where);
            }
            if(!empty($goods_info['price'])){
                //$where=" ispass='1' AND `id` ='".$goods_info['price']."' ";
                $goods_info['price_list']=get_dbinfo('price',$goods_info['price']);
            }
            $param['act']="product";
            $param['cateid']=$goods_info['goods_cate_id'];
            $goods_info['goods_cate_url']=build_url($param);
            $goods_info['photolist']=get_goods_photo($goods_id);
            if(!empty($goods_info['related_goods'])){
                //相关商品
                $goods_rellist=explode(",",$goods_info['related_goods']);
                if(!empty($goods_rellist)){
                foreach ($goods_rellist as $vgoods_id)
                    $goods_info['related_goodslist'][]=get_goods_info($vgoods_id,"*",1);
                }
            }
            //print_r($goods_info);
            if($language=="zh-cn"){
                $tpl->assign("page_title",$goods_info['goods_cnanme']);
                $tpl->assign("page_keywords",$goods_info['goods_keywords']);
                $tpl->assign("page_des",$goods_info['goods_des']);
                $tpl->assign("sys_onnav",$sys_onnav.$goods_info['goods_cnanme']);
                $goods_info['goods_cate_cnname']=get_categroy($param['cateid'],"cnname");
                
            }else{
                $tpl->assign("page_title",$goods_info['goods_enname']);
                $tpl->assign("page_keywords",$goods_info['goods_enkeywords']);
                $tpl->assign("page_des",$goods_info['goods_endes']);
                $tpl->assign("sys_onnav",$sys_onnav.$goods_info['goods_enname']);
                $goods_info['goods_cate_enname']=get_categroy($param['cateid'],"enname");
            }
            
            $tpl->assign("cateid",$goods_info['goods_cate_id']);
            $tpl->assign("goods",$goods_info);
            //print_r($goods_info);
        }
    }
    update_goods_count($goods_id); /// 商品浏览统计
    $outhtml=$tpl->fetch("goods.html",$cache_id);
    $dtb->outhtml($outhtml);
/*购物车*/
}elseif ($action=='cart'){
    $list=get_cart_goods();
    
    $imax=count($list);
    $cartinfo=array('goods_count'=>0);
    if($imax>0){
        for($i=0;$i<$imax;$i++){
            
            $goods_info=getgoodsinfo($list[$i]['goods_id']);
            
            $list[$i]['cn_url']=$goods_info['cn_url'];
            $list[$i]['en_url']=$goods_info['en_url'];
            $list[$i]['smallimage']=$goods_info['smallimage'];
            $list[$i]['goods_cnanme']=$goods_info['goods_cnanme'];
            $list[$i]['goods_enanme']=$goods_info['goods_enname'];
            $list[$i]['cn_url']=$goods_info['cn_url'];
            $list[$i]['en_url']=$goods_info['en_url'];
            $list[$i]['goods_sn']=$goods_info['goods_sn'];
            $list[$i]['goods_info']=$goods_info;
            if($language=='zh-cn'){
                $list[$i]['amount']=round($list[$i]['price']*$list[$i]['count'],2);
            }else {
                $list[$i]['amount']=round($list[$i]['enprice']*$list[$i]['count'],2);   
            }
            $list[$i]['mini_order']=empty($goods_info['mini_order'])?1:intval($goods_info['mini_order']);
            $cartinfo['all_amount']+=$list[$i]['amount'];
            $cartinfo['goods_count']+=$list[$i]['count'];
            unset($goods_info);
        }
    }
    $tpl->assign("cartinfo",$cartinfo);
    $tpl->assign("list",$list);
    //print_r($list);
    $outhtml=$tpl->fetch("cart.html",$cache_id);
    $dtb->outhtml($outhtml);
/*检查购物车*/
}elseif ($action=='cart_check'){
    $cartall=get_cart_goods();
    if(empty($cartall)){
        $publinks[0]['href']="index.php?act=cart&lang=".$language;
        $dtb->sysbox($LANG['error'].$LANG['tips'],"<li>1. ".$LANG['cart_is_empty']."</li>\n",$publinks);
    }else{
        $sys_info['pay']=get_paymethod();
        $sys_info['post']=get_postmethod();
        $order_sn=get_order_sn();
        $orderinfo=array('name','companyname','tel' ,'address','address2','fax','email','come_from','comment');
        $orderinfocheck=array('name','tel' ,'address','fax','email');
        foreach ($orderinfocheck as $v){
            $orderyes[$v]='yes';
        }
        $tpl->assign('orderyes',$orderyes);
        $tpl->assign("savepost",$savepost);
        $tpl->assign("order_sn",$order_sn);
        if($savepost=="yes"){
            foreach ($orderinfo as $info){
                if(!empty($_POST[$info])){
                    $orderinfo2[]=$LANG[$info].":".$_POST[$info];
                }else{
                    if(in_array($info,$orderinfocheck)){
                        $publinks[0]['href']="javascript:history.back();";
                        // 保留用户已经输入的资料
                        $dtb->sysbox($LANG['error'].$LANG['tips'],"<li>".$LANG[$info]." ".$LANG['no_empty']."!</li>",$publinks);
                    }
                }
            }
            $linkinfo=implode("<br />\n",$orderinfo2);
            $order['order_sn']=$order_sn;
            $order['money']=$get_cart_sum['allmoney'];
            $order['addtime']=time();
            $order['post_methods']=$_POST['post_methods'];
            $order['pay_methods']=$_POST['pay_methods'];
            $order['linkmeninfo']=$linkinfo;
            $order['goods_count']=$get_cart_sum['allcount'];
            $order['orther_money']=0;
            $order['lang']=$language;
            if(empty($get_cart_sum['allcount'])){
                $dtb->sysbox($LANG['error'].$LANG['tips'],"<li>".$LANG['cart_is_empty']."!</li>",$publinks);
            }
            if(empty($order['pay_methods'])){
                $dtb->sysbox($LANG['error'].$LANG['tips'],"<li>".$LANG['payments'].$LANG['no_empty']."!</li>",$publinks);
            }
            if(empty($order['post_methods'])){
                $dtb->sysbox($LANG['error'].$LANG['tips'],"<li>".$LANG['postments'].$LANG['no_empty']."!</li>",$publinks);
            }
            $postm=get_postmethod($order['post_methods'],'post_fees,cnname,enname');
            $postp=get_paymethod($order['pay_methods'],'payfees,cnname,enname');
            $order['fee_money']=$postp['payfees'];
            $order['payfees']=$postm['post_fees'];
            $order['user_id']=$user_info['user_id'];
            $order['money_all']=$order['money']+($order['fee_money']+$order['payfees']);
            $orderok=true;
            $cart_goodsimax=count($cartall);
            for ($i=0;$i<$cart_goodsimax;$i++){
                $order_goods['order_sn']=$order_sn;
                $order_goods['goods_id']=$cartall[$i]['goods_id'];
                $order_goods['goods_sn']=get_goods_info($order_goods['goods_id'],'goods_sn',1);
                $order_goods['goods_price']=$cartall[$i]['price'];
                $order_goods['enprice']=$cartall[$i]['enprice'];
                $order_goods['goods_count']=$cartall[$i]['count'];
                $order_goods['addtime']=time();
                $order_goods['lang']=$language;
               
                if($orderok){
                    $orderok=$db->autoExecute($dtb->table('order_goods'),$order_goods);
                }
                update_goods_order_count($order_goods['goods_id']);
                unset($order_goods);
            }
            if($orderok){
                $orderok=$db->autoExecute($dtb->table('order'),$order);
                clean_cart_goods();// 清理购物车。
            }
            $orderoktext=$orderok?$LANG['success']:$LANG['failure'];
            $LANG['order_submit']=sprintf($LANG['order_submit'],$order_sn,$orderoktext);
            $tpl->assign("LANG",$LANG);
            $tpl->assign("pay_info",$postp);
            $tpl->assign("post_info",$postm);
        }
        $tpl->assign("orderinfo",$orderinfo);
        $tpl->assign("sys_info",$sys_info);
        
        $tpl->assign("list",$cartall);
        $tpl->assign("page_title",$LANG['cart_eheck']);
        $tpl->assign("sys_onnav",$sys_onnav.$LANG['cart_eheck']);
        //print_r($list);
        $outhtml=$tpl->fetch("cart_check.html",$cache_id);
        $dtb->outhtml($outhtml);
    }
    
}elseif ($action=='user'){
    $type=$_REQUEST['type'];
    include_once ROOT_PATH.'include/lib_member_user.php';
    $UO=new U();
    $user_name=$dtb->getcookies('user_name');
    $user_id=$dtb->getcookies('user_id');
    $user_lang=require(ROOT_PATH.'tools/language/user_'.$language.".php");
    if($type=='list'||empty($type)||$type==null||$type==''){
        $type='login';
        if(!empty($user_id)&&($type=='reg'||$type=='login')){
            $type='memberhome';
        }
    }
    $userarray=array('memberhome','reg','regsave','login','edituserinfo','order_list','orderview','logout');
    $notnav=array('regsave','orderview');
    $notloginarray=array('reg','login','regsave','logout');
    if(!in_array($type,$userarray)){
        $url_this =  "http://".$_SERVER ['HTTP_HOST'].$_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
        $dtb->sysbox($LANG['error'].$LANG['tips'],"<li>1. ".$LANG['not_found_gohome']."</li>\n".
            "<li>2. ".$LANG['pageiserror']."</li>\n<li>3. ".$LANG['yourgopage'].":".$url_this."</li>");
    }
    
    $userinfo=$UO->get_userinfo($user_name);
    if(!empty($userinfo)){
        foreach ($userinfo as $key=>$vals){
            $tpl->assign($key,$dtb->getcookies($key));
        }
        $notnav[]='reg';
        $notnav[]='login';
        $notnav[]='regsave';
    }
    if(!in_array($type,$notloginarray)){
        
        $UO->check_login();
    }
    
    if($type=='memberhome'){
        
        if(empty($user_name)||empty($userinfo)){
            header('Location:index.php?act=user&type=reg&lang='.$language);
        }else{
            $tpl->assign('userinfo',$userinfo);
        }
    }elseif ($type=='edituserinfo'){
        $publinks=array('text'=>$LANG['go_on'],'href'=>'index.php?act=user&type=edituserinfo&lang='.$language);
        if(empty($user_name)||empty($userinfo)){
            $dtb->sysbox($LANG['error'].$LANG['tips'],$user_lang['notlogin']);
        }else{
            $tpl->assign("user_info",$userinfo);
        }
         if(!empty($_POST)){
             $userprame=array(
                'user_truename'=>$_POST['user_truename'],
                'user_email'=>$_POST['user_email'],
                'user_q'=>$_POST['user_q'],
                'user_a'=>$_POST['user_a'],
                'user_address'=>$_POST['user_address'],
                'user_address2'=>$_POST['user_address2'],
                'companyname'=>$_POST['companyname'],
                'come_from'=>$_POST['come_from'],
                'user_province'=>$_POST['user_province'],
                'user_city'=>$_POST['user_city'],
                'user_qq'=>$_POST['user_qq'],
                'user_orther'=>$_POST['user_orther'],
                'user_orther_num'=>$_POST['user_orther_num'],
                'user_tel'=>$_POST['user_tel'],
                'user_mob'=>$_POST['user_mob'],
             );
             if(empty($_POST['user_pass'])){
                    unset($userprame['user_pass']);
                }else{
                    $userprame['user_pass']=md5($_POST['user_pass']);
                }
                $modfyok=$db->autoExecute($dtb->table("users"),$userprame,"UPDATE"," user_id='$user_id'");
                if($modfyok){
        			$dtb->sysbox($LANG['success'].$LANG['tips'],$user_lang['modify_userinfo'].$LANG['success'],$publinks);
        		}else{
        			$dtb->sysbox($LANG['error'].$LANG['tips'],$user_lang['modify_userinfo'].$LANG['failure'],$publinks);
        		}
         }
        
    }elseif ($type=='reg'){
        
        $tpl->assign("user_info",$user_lang);
        
    }elseif ($type=='login'){    
        if(!empty($_POST)){
            $UO->user_login($_POST['user_name'],$_POST['user_pass']);
        }
    }elseif ($type=='regsave'){
        $publinks=array('text'=>$LANG['go_on'],'href'=>'index.php?act=user&type=login&lang='.$language."&url=".rawurldecode($_GET['url']));
         if(!empty($_POST)){
           
        $checkarray=array('user_name','user_pass','user_pass2','user_email');
        	foreach ($checkarray as $val){
        		if(empty($_POST[$val])){
        			$dtb->sysbox($LANG['error'].$LANG['tips'],$user_lang[$val].$LANG['no_empty'],$publinks);
        		}
        	}
        	if(!$UO->check_useranme($_POST['user_name'])){
        	       $dtb->sysbox($LANG['error'].$LANG['tips'],$user_lang['user_nopass'],$publinks);   
        	}
        	if($_POST['user_pass']!=$_POST['user_pass2']){
        		$dtb->sysbox($LANG['error'].$LANG['tips'],$user_lang['user_pass'].",".$user_lang['user_pass'].$user_lang['not_check'],$publinks);
        	}
        	if(!is_email($_POST['user_email'])){
        		$dtb->sysbox($LANG['error'].$LANG['tips'],$user_lang['user_email'].$user_lang['cls_error'],$publinks);
        	}
        	if($UO->check($_POST['user_name'])){
        		$dtb->sysbox($LANG['error'].$LANG['tips'],$user_lang['user_name'].$user_lang['userisfound'],$publinks);
        	}else{
        		$userprame=array(
        			'user_name'=>$_POST['user_name'],
        			'user_pass'=>$_POST['user_pass'],
        			'user_pass2'=>md5(trim($_POST['user_pass'])),
        			'user_email'=>$_POST['user_email'],
        		);
        		$addok=$UO->adduser($userprame);
        		if($addok){
        		    if(!empty($_GET['url'])){
        		        $publinks['href']=rawurldecode($_GET['url']);
        		    }
        		    $UO->user_login($userprame['user_name'],trim($_POST['user_pass']));
        			$dtb->sysbox($LANG['success'].$LANG['tips'],$LANG['reg'].$LANG['success'],$publinks);
        		}else{
        			$dtb->sysbox($LANG['error'].$LANG['tips'],$LANG['reg'].$LANG['failure'],$publinks);
        		}
        	}
        }else {
            $dtb->sysbox($LANG['error'].$LANG['tips'],$LANG['reg'].$LANG['param_error'],$publinks);
        }
    }elseif ($type=='order_list'){
        $tablename='order';
        
        $sql="SELECT * FROM ".$dtb->table($tablename);
        $sqlwhere=" WHERE user_id='$user_id' AND lang='$language' ORDER BY order_id DESC ";
        $pager['page']=intval($_GET['page']);
        $pager['pagesize']=empty($siteconfig['goods_pagesize'])?12:intval($siteconfig['goods_pagesize']);
        $pager=get_page("order",$sqlwhere,$pager);
        
        $sql=$sql.$sqlwhere." LIMIT ".$pager['satrt']." , ".$pager['pagesize'];
        $list=$db->getAll($sql);
        $mainarr=$_GET;
        unset($mainarr['page']);// 去掉page 参数。
        foreach ($mainarr as $keys=>$values){
            if(!empty($mainurls)){
                $mainurls.="&$keys=$values";
            }else{
                $mainurls="$keys=$values";
            }
        }
        
        $main_url="index.php?".$mainurls;
            /* 分页功能          */
            $page_arg=array('total'=>$pager['readcount'],
            'perpage'=>$pager['pagesize'],
            'page_name'=>'page',
            'url'=>$main_url);
            require_once(ROOT_PATH.'include/page.class.php');
            $pagex=new page($page_arg);
            $pagex->first_page=$LANG['first_page'];
            $pagex->next_page=$LANG['next_page'];
            $pagex->pre_page=$LANG['pre_page'];
            $pagex->last_page=$LANG['last_page'];
            $tpl->assign('page',$pagex->show(5));
            //print_r($list);
        $tpl->assign('pageinfo',$pager);
        $tpl->assign("list",$list);
    }elseif ($type=='orderview'){
        $tablename='order';
        $publinks=array('text'=>$LANG['go_on'],'href'=>'index.php?act=user&type=order_list&lang='.$language);
        $order_sn=$_GET['order_sn'];
        $order_info=get_order_info($order_sn,1);
        if(empty($order_info)){
            $dtb->sysbox($LANG['error'].$LANG['tips'],$user_lang['order_notfind'],$publinks);
            
        }else{
            if(file_exists(LANG_PATH."pay_order_{$language}.php")){
                $tmeplang=require(LANG_PATH."pay_order_{$language}.php");
                $LANG=array_merge($LANG,$tmeplang);
                $tpl->assign('LANG',$LANG);
            }
            $order_info['user_info']=$UO->getuserinfo($order_info['user_id']);
            $order_info['good_list']=get_order_goods($order_sn);
            for ($i=0;$i<count($order_info['good_list']);$i++){
                $order_info['good_list'][$i]['goods_price']=format_price($order_info['good_list'][$i]['goods_price']);
                $order_info['good_list'][$i]['goods_enprice']=format_price($order_info['good_list'][$i]['goods_enprice']);
                $order_info['good_list'][$i]['goods_info']=get_goods_info($order_info['good_list'][$i]['goods_id']);
            }
            $order_info['good_listbar']=sprintf($LANG['all_goods_bar'],count($order_info['good_list']));
            $order_info['order_statustext']=$LANG['order_status_'.$order_info['order_stats']];
            $order_info['pay_statustext']=$LANG['pay_status_'.$order_info['pay_stats']];
            $order_info['post']=get_postmethod($order_info['post_methods']);
            $order_info['pay']=get_paymethod($order_info['pay_methods']);
            /*如果已经启用了支付方式*/            
            if($siteconfig['online_pay']==1){
                $payfile=ROOT_PATH."tools/paymethod/".$order_info['pay']['filename'];
                if(!empty($order_info['pay'])&&file_exists($payfile)){
                    require_once($payfile);
                    $pay=new $order_info['pay']['class_name']();
                    if($order_info['pay_stats']<=2){
                           $payment=get_paymethod($order_info['pay_methods']," * ");
                           $order_info['pay_code']=$pay->get_code($order_info,$payment);
                    }
                }
            }
            //print_r($order_info);die();
            
            $tpl->assign('order',$order_info);
        }
    }elseif ($type=='logout'){
        $userinfo=$UO->get_userinfo($user_name);
    
        $publinks=array('text'=>$user_lang['relogin'],'href'=>'index.php?act=user&type=login&lang='.$language);
        if(!empty($userinfo)){ 
        foreach ($userinfo as $key=>$vals){
             $dtb->setcookies($key,'',time()-3600);
         }
        }
         $dtb->sysbox($LANG['error'].$LANG['tips'],$user_lang['logoutok'],$publinks);
    }else {
        die("ERR.");
    }
    
   $ui=0;
   foreach ($userarray as $vs){
        if(!in_array($vs,$notnav)){
           $usernav[$vs]=$LANG[$vs];
        }
   }
   $tpl->assign("user_lang",$user_lang);
   $tpl->assign("usernav",$usernav);
   $tpl->assign("type",$type);
   $tpl->assign("sys_onnav",$sys_onnav."&gt;&gt;".$LANG[$type]);
   $outhtml=$tpl->fetch("{$action}.html",$cache_id);
   $dtb->outhtml($outhtml); 
}elseif ($action=='downimage'){
    $goods_sn=trim($_GET['goods_sn']);
    $download=trim($_GET['download']);
    if(empty($goods_sn)){
        $html=file_get_contents(ROOT_PATH."tools/orthers/doanimage.html");
        die($html);
    }else{
        // 进行商品图片下载。
        if($download!='yes'){
            $sql="SELECT bigimage,goods_sn,goods_id FROM ".$dtb->table('goods')." WHERE goods_sn='$goods_sn' LIMIT 0,100 "; //只显示相同货号的前100个。
            $allsn=$db->getALL($sql);
            if(!empty($allsn)){
                if(count($allsn)<2){
                    $goods_id=$allsn[0]['goods_id'];
                    header("Location:index.php?act={$action}&goods_sn={$goods_sn}&goods_id={$goods_id}&download=yes");
                }else{
                    echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><title>Download Image</title></head><body  style=" font-size:12px">'.
                    "总计 Count: ".count($allsn)." Time:".date("Y-m-d H:i:s")." <a href='index.php?act=downimage'>返回(Return)</a> <hr />";
                    $i=1;
                    foreach($allsn as $goods){
                        $goods_id=$goods['goods_id'];
                        echo "{$i}. <strong>商品货号(Item)</strong>: $goods_sn <a href='index.php?act={$action}&goods_sn={$goods_sn}&goods_id={$goods_id}&download=yes'>Download Image(下载图片)</a><br />";
                        $i++;
                    }
                    echo "<hr ><address>* 如果浏览器没有直接提示下载，请点击右键目标另存为！<br />If the browser did not directly prompt to download, please right-click Save Target As!</address>".$_SERVER['SERVER_SIGNATURE']."</body></html>";
                }
            }else{
                die("商品货号错误(No commodity mistake).");
            }
        }else{
            // 正式开始下载商品图片。
            $goods_id=trim($_GET['goods_id']);
            if(!empty($goods_id)||!empty($goods_sn)){
                if(empty($goods_id)){
                $sql="SELECT bigimage,goods_sn FROM ".$dtb->table('goods')." WHERE goods_sn='$goods_sn' ";
                }else{
                 $sql="SELECT bigimage,goods_sn FROM ".$dtb->table('goods')." WHERE goods_id='$goods_id' ";   
                }
                $imagefile=$db->getOne($sql);
                if(empty($imagefile)||!file_exists(ROOT_PATH.$imagefile)){
                    die("该商品图片不存在，请返回重试。<br />The picture of goods does not exist, go back to try again.");
                }else{
                    // 发送给浏览器下载信息。
                    $fileinfo=explode(".",$imagefile);
                    $fileext=$fileinfo[1];
                    $fileName=$goods_sn; //以货号作为下载的文件名。
                    header("content-type:application/octet-stream");
                    header("content-disposition:attatchment;filename=\"{$fileName}.{$fileext}\"");
                    header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
                    header('Accept-Ranges: bytes'); 
                    header('Expires:0');
                    header('Pragma:public');
                    print(file_get_contents(ROOT_PATH.$imagefile));
                }
                
            }else{
                die("参数错误，请返回重试。	<br />Parameter error, please return to try again.");
            }
        }
    }
    
    
/*其它栏目*/
}else{
    $get_navact=get_navact();   
    if(!in_array($action,$get_navact)){
        
        if(!file_exists(ROOT_PATH.dirname($_SERVER['SCRIPT_NAME'])."{$action}.html")){
        @header('HTTP/1.1 404 Not Found');
        @header('Status: 404 Not Found');
        $publinks=array('text'=>$LANG['go_on'],'href'=>'index.php?lang='.$language);
        $url_this =  "http://".$_SERVER ['HTTP_HOST'].$_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
        $dtb->sysbox($LANG['error'].$LANG['tips'],"<li>1. ".$LANG['not_found_gohome']."</li>\n".
            "<li>2. ".$LANG['pageiserror']."</li>\n<li>3. ".$LANG['yourgopage'].":".$url_this."</li>",$publinks);
        }else{
            die(file_get_contents(ROOT_PATH.dirname($_SERVER['SCRIPT_NAME'])."{$action}.html"));
        }
    }else{
        if(!$tpl->is_cached("columns.html",$cache_id)){
            $columos=get_columns($action);
            if(empty($columos)){
                $dtb->sysbox($LANG['error'].$LANG['tips'],"<li>1. ".$LANG['not_found_gohome']."</li>\n".
                    "<li>2. ".$LANG['pageiserror']."</li>",$publinks);
            }else{
             $tpl->assign("data",$columos);
             if($language=='zh-cn'){
                $tpl->assign("page_title",$columos['cntitle']);
             }else{
                $tpl->assign("page_title",$columos['entitle']);
             }
            }
        }
        $outhtml=$tpl->fetch("columns.html",$cache_id);
        $dtb->outhtml($outhtml);
    }
}
?>