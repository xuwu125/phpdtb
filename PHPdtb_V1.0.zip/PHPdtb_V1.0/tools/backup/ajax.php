<?php
/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */

/**
 * 
 * ========================================================================
 * Appname:     PHPdtb 开源网站系统AJAX Api server 
 * Verison:     1.0.0.1280
 * Update:      2008-11-4
 * Author:      xuwu <xuwu125@gmail.com>
 * Website:     www.opensources.org.cn
 * Filename:    ajax.php
 * ========================================================================
 * */
$install_lockfile="./tools/install.lock";
if(!file_exists($install_lockfile)){
    die("对不起，请先运行安装程序。<a href='install.php'>马上安装</a>");
}
define('IN_SITE',true);
define('SET_Smarty',false);
define('NOSET_AJAX',false);
include_once('include/init.php');
$ajaxlang=empty($_GET['lang'])?"zh-cn":trim($_GET['lang']);
if(empty($action)){
    die("ERR");
/*  提取所有的E-mail地址。  */
}elseif ($action=='add_cart'){
    $goods_id=urldecode($_REQUEST['goods_id']);
    if(empty($goods_id)){
        die("ERR");
    }else{
        $goods=add_cart($goods_id);
        if(!empty($goods)){
            die("OK");
        }else{
            die("ERR");
        }
    }
    
/*更新购物车*/
}elseif ($action=='update_cart'){
    $goods_id=intval(urldecode($_REQUEST['goods_id']));
    $goods_count=intval($_REQUEST['count']);
    if(empty($goods_id)){
        die("ERR");
    }else{
        $goodsinfo=getgoodsinfo($goods_id);
        /* 商品不存在 */
        if(empty($goodsinfo)){
            die("ERR");
        }else{
            
            $update=update_cart($goods_id,$goods_count,$goodsinfo);
            if($update){
                die("OK");
            }else{
                die("ERR");
            }
        }
    }
/*删除购物车中的物品*/
}elseif ($action=='del_cart'){  
    $goods_id=urldecode($_REQUEST['goods_id']);
    if(empty($goods_id)){
        die("ERR");
    }else{
        $where=" goods_id='$goods_id' AND sessid='".SESS_ID."' ";
        $sql="DELETE FROM ".$dtb->table("cart")." WHERE $where ";
        $del=$db->query($sql);
        if($del){
            die("OK");
        }else{
            die("ERR");
        }
    }
/*支付方式*/
}elseif ($action=='pay_methods'||$action=='post_methods'){
    require_once(ROOT_PATH.'include/cls_json.php');
    $json=new JSON;
    $result=array("error"=>"ERR");
    $ispasswhere=" `ispass`='1' ";
    
    if($action=='pay_methods'){
        $tablename='paymethod';
        if($GLOBALS['language']!='zh-cn'){
            $ispasswhere=" `enispass`='1' ";
        }
    }else{
        $tablename='postmethod';
    }
    $id=$_GET['id'];$langx=$_GET['lang'];
    if(empty($id)){
        die($json->encode($result));
    }
    $sql="SELECT * FROM ".$dtb->table($tablename)." WHERE `id`='$id' AND ispass='1' ";
    $data=$db->getRow($sql);
    if($data){
        $result['error']='OK';
        if($langx=='zh-cn'){
            $result['des']=$data['cndes'];
        }else{
            $result['des']=$data['endes'];
        }
        $result['action']=$action;
        $result['data']=$data;
    }
    die($json->encode($result));
/*  其它意外情况   */
}else{
    die("ERR");
}


/**
 * 增加商品到购物车
 *
 * @param int $goods_id     商品ID
 * @return bool             返回执行状态
 */
function add_cart($goods_id){
    $where=" goods_id='$goods_id' AND sessid='".SESS_ID."' ";
    $sql="SELECT * FROM ".$GLOBALS['dtb']->table("cart")." WHERE $where LIMIT 0,1";
    $goods=$GLOBALS['db']->getRow($sql);
    $goodsinfo=getgoodsinfo($goods_id);
    if(empty($goodsinfo['mini_order'])){
        $goodsinfo['mini_order']=1;
    }
    
    $good=array("goods_id"=>$goods_id,'count'=>$goodsinfo['mini_order'],
        "price"=>$goodsinfo['goods_price'],"enprice"=>$goodsinfo['goods_enprice'],"sessid"=>SESS_ID);

    if(empty($goods)){
        return $GLOBALS['db']->autoExecute($GLOBALS['dtb']->table("cart"),$good,'INSERT');
    }else{
        $good=array('count'=>$goods['count']+1);
        return $GLOBALS['db']->autoExecute($GLOBALS['dtb']->table("cart"),$good,'UPDATE',$where);
    }
}


/**
 * 更新购物车中的商品
 *
 * @param int $goods_id         商品ID
 * @param int $goods_count      商品数量
 * @return bool                 返回执行状态
 */
function update_cart($goods_id,$goods_count,$goodsinfo){
    if(empty($goods_count)){
        $goods_count=empty($goodsinfo['mini_order'])?1:intval($goodsinfo['mini_order']);
    }
    $good['count']=$goods_count;
    $where=" goods_id='$goods_id' AND sessid='".SESS_ID."' ";
    return $GLOBALS['db']->autoExecute($GLOBALS['dtb']->table("cart"),$good,'UPDATE',$where);
}

?>