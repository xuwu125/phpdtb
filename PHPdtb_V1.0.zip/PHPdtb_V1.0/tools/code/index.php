<?php
/**
 * PHP PHP 中文版验证码 PHP Chinese CODE V1.0 
 * @author ：xuwu125 <xw-09@163.com> 
 * @access :Public user
 * @example :直接使用?test=yes 参数可以看到所有测试
 * @copyright 远洋门户版权所有 www.023si.com
 * @param ?test=yes     测试用的
 * @param ?type=*       区分验证码类型的。
 * @param ?f=*          字体文件名
 * @param ?r=*          验证码长度
 * @param ?s=*          验证码产生的SESSION 的名称
 * @param ?clear=cache  清空所有缓存的解析文件[tmp]目录。
 **/
define('IN_SITE',true);
define('NOT_START',true);
$_CFG=include('../../config.inc.php');// 首先加载配置文件。
$_CFG['site_url']=str_replace($_CFG['adminpath'],"",$_CFG['site_url']);
define('ROOTPATH', str_replace('tools/code/index.php', '', str_replace('\\', '/', __FILE__)));
include_once(ROOTPATH."/include/init.php");
$sess->max_life_time=300;
$programe_name="PHP 中文版验证码，可以自由扩展";
$verison="PHP Chinese CODE V1.0 ";

$RANDCODE=array('一','地','在','要','工','上','是','中','国','同','意','漫','望','天','外','云','花','我','爱','你','变','动','得','失');
//生成附加码
$randnum=4;
$temp="____temp.tmp";    // 临时文件名
$codepath='codetable.txt';           // 汉字表，只有当后面跟有type＝1 时才会有效果。
function create_phpcode($length=4,$sessionname='excode',$font_face='simkai.ttf'){
    @session_start();
    global $RANDCODE;
    header("content-type: image/png");
    $image_x=$length*22;    //图片宽度
    $image_y=25;            //图片高度
    $noise_num=20*$length;   //杂点数量
    $line_num=$length/2;      //干扰线数量
    $image=imagecreate($image_x,$image_y);
    imagecolorallocate($image,0xff,0xff,0xff);                  //设定背景颜色
    $rectangle_color=imagecolorallocate($image,0xAA,0xAA,0xAA); //边框颜色
    $noise_color=imagecolorallocate($image,0x00,0x00,0xff);     //杂点颜色
    $font_color=imagecolorallocate($image,0x00,0x00,0xFF);      //字体颜色
    $line_color=imagecolorallocate($image,0x33,0x33,0xff);      //干扰线颜色
    $font_face="font/".$font_face;
    if(!file_exists($font_face)){$font_face="simkai.ttf";}
    //加入杂点
    for($i=0;$i<$noise_num;$i++)
    imagesetpixel($image,mt_rand(0,$image_x),mt_rand(0,$image_y),$noise_color);
    $x=2;
    $session_code='';
    for($i=0;$i<$length;$i++)
    {
        $code=$RANDCODE[mt_rand(0,count($RANDCODE)-1)];
     imagettftext($image,14,mt_rand(-6,6),$x,18,$font_color,$font_face,$code);
        $x+=22;
        $session_code.=$code;
    }
    $_SESSION[$sessionname]=$session_code;  //把附加码的值放在session中
    //加入干扰线
    for($i=0;$i<$line_num;$i++)
    imageline($image,mt_rand(0,$image_x),mt_rand(0,$image_y),
    mt_rand(0,$image_x),mt_rand(0,$image_y),$line_color);
    imagerectangle($image,0,0,$image_x-1,$image_y-1,$rectangle_color);  //加个边框
    imagepng($image);
    imagedestroy($image);
}
if($_GET['type']!=0){
    // 自动创建目录
    if(!file_exists("tmp")){mkdir("tmp",0777);}
    if(!file_exists("font")){mkdir("font");}
    $temp="tmp/code[".intval($_GET['type'])."]".$temp;
    $codefiletime=filemtime($codepath);
    if(!file_exists($temp)||filemtime($temp)-$codefiletime<=0){
    
        
      $fcode2="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
      if($_GET['type']==1){
            $fcode=iconv("GB2312","UTF-8",file_get_contents($codepath));
            // 提取所有中文内容。
            $fcode=eregi_replace("\r\n|\n|\t|，|：|。|、|,|\'|\"|？|‘|’|“|”|《|》|（|）|！|\!|`|　|@|#|\$|%|&|\*|\(|\)|_|\=|\+|\-|\.|\~|\^|\[|\]|\￥|\<|\>|\/|…|[a-z0-9]","",$fcode);
      }elseif($_GET['type']==2){
            $fcode=strtolower($fcode2).strtoupper($fcode2);
      }elseif($_GET['type']==2){
            $fcode=$fcode2;
      }elseif($_GET['type']==3){
            $fcode=strtolower($fcode2);
      }elseif($_GET['type']==4){
            $fcode=strtolower($fcode2).strtoupper($fcode2)."0123456789";
      }elseif($_GET['type']==5){
            $fcode=strtolower($fcode2)."0123456789";
      }elseif($_GET['type']==6){
            $fcode=strtoupper($fcode2)."0123456789";
      }elseif($_GET['type']==7){
            $fcode=iconv("GB2312","UTF-8",file_get_contents($codepath));
            // 提取所有可用内容。
            $fcode=eregi_replace("\r\n|\n|\t|，|：|。|、|,|\'|\"|？|‘|’|“|”|《|》|（|）|！|\!|`|　|@|#|\$|%|&|\*|\(|\)|_|\=|\+|\-|\.|\~|\^|\[|\]|\￥|\<|\>|\/|…","",$fcode);
      
      }elseif($_GET['type']==8){
      	  	$fcode="0123456789";
      }
      
      $fcode=str_replace(array(' ','$',"|",":","."),"",$fcode);
      $fcodelen=strlen($fcode);
      if($fcodelen>=4){
          $RANDCODE=array();
          for ($i=0;$i<=$fcodelen;$i++){
              // 防止重复。
              $fonts=mb_substr($fcode,$i,1,"UTF-8");
              if(!in_array($fonts,$RANDCODE)&&$fonts!=""){
              $RANDCODE[]=$fonts;
              }
          }
      }
      // 写缓存文件，让它速度达到最快。
      $RANDCODE_tmp="<?php\n\n/**\n*Programe name:$programe_name\n*Verison：$verison\n*Website:http://www.023si.com http://www.php-class.cn\n*E-mail:xw-09@163.com xuwu125@gmail.com\n*Code file time:".date("Y-m-d H:i:s",$codefiletime)."\n*Temp file time:".date("Y-m-d H:i:s")."\n**/ \n return array('".implode("','",$RANDCODE)."');\n?>";
      file_put_contents($temp,$RANDCODE_tmp);
    }else{
       $RANDCODE=include($temp);
    }
}
if(!empty($_GET['r'])&&$_GET['r']>=4){
    $randnum=intval($_GET['r']);
}else{
    $randnum=$randnum;
}
if(!empty($_GET['clear'])=='cache'){
    foreach (glob('tmp/*.tmp') as $tp){
        @unlink($tp);
    }
    die("清除缓存完毕，所以验证码的解析将重新开始！");
}

if(empty($_GET['test'])){
    $f=empty($_GET['f'])?"":urldecode(trim($_GET['f']));
    //print_r($_GET);
    if(!empty($_GET['s'])&&strlen($_GET['s'])>=4){
        $sessionname=$_GET['s'];
        if(empty($f)){
        create_phpcode($randnum,$sessionname);
        }else{
        create_phpcode($randnum,$sessionname,$f);    
        }
    }else{
         if(empty($f)){
            create_phpcode($randnum);
         }else{
             create_phpcode($randnum,"sessioncode",$f);
         }
    }
}
/*以下是测试代码用的。(可以删除的,不会影响程序的)*/
if($_GET['test']='yes'){
    echo "<h2>$programe_name - 效果测试工具</h2>";
    echo "<h4>版本：$verison  <a href='http://www.023si.com' target='_blank' >www.023si.com</a> </h4>";
    echo "<br />不同类型的验证码:";
    for ($i=0;$i<=7;$i++){
        echo "<br />效果<b>$i</b>：<img src='?type=$i'>";
    }
    echo "<br />不同类型不同长度的验证码(最小长度4位):";
    for ($i=0;$i<=7;$i++){
        for ($i2=4;$i2<=10;$i2++){
            echo "<br />效果<b>$i</b> (长度为<b>$i2</b>)：<img src='?type=$i&r=$i2'>";
        }
    }
    echo "<br />不同类型不同长度不同的Session name的验证码(最小长度4位):";
    for ($i=0;$i<=7;$i++){
        for ($i2=4;$i2<=8;$i2++){
            $sessionnames="Session_".$i."_".$i2;
            echo "<br />效果$i (长度为$i2) Session name=<b>$sessionnames</b> ：<img src='?type=$i&r=$i2&s=$sessionnames'>";
        }
    }
    echo "<br />字体目录[font]自动识别测试效果:";
    $fontlist=glob("{font/*.ttf,font/*.TTF}",GLOB_BRACE );
    if(empty($fontlist)){
        echo "<br />没有字体文件。";
    }else{
        foreach ($fontlist as $flist){
            $flist=str_replace("font/","",$flist);// 只要名字就可以了。
            echo "<br />字体文件[$flist]效果<b>$i</b>：<img src='?type=7&f=".urlencode($flist)."'>";
        }
    }
    echo "<br />Session 内容如下:\n";
    $slist="<?php \$_SESSION_LIST=".var_export($_SESSION,true)."; ?>";
    echo highlight_string($slist);
    echo "<br />$programe_name 源码如下:\n";
    echo highlight_file(__FILE__);
    echo "<br />所有测试完毕。以上效果可以有更多组合，如果图片不显示，就说明服务器不支持！";
}
?>
