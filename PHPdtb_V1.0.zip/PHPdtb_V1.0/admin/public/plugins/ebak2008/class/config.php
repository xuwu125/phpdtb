<?php
/**
 * Dtb api 
 * 
 * */
define('DBBACKUP_PATH', str_replace($_CFG['adminpath'].'config.php', '', str_replace('\\', '/', __FILE__)));
define('DTB_PATH', str_replace("admin/public/plugins/ebak2008/class/","",DBBACKUP_PATH));
define('ADMIN_PATH', str_replace("public/plugins/ebak2008/class/","",DBBACKUP_PATH));
$_CFG=require(DTB_PATH."config.inc.php");
$loginof=@file_get_contents(ADMIN_PATH."public/data/database_yes.tmp");
if(empty($loginof)){
    header("Content-Type:text/html; charset=utf-8");
    die("非法访问");
}
//Database
$phome_db_ver="";
$phome_db_server=$_CFG['db_host'];
$phome_db_port="3306";
$phome_db_username=$_CFG['db_user'];
$phome_db_password=$_CFG['db_pwd'];
$phome_db_dbname=$_CFG['db_database'];
$baktbpre="";
$phome_db_char="utf8";

//USER
$set_username="welldone";
$set_password="1650939b1e5e4c94299815b977141de9";
$set_outtime="60";
$set_loginkey="1";

//COOKIE
$phome_cookiedomain="";
$phome_cookiepath="/";
$phome_cookievarpre="ebak_";

//LANGUAGE
$langr=@ReturnUseEbakLang();
$ebaklang=$langr['lang'];
$ebaklangchar=$langr['langchar'];

//BAK
$bakpath="bdata";
$bakzippath="zip";
$filechmod="1";
$phpsafemod="";
$php_outtime="1000";
$limittype="";
$canlistdb="";

//------------ SYSTEM ------------
@HeaderIeChar();
?>