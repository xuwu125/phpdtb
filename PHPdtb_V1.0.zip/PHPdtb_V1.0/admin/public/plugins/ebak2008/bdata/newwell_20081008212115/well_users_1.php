<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_users`;");
E_C("CREATE TABLE `well_users` (
  `user_id` int(10) unsigned NOT NULL auto_increment,
  `user_name` varchar(24) NOT NULL,
  `user_truename` varchar(8) NOT NULL COMMENT '真实姓名',
  `user_pass` varchar(32) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_q` varchar(255) NOT NULL,
  `user_a` varchar(255) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_province` varchar(100) NOT NULL default '浙江省',
  `user_city` varchar(100) NOT NULL default '杭州市',
  `user_qq` int(10) unsigned NOT NULL,
  `user_orther` varchar(255) NOT NULL,
  `user_orther_num` varchar(255) NOT NULL,
  `user_tel` varchar(255) NOT NULL,
  `user_mob` varchar(255) NOT NULL,
  `user_money` decimal(8,2) NOT NULL default '0.00',
  `user_rank` tinyint(3) unsigned NOT NULL default '0',
  `user_integral` int(10) unsigned NOT NULL default '0',
  `user_regip` varchar(32) NOT NULL default '127.0.0.1',
  `user_regtime` int(10) unsigned NOT NULL default '0',
  `user_lastlogintime` int(10) unsigned NOT NULL default '0',
  `user_lastloginip` varchar(32) NOT NULL default '127.0.0.1',
  `user_logincount` int(10) unsigned NOT NULL default '1',
  `user_lock` tinyint(1) unsigned NOT NULL default '0' COMMENT '锁定会员',
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `user_name` (`user_name`,`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8");
E_D("replace into `well_users` values('1','xuwu125','徐武','e10adc3949ba59abbe56e057f20f883e','xuwu125@gmail.com','123456','654321','浙江省杭州市上城区','浙江省','杭州市','283573363','MSN','xuwu125@hotmail.com','0579-83805668','13992526528','0.00','0','0','127.0.0.1','1223178058','1223178058','127.0.0.1','1','0');");
E_D("replace into `well_users` values('2','xuwu122','徐武2','e10adc3949ba59abbe56e057f20f883e','xuwu125@gmail.com','123456','654321','浙江省杭州市上城区环城东路','浙江省','杭州市','283573363','MSN','xuwu125@hotmail.com','0579-83805668','13992526528','0.00','0','0','127.0.0.1','1223178058','1223178058','127.0.0.1','1','0');");

@include("../../inc/footer.php");
?>