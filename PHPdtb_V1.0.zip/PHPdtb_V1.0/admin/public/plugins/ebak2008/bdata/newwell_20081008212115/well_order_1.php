<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_order`;");
E_C("CREATE TABLE `well_order` (
  `order_id` int(10) unsigned NOT NULL auto_increment,
  `order_sn` varchar(32) NOT NULL COMMENT '订单号',
  `money` decimal(8,2) unsigned NOT NULL default '0.00' COMMENT '商品金额',
  `addtime` int(10) unsigned NOT NULL default '0' COMMENT '订单时间',
  `order_stats` tinyint(3) unsigned NOT NULL default '0' COMMENT '订单状态',
  `pay_stats` tinyint(3) unsigned NOT NULL default '0' COMMENT '支付状态',
  `post_methods` int(10) unsigned NOT NULL default '0' COMMENT '配送方式',
  `pay_methods` int(10) unsigned NOT NULL default '0' COMMENT '支付方式',
  `money_all` decimal(8,2) unsigned NOT NULL default '0.00' COMMENT '总金额',
  `linkmeninfo` text NOT NULL COMMENT '联系人等信息',
  `goods_count` int(10) unsigned NOT NULL default '1' COMMENT '商品总数',
  `fee_money` decimal(8,2) NOT NULL default '0.00' COMMENT '邮费',
  `orther_money` decimal(8,2) NOT NULL default '0.00' COMMENT '折扣金额',
  `admin_user` varchar(255) NOT NULL COMMENT '最后的操作人员',
  PRIMARY KEY  (`order_id`),
  UNIQUE KEY `order_sn` (`order_sn`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8");
E_D("replace into `well_order` values('1','200809020102','5.00','1219939494','1','1','0','0','0.00','联系人：徐武','1','0.00','1.00','admin');");
E_D("replace into `well_order` values('2','200809020108','5.00','1219939494','1','1','2','3','0.00','联系人：徐武','1','0.00','1.00','admin');");
E_D("replace into `well_order` values('3','68062461221496204','51.00','1221496406','0','0','4','1','51.00','姓名:fdsa<br />\n电话:saf<br />\n地址:safd<br />\n传真:dsafd<br />\n电子邮件:f<br />\n备注:fdsa','11','0.00','0.00','');");
E_D("replace into `well_order` values('4','97362451221497151','8.00','1221497601','0','0','2','1','8.00','姓名:vfdsa<br />\n电话:fdsafd<br />\n地址:safds<br />\n传真:fdsafd<br />\n电子邮件:safds<br />\n备注:afdsafdsafds','4','0.00','0.00','');");
E_D("replace into `well_order` values('5','87476951221497650','8.00','1221497650','0','0','2','1','8.00','姓名:vfdsa<br />\n电话:fdsafd<br />\n地址:safds<br />\n传真:fdsafd<br />\n电子邮件:safds<br />\n备注:afdsafdsafds','4','0.00','0.00','');");
E_D("replace into `well_order` values('6','73207641221497749','8.00','1221497749','0','0','2','1','8.00','姓名:vfdsa<br />\n电话:fdsafd<br />\n地址:safds<br />\n传真:fdsafd<br />\n电子邮件:safds<br />\n备注:afdsafdsafds','4','0.00','0.00','');");
E_D("replace into `well_order` values('7','31526611221498036','3.20','1221498105','0','0','3','1','3.20','姓名:徐武<br />\n电话:07985792498732<br />\n地址:中国浙江<br />\n传真:0571-888888<br />\n电子邮件:xw-09@163.com<br />\n备注:备注','3','0.00','0.00','');");
E_D("replace into `well_order` values('8','12072841221498256','62.00','1221498265','0','0','1','1','62.00','姓名:fdsafdsa<br />\n电话:fdsa<br />\n地址:fdsa<br />\n传真:fdsaf<br />\n电子邮件:fdsa<br />\n备注:fdsafdsa','62','0.00','0.00','admin');");
E_D("replace into `well_order` values('9','72920621221667869','78.60','1221667914','1','1','3','1','78.60','姓名:姓名<br />\n电话:电话<br />\n地址:地址<br />\n传真:传真<br />\n电子邮件:电子邮件<br />\n备注:备注','56','0.00','0.00','admin');");

@include("../../inc/footer.php");
?>