<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_price`;");
E_C("CREATE TABLE `well_price` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cnname` varchar(100) NOT NULL,
  `enname` varchar(100) NOT NULL,
  `cndes` text NOT NULL,
  `endes` text NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `ispass` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8");
E_D("replace into `well_price` values('1','1-2元','1-2RMB','1-2美元','1-2美元','1','1');");

@include("../../inc/footer.php");
?>