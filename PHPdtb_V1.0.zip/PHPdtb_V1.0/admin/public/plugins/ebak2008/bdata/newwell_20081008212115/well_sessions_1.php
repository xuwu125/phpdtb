<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_sessions`;");
E_C("CREATE TABLE `well_sessions` (
  `sesskey` char(32) character set utf8 collate utf8_bin NOT NULL default '',
  `expiry` int(10) unsigned NOT NULL default '0',
  `userid` mediumint(8) unsigned NOT NULL default '0',
  `adminid` mediumint(8) unsigned NOT NULL default '0',
  `ip` char(15) NOT NULL default '',
  `data` char(255) NOT NULL default '',
  PRIMARY KEY  (`sesskey`),
  KEY `expiry` (`expiry`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8");
E_D("replace into `well_sessions` values('d8f3405289d63a51725378e5d2d8c6a6','1223472040','0','1','127.0.0.1','a:4:{s:9:\"user_code\";s:4:\"0322\";s:8:\"admin_id\";s:1:\"1\";s:9:\"user_name\";s:5:\"admin\";s:9:\"user_comp\";s:3:\"all\";}');");

@include("../../inc/footer.php");
?>