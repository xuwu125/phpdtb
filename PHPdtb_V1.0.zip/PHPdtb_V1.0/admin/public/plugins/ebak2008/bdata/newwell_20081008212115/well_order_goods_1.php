<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_order_goods`;");
E_C("CREATE TABLE `well_order_goods` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `order_sn` varchar(255) NOT NULL,
  `goods_id` int(11) unsigned NOT NULL default '0',
  `goods_sn` varchar(255) NOT NULL,
  `goods_price` decimal(8,2) NOT NULL default '0.00',
  `goods_count` int(11) unsigned NOT NULL default '0',
  `addtime` int(11) NOT NULL COMMENT '备注',
  PRIMARY KEY  (`id`),
  KEY `goods_id` (`goods_id`,`goods_sn`),
  KEY `order_sn` (`order_sn`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8");
E_D("replace into `well_order_goods` values('1','200809020102','1','fdsafdsafdsa','1.00','1','0');");
E_D("replace into `well_order_goods` values('2','97362451221497151','0','','0.00','4','1221497601');");
E_D("replace into `well_order_goods` values('3','97362451221497151','0','','0.00','4','1221497601');");
E_D("replace into `well_order_goods` values('4','97362451221497151','0','','0.00','4','1221497601');");
E_D("replace into `well_order_goods` values('5','97362451221497151','0','','0.00','4','1221497601');");
E_D("replace into `well_order_goods` values('6','87476951221497650','0','','0.00','4','1221497650');");
E_D("replace into `well_order_goods` values('7','87476951221497650','0','','0.00','4','1221497650');");
E_D("replace into `well_order_goods` values('8','87476951221497650','0','','0.00','4','1221497650');");
E_D("replace into `well_order_goods` values('9','87476951221497650','0','','0.00','4','1221497650');");
E_D("replace into `well_order_goods` values('10','73207641221497749','0','','0.00','4','1221497749');");
E_D("replace into `well_order_goods` values('11','73207641221497749','0','','0.00','4','1221497749');");
E_D("replace into `well_order_goods` values('12','73207641221497749','0','','0.00','4','1221497749');");
E_D("replace into `well_order_goods` values('13','73207641221497749','0','','0.00','4','1221497749');");
E_D("replace into `well_order_goods` values('14','31526611221498036','0','','0.00','3','1221498105');");
E_D("replace into `well_order_goods` values('15','31526611221498036','0','','0.00','3','1221498105');");
E_D("replace into `well_order_goods` values('16','12072841221498256','5','fdsafdsafdsa','1.00','5','1221498265');");
E_D("replace into `well_order_goods` values('17','12072841221498256','1','fdsafdsafdsa','1.00','57','1221498265');");
E_D("replace into `well_order_goods` values('18','72920621221667869','3','goods_sn','1.20','53','1221667914');");
E_D("replace into `well_order_goods` values('19','72920621221667869','4','dsafdsa','5.00','3','1221667914');");

@include("../../inc/footer.php");
?>