<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_paymethod`;");
E_C("CREATE TABLE `well_paymethod` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cnname` varchar(100) NOT NULL,
  `enname` varchar(100) NOT NULL,
  `endes` text NOT NULL,
  `cndes` text NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `ispass` tinyint(3) unsigned NOT NULL default '0',
  `filename` varchar(50) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8");
E_D("replace into `well_paymethod` values('1','贝宝中国','Paypal of china','Paypal of china','宝是由上海网付易信息技术有限公司与世界领先的网络支付公司—— PayPal 公司通力合作为中国市场度身定做的网络支付服务。（网址：http://www.paypal.com/cn）','2','1','paypalcn.php','paypalcn');");
E_D("replace into `well_paymethod` values('2','财付通','Tenpay','Tenpay','财付通网站 (www.tenpay.com) 作为功能强大的支付平台，是由中国最早、最大的互联网即时通信软件开发商腾讯公司创办，为最广大的QQ用户群提供安全、便捷、简单的在线支付服务。','4','1','tenpay.php','tenpay');");
E_D("replace into `well_paymethod` values('3','支付宝 ','Alipay','alipay','支付宝，是支付宝公司针对网上交易而特别推出的安全付款服务，其运作的实质是以支付宝为信用中介，在买家确认收到商品前，由支付宝替买卖双方暂时保管货款的一种增值服务。（网址：http://www.alipay.com）','3','1','alipay.php','alipay');");
E_D("replace into `well_paymethod` values('4','Paypal','Paypal','paypal ','PayPal 是在线付款解决方案的全球领导者，在全世界有超过七千一百六十万个帐户用户。PayPal 可在 56 个市场以 7 种货币（加元、欧元、英镑、美元、日元、澳元、港元）使用。（网址：http://www.paypal.com）','1','1','paypal.php','paypal');");
E_D("replace into `well_paymethod` values('5','货到付款','Max Muster Straße 21-23 D','Max Muster Straße 21-23 D','货到付款','5','1','muster.php','muster');");

@include("../../inc/footer.php");
?>