<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_status`;");
E_C("CREATE TABLE `well_status` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `ip` varchar(32) NOT NULL,
  `addtime` int(10) unsigned NOT NULL default '0',
  `referer` varchar(255) NOT NULL,
  `thisurl` varchar(255) NOT NULL,
  `browser` varchar(255) NOT NULL,
  `system` varchar(255) NOT NULL,
  `alexa` tinyint(3) unsigned NOT NULL default '0',
  `user_augrent` varchar(255) NOT NULL,
  `language` varchar(30) NOT NULL,
  `parent` varchar(30) NOT NULL,
  `orthers` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");

@include("../../inc/footer.php");
?>