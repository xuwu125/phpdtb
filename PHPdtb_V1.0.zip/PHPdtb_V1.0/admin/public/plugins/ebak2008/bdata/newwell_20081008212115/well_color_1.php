<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_color`;");
E_C("CREATE TABLE `well_color` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cnname` varchar(100) NOT NULL,
  `enname` varchar(100) NOT NULL,
  `cndes` text NOT NULL,
  `endes` text NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `ispass` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8");
E_D("replace into `well_color` values('1','黄色','orgeage','fdsafdsa','fdsafdsafdsa','3','1');");
E_D("replace into `well_color` values('2','红色','red','sdafd','safdsafdsa','1','1');");
E_D("replace into `well_color` values('3','蓝色','blue','fdsafdsa','fdsafdsafa','2','1');");

@include("../../inc/footer.php");
?>