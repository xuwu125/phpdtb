<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_categroy`;");
E_C("CREATE TABLE `well_categroy` (
  `cid` int(10) unsigned NOT NULL auto_increment,
  `cnname` varchar(255) NOT NULL,
  `enname` varchar(255) NOT NULL,
  `cndes` text NOT NULL,
  `endes` text NOT NULL,
  `ispass` tinyint(3) unsigned NOT NULL default '0',
  `order` int(10) unsigned NOT NULL default '0',
  `categoryid` int(10) unsigned NOT NULL default '0',
  `class_img` varchar(200) NOT NULL,
  `is_hot` tinyint(3) unsigned NOT NULL default '0',
  `cnkeywords` varchar(80) NOT NULL,
  `enkeywords` varchar(80) NOT NULL,
  `cndescription` varchar(200) NOT NULL,
  `endescription` varchar(200) NOT NULL,
  PRIMARY KEY  (`cid`),
  KEY `ispass` (`ispass`,`order`),
  KEY `categoryid` (`categoryid`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8");
E_D("replace into `well_categroy` values('1','分类一','Well done','faFDSAFDSA','fdsaFSDFDSA','1','3','0','upload/class_img/1220714547786307741.gif','1','','','','');");
E_D("replace into `well_categroy` values('2','二级分类','Two categroy','fdsafd','safdsafdsa','1','1','1','upload/class_img/1220714547786307741.gif','1','','','','');");
E_D("replace into `well_categroy` values('5','分类二','FDSAFDSA','fdsafdsDSAF','afdsafdsa','1','2','0','upload/class_img/1220714547786307741.gif','1','','','','');");
E_D("replace into `well_categroy` values('3','分类三','class three','','','1','3','0','upload/class_img/1220714547786307741.gif','1','','','','');");
E_D("replace into `well_categroy` values('4','分类4','class four','','','1','4','0','upload/class_img/1220714547786307741.gif','1','','','','');");
E_D("replace into `well_categroy` values('6','fdsasfd','fdsaf','dsafdsafdsa','fdsafdsafdsa','1','3','5','upload/class_img/1220714547786307741.gif','1','','','','');");
E_D("replace into `well_categroy` values('7','test','test','test','test','1','1','3','upload/class_img/1220714547786307741.gif','1','','','','');");
E_D("replace into `well_categroy` values('8','test2','test2','test','test','1','1','3','upload/class_img/1220714547786307741.gif','1','','','','');");
E_D("replace into `well_categroy` values('9','test3','test3','test','test','1','1','3','upload/class_img/1220714547786307741.gif','1','','','','');");
E_D("replace into `well_categroy` values('10','test4','test4','test','test','1','1','3','upload/class_img/1220714547786307741.gif','1','','','','');");

@include("../../inc/footer.php");
?>