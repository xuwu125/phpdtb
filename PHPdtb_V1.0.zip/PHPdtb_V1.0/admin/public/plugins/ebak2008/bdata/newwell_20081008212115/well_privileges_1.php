<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_privileges`;");
E_C("CREATE TABLE `well_privileges` (
  `comid` tinyint(4) NOT NULL auto_increment,
  `parent_index` varchar(30) NOT NULL COMMENT '权限名称',
  `node_index` varchar(30) NOT NULL COMMENT '上级权限',
  `name` varchar(255) NOT NULL COMMENT '名称',
  PRIMARY KEY  (`comid`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8");
E_D("replace into `well_privileges` values('1','add_goods','','');");
E_D("replace into `well_privileges` values('2','add_goods','list','');");
E_D("replace into `well_privileges` values('3','nav','','');");
E_D("replace into `well_privileges` values('4','nav','list','');");
E_D("replace into `well_privileges` values('5','nav','add','');");
E_D("replace into `well_privileges` values('6','template','','');");
E_D("replace into `well_privileges` values('7','template','list','');");
E_D("replace into `well_privileges` values('8','goods_manage','','');");
E_D("replace into `well_privileges` values('9','goods_manage','list','');");
E_D("replace into `well_privileges` values('10','edit_goods','','');");
E_D("replace into `well_privileges` values('11','edit_goods','list','');");
E_D("replace into `well_privileges` values('12','del_goods','','');");
E_D("replace into `well_privileges` values('13','del_goods','list','');");
E_D("replace into `well_privileges` values('14','user_manage','','');");
E_D("replace into `well_privileges` values('15','user_manage','list','');");
E_D("replace into `well_privileges` values('16','user_manage','edit','');");
E_D("replace into `well_privileges` values('17','cp','','');");
E_D("replace into `well_privileges` values('18','cp','list','');");
E_D("replace into `well_privileges` values('19','wellcome','','');");
E_D("replace into `well_privileges` values('20','wellcome','list','');");
E_D("replace into `well_privileges` values('21','adminuser_manage','','');");
E_D("replace into `well_privileges` values('22','adminuser_manage','list','');");
E_D("replace into `well_privileges` values('23','setting','','');");
E_D("replace into `well_privileges` values('24','setting','list','');");
E_D("replace into `well_privileges` values('25','price_manage','','');");
E_D("replace into `well_privileges` values('26','price_manage','list','');");
E_D("replace into `well_privileges` values('27','mate_manage','','');");
E_D("replace into `well_privileges` values('28','mate_manage','list','');");
E_D("replace into `well_privileges` values('29','color_manage','','');");
E_D("replace into `well_privileges` values('30','color_manage','list','');");
E_D("replace into `well_privileges` values('31','categroy_manage','','');");
E_D("replace into `well_privileges` values('32','categroy_manage','list','');");
E_D("replace into `well_privileges` values('33','categroy_manage','edit','');");
E_D("replace into `well_privileges` values('34','categroy_manage','add','');");
E_D("replace into `well_privileges` values('35','color_manage','add','');");
E_D("replace into `well_privileges` values('36','color_manage','edit','');");
E_D("replace into `well_privileges` values('37','adminuser_manage','edit','');");
E_D("replace into `well_privileges` values('38','logs_manage','','');");
E_D("replace into `well_privileges` values('39','logs_manage','list','');");
E_D("replace into `well_privileges` values('40','logs_manage','view','');");
E_D("replace into `well_privileges` values('41','nav','edit','');");
E_D("replace into `well_privileges` values('43','nav','eidtsave','');");
E_D("replace into `well_privileges` values('44','phpinfo','','');");
E_D("replace into `well_privileges` values('45','phpinfo','list','');");
E_D("replace into `well_privileges` values('46','adminuser_manage','add','');");

@include("../../inc/footer.php");
?>