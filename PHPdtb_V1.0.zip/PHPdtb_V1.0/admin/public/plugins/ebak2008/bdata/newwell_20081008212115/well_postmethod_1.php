<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_postmethod`;");
E_C("CREATE TABLE `well_postmethod` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cnname` varchar(100) NOT NULL,
  `enname` varchar(100) NOT NULL,
  `endes` text NOT NULL,
  `cndes` text NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `ispass` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8");
E_D("replace into `well_postmethod` values('1','邮局平邮','China e','China e','邮局平邮','5','1');");
E_D("replace into `well_postmethod` values('2','EMS','EMS','EMS websiete:http://www.ems.com.cn/english-main.jsp','EMS 网站:http://www.ems.com.cn/','3','1');");
E_D("replace into `well_postmethod` values('3','UPS','UPS','UPS website:http://www.ups.com','UPS 中国网址：http://www.ups.com/content/cn/zh/index.jsx','1','1');");
E_D("replace into `well_postmethod` values('4','DHL','DHL','DHL','DHL','2','1');");
E_D("replace into `well_postmethod` values('5','Fedex','Fedex','Fedex website：http://fedex.com','Fedex 网址：http://fedex.com/cn/','4','1');");
E_D("replace into `well_postmethod` values('6','圆通快递','Yuantong ','Yuantong ','圆通快递','6','1');");
E_D("replace into `well_postmethod` values('7','顺风快递','Shunfeng','Shunfeng','顺风快递','7','1');");
E_D("replace into `well_postmethod` values('8','申通快递','Shengtong','Shengtong','申通快递','8','1');");
E_D("replace into `well_postmethod` values('9','中通速递','Zhongtong','Zhongtong','中通速递','9','1');");
E_D("replace into `well_postmethod` values('10','运费到付','FPD','FPD','运费到付','10','1');");
E_D("replace into `well_postmethod` values('11','上门取货 ','Cac','Cac','上门取货 ','11','0');");

@include("../../inc/footer.php");
?>