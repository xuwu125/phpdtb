<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2008
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `well_setting`;");
E_C("CREATE TABLE `well_setting` (
  `setid` tinyint(3) unsigned NOT NULL auto_increment,
  `isoff` tinyint(3) unsigned NOT NULL default '0' COMMENT '网站开关',
  `isoff_des` text NOT NULL COMMENT '关闭站点的原因',
  `enname` varchar(255) NOT NULL,
  `endes` varchar(255) NOT NULL,
  `enkeyword` varchar(255) NOT NULL,
  `enheader` text NOT NULL,
  `enfooter` text NOT NULL,
  `cnname` varchar(255) NOT NULL,
  `cndes` varchar(255) NOT NULL,
  `cnkeyword` varchar(255) NOT NULL,
  `cnheader` text NOT NULL,
  `cnfooter` text NOT NULL,
  `code_type` tinyint(1) unsigned NOT NULL default '8',
  `edit_width` varchar(50) NOT NULL,
  `edit_height` varchar(50) NOT NULL,
  `edit_skin` varchar(50) NOT NULL,
  `edit_toolbar` varchar(50) NOT NULL,
  `sessionmaxtime` int(10) unsigned NOT NULL,
  `ip_no_access` varchar(255) NOT NULL,
  `plugins_onoff` tinyint(1) unsigned NOT NULL default '1' COMMENT '是否启用插件',
  `status_script` text NOT NULL,
  `template` varchar(20) NOT NULL default 'default',
  `language` varchar(20) NOT NULL default 'zh-cn',
  `tpl_cache` tinyint(1) NOT NULL default '0',
  `tpl_cachetime` int(11) NOT NULL default '0',
  `cache_data_dir` varchar(100) NOT NULL default 'Tmp/caches/',
  `session_cookie_path` varchar(100) NOT NULL default '/',
  `session_cookie_domain` varchar(100) NOT NULL,
  `max_cache_time` int(11) NOT NULL default '300',
  `sql_logs_dir` varchar(200) NOT NULL default 'Tmp/logs',
  `rewrite_mod` tinyint(1) unsigned NOT NULL default '0',
  `goods_bigimg` varchar(255) NOT NULL,
  `goods_smallimg` varchar(255) NOT NULL,
  `class_img` varchar(255) NOT NULL,
  `status_off` tinyint(1) unsigned NOT NULL default '0',
  `status_small` tinyint(1) unsigned NOT NULL default '0',
  `goods_pagesize` int(10) unsigned NOT NULL default '12',
  PRIMARY KEY  (`setid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8");
E_D("replace into `well_setting` values('1','1','网站升级中','Well done','Well done','Well done','<!--Well done header-->','<!--Well done footer-->','中文网站','中文网站','中文网站','<!--中文网站 header-->','<!--中文网站 footer-->','8','100%','500px','default','Default','7200000','192.168.1.1\r\n192.168.18.*','1','<div title=''Start script'' style=''display:none''><script></script></div>','default','zh-cn','0','1800','Tmp/caches/','/','','10','Tmp/logs/','1','upload/goods/big','upload/goods/small','upload/class_img','0','0','12');");

@include("../../inc/footer.php");
?>