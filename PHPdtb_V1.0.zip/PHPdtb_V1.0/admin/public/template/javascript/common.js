/**
* jQuery Api document
* @author xuwu125<xuwu125@gmail.com>
*/
// 定义变量
var formname="";
var userAgent = navigator.userAgent.toLowerCase();

var now = /..:..:../.exec(Date())[0]; //最简单的获取当前时间(js)兼容firefox

// 函数开始
function Winobj(){
	var Winobjs = {
		"clientWidth": document.body.clientWidth,/*网页可见区域宽*/
		"clientHeight": document.body.clientHeight,/*网页可见区域高*/
		"offsetWidth": document.body.offsetWidth,/*网页可见区域宽(包括边线的宽)*/
		"offsetHeight": document.body.offsetHeight,/*网页可见区域高(包括边线的高)*/
		"scrollWidth": document.body.scrollWidth,/*网页正文全文宽*/
		"scrollHeight": document.body.scrollHeight,/*网页正文全文高*/
		"scrollTop": document.body.scrollTop,/*网页被卷去的高*/
		"scrollLeft": document.body.scrollLeft,/*网页被卷去的左*/
		"screenTop": window.screenTop,/*网页正文部分上*/
		"screenLeft": window.screenLeft,/*网页正文部分左*/
		"screen_height": window.screen.height,/*屏幕分辨率的高*/
		"screen_width": window.screen.width,/*屏幕分辨率的宽*/
		"availHeight": window.screen.availHeight,/*网页被卷去的左*/
		"availWidth": window.screen.availWidth /*网页被卷去的左*/
	};
	return Winobjs;
}
String.prototype.trim = function()
{
return this.replace(/(^\s*)|(\s*$)/g, "");
}
function replaceAll(str,need,rep){
	while(str.indexOf(need)!=-1){
	str.replace(need,rep);
	}
	return str;
}
function isUndefined(variable) {
	return typeof variable == 'undefined' ? true : false;
}
function win_status(w){window.status=w;return true;}
function $$(id){return document.getElementById(id);}
function strleft(str,len){
	if(str.length>=len){
		return str.substring(0,len);
	}else{
		return str;
	}
}
// 随机取色函数
function foo() {
  var rndColor = '#';
  var hexValues = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'];
  for (var i=0; i<6; i++) {
    rndColor += ''+hexValues[parseInt(Math.random()*hexValues.length)];
  }
	return rndColor;
}

function StripTags(str) { 
    return str.replace(/<\/?[^>]+>/gi, ''); 
  } 
  /// 脚本永不出错代码
function killErrors() 
{ //window.onerror = killErrors; 
return true; 
}
function admin_login(){
	$("#loginform").submit(function(){
		$("#errorshow").hide();
		if($("#user_name").val()==""){
				$("#errorshow").html("用户名不可为空！").css({"color":"red"}).show("slow");
				$("#user_name").focus();
				return false;
		}
		if($("#user_pwd").val()==""){
				$("#errorshow").html("密码不可为空！").css({"color":"red"}).show("slow");
				$("#user_pwd").focus();
				return false;
		}
		if($("#user_code").val()==""){
				$("#errorshow").html("验证码不可为空！").css({"color":"red"}).show("slow");
				$("#user_code").focus();
				return false;
		}
	});
	
}

function admin_cp(){
	var rel=0;
	var Winobjs=new Winobj();
	//$.each(Winobjs,function(i,n){alert(i+"="+n);});
	loadstats(0);
		if($.browser.msie){
			$("#mainbox").height(parseInt(Winobjs.availHeight-174));//174
		}else{
			$("#mainbox").height(Winobjs.availHeight-110);//180
		}
		$("#mainlefter").height(($("#mainbox").height()-63));
		$("#mainrighter").height(($("#mainbox").height()-63));
		if($.browser.msie){
		$("#mainrighter").width(($("#mainbox").width()-183));//183 //168
		}else{
		$("#mainrighter").width(($("#mainbox").width()-182));
		}
	window.onload=function(){
		$("#main_loading").html("开始初始化后台界面...");
		$("#main_loading").hide("slow");
		$("#mainbox").show("slow");
		loadstats(1);
	}
	
	$(".menu").each(function(){
			if (rel > 0) {
				$(this).find("dl").hide("fast");
			}
			$(this).find("a").each(function(){
				$(this).attr("rel","cpnav_"+rel);
				rel++;
			});
			$("#mainlefter").find("a").each(function(){
				$(this).click(function(){
				var objectx=$(this).attr("rel");
				var target=$(this).attr("target");
				if(target!=''){
					return true;
				}
				var nav=0;
				$("#navlist").find("a").each(function(){
					nav++;
				});
				if(nav>10){
					mesbox("1.程序自动提醒你，你可能打开的窗口过多了!<br />2.目前只支持11个窗口，所以你打的窗口不能超过11个。<br />3.你可以先关掉一此不用的窗口。");return false;
				}close_allifame();
				if (!$$("nav_"+objectx)) {
					$("#navlist").append("<li id='nav_" + objectx + "'><a href='javascript:;' title=' Title:"+$(this).text()+"\n Url:"+ $(this).attr("href") + "' onclick=\"return select_nav('"+objectx+"');\"><span>"+ strleft($(this).text(),4) + "</span></a><cite title='关闭'></cite></li>");
					var iframe = '<iframe name="iframe_' + objectx + '" id="iframe_' + objectx + '" src="' + $(this).attr("href") + '" width="100%" height="100%" frameborder="0" allowtransparency="true" onload="return iframe_load(\'' + objectx + '\');" ></iframe>';
					$("#mainrighter").append("<div id='com_" + objectx + "'>"+iframe+"</div>");
					$("iframe_" + objectx).height($("#mainrighter").height());
					loadstats(0);
					$('#nav_' + objectx).attr("skip","yes");
					$('#nav_' + objectx).find("cite").click(function(){
						var o=$(this).parent().attr("id").replace("nav_","");
						var prev=$(this).parent().prev().attr("id").replace("nav_","");
						if($(this).parent().attr("skip")=="yes"){mesbox("该窗口暂时不充许关闭!");return false;}
						$('#nav_' + o).remove();
						$('#com_' + o).remove();
						select_nav(prev);
					});
					
					select_nav(objectx);
					return false;
				}else{
					select_nav(objectx);
					return false;
				}
				
			});
			});
			
		});
	$(".menu").each(function(){
		$(this).find("span").click(function(){
			$(this).parent().parent().find("dl").slideUp("slow");
			$(this).parent().find("dl").slideDown("slow");
		});
	});
	$("#alert_box").height($("#mainbox").height()).hide();//Winobjs.availHeight+"px"
	$("#alert_boxc").css({"margin-left":parseInt((Winobjs.screen_width+400)/4)+"px"});;
}
function close_allifame(){
	$("#mainrighter").find("div").each(function(){
		$(this).hide();
	});

	$("#navlist").find("a").each(function(){
		$(this).removeClass();
	});

}
function select_nav(objid){close_allifame();
	$("#nav_"+objid).find("a").addClass("selecter");
	$("#nav_"+objid).find("a").blur();
	$("#nav_"+objid).find("a").find("span").css({color:'#333333'});
	$("#com_"+objid).show();
	return false;
}
function loadstats(num){
	if(num!=1){
	$("#main_loadstats").html(main_loadstats_text);
	}else{
	$("#main_loadstats").html('空闲中...');
	}
}
function iframe_load(objid){
	$("#nav_"+objid).removeAttr("skip");
	loadstats(1);
};

function jsCopy(str,type)   
{   
  	clipboardData.setData('text',str);
  	if(type==1){
	alert("恭喜你，复制成功！\n内容如下：\n"+str);
	}
}

/// 自动选择菜单函数
function AutosetSel(idname,str){
var idx=document.getElementById(idname);
if(idx){
	for(var i=0;i<idx.options.length;i++){                
	if (idx.options[i].value==str){
	idx.selectedIndex=i;
	break;
	}
	}   
}
}

function set_checkbox(names,arrs){
	$("input[@name='"+names+"']").each(
		function(i){
			if($(this).attr("type")=="checkbox"){
				if(in_array($(this).val(),arrs)){
					$(this).attr('checked',true);
				}
			}
			
		}
	);
}

function in_array(needs,arr){
	var t=false;
	for(var i=0;i<arr.length;i++){
		if(arr[i]==needs){
			return true;
		}
	}
	return t;
}


function show_message(id){
	$(function(){
		var d=$("#"+id);
		if(d){
			$("#"+id+"_title").toggle(function(){
				$("#"+id+"_content").slideDown("slow");								 
			},function(){
				$("#"+id+"_content").slideUp("slow");								 
			});
			
			d.show("slow");
		}
	});
}
function chekemail(temail) {  
 var pattern = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;  
	 if(pattern.test(temail)) {  
	  return true;  
	 } 
}

function go_url(url){
	location.href=url;return false;
}
function dellink(){
	if(!confirm('你确定执行此操作吗？')){return false;}
	
}
function set_tables(id){
if(id&&id!=="undefined"){
	var tables="#"+id;
}else{
	var tables="";
}
$(tables+" tr").each(function(i){
	if(this.title!='skip'){
		this.style.backgroundColor=['#EEEEEE','#FFFFFF'][i%2];
		$(this).hover(function(){
			this.style.backgroundColor='#EEEEEE';
		},
		function(){
			this.style.backgroundColor='#FFFFFF';
		}); 
		}
	});
}

function admincp_loader(){
window.setTimeout("$('#main_loading').html('正在设定后台相关表格样式...');",200);	
window.setTimeout("$('#main_loading').html('正在设定后台按钮事件...');",300);
window.setTimeout("$('#main_loading').html('正在初始化鼠标事件效果...');",400);
window.setTimeout("$('#main_loading').html('后台相关数据加载完毕...');",500);
}

$(document).ready(function(){
	
	set_tables();
	
	$(".dellink").click(function(){
		if(!confirm('你确定执行此删除操作吗？')){return false;}
	});
	$("input").each(function(){
		var types=$(this).attr("type");
		if(types=="text"||types=="password"){
			$(this).hover(function(){
				$(this).css({"border":'1px solid #66CC00'});
			},
			function(){
				$(this).css({"border":'1px solid #666666'});
			});
		}
	});
	$("textarea").hover(function(){
				$(this).css({"border":'1px solid #66CC00'});
			},
			function(){
				$(this).css({"border":'1px solid #666666'});
			});
	$("input").each(function(){
		var types=$(this).attr("type");
		if(types=="text"||types=="password"){
			$(this).click(function(){
				$(this).css({"border":'1px solid #66CC00'});
				$(this).blur(function(){
					$(this).css({"border":'1px solid #666666'});
				});
			});
		}
	});
	$("textarea").click(function(){
				$(this).css({"border":'1px solid #66CC00'});
				$(this).blur(function(){
					$(this).css({"border":'1px solid #666666'});
				});
			});
	
    $(".autobt").toggle(function(){
         $(this).attr("checked",true);
        $(this).prev().val($(this).val());
        $(this).prev().attr("readonly",true);
    },function(){
        $(this).prev().val("");
        $(this).prev().attr("readonly",false);
        $(this).attr("checked",false);
    });
	
});


function checkboxall_form(fname,check){
	var f=$("#"+fname).find(".checkboxall").click(function(){
		$("#"+fname).find("."+check).attr("checked",$(this).attr("checked"));
		$("#"+fname).find(".checkboxall").attr("checked",$(this).attr("checked"));
	});
}