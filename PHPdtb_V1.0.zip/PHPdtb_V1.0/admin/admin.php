<?php
/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */

/**
 * 后台管理程序
 * 
 * @access administrators
 * @link www.p-so.com
 * @version V1.0 2008729
 * @author xuwu125
 * @package administrator CP
 */
$install_lockfile="../tools/install.lock";
if(!file_exists($install_lockfile)){
	header("Content-Type:text/html; charset=utf-8");
    die("对不起，请先运行安装程序。<a href='../install.php'>马上安装</a>\n<br />".
    "Sorry, you run the installer.<a href='../install.php'>Immediately installed</a>");
}
/**
 * 设置安全变量，表示必须从这里为入口
 *
 */
define('IN_SITE',true);
/**
 * 表示使用Smarty 模板技术
 *
 */
define('SET_Smarty',true);



include_once(dirname(__FILE__)."/include/init.php");
/*取得安装信息*/

if(empty($action)){
    $dtb->sysbox("错误提示","参数错误");
}elseif ($action=='login'){
    $gourl=$_GET['gourl'];
    $gourl=empty($_GET['gourl'])?"admin.php?act=cp":trim($_GET['gogurl']);
    $tpl->assign('gourl',$gourl);
    $outhtml=$tpl->fetch("admin_login.html",$gourl);
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
}elseif ($action=='actlogin'){
    $user_name=$_POST['user_name'];
    $user_pwd=$_POST['user_pwd'];
    $user_code=$_POST['user_code'];
    $serveruser_code=$_SESSION['user_code'];
    $gourl=$_POST['gourl'];
    $links=array('href'=>'admin.php?act=login','text'=>'返回重新登录');
    if(empty($user_code)||empty($user_pwd)||empty($user_name)){
        $dtb->sysbox("错误提示","对不起，请输入用户名和验证码后再进行提交登录！",$links);
    }
    if($serveruser_code!=$user_code){
        $dtb->sysbox("错误提示","对不起，验证码不正确！",$links);
    }
    $sql="SELECT * FROM ".$dtb->table("adminuser")." WHERE user_name='$user_name' AND user_pass='".MD5($user_pwd)."'";
    $login=$db->getRow($sql);
    if(empty($login)){
        $dtb->sysbox("错误提示","对不起，登录失败！",$links);
    }else{
        $links=array('href'=>'admin.php?act=cp','text'=>'进入后台管理');
        $_SESSION['admin_id']=$login['admin_id'];
        $_SESSION['user_name']=$login['user_name'];
        $_SESSION['user_comp']=$login['user_comp'];
        
        file_put_contents(ADMIN_PATH."public/data/database_yes.tmp","<?php\n return ".var_export($_SESSION,true)."\n?>");
        $upfarray=array('user_lastip'=>$ip,'user_lasttime'=>time(),'user_logincount'=>($login['user_logincount']+1));
        $updateok=$db->autoExecute($dtb->table("adminuser"),$upfarray,"UPDATE"," admin_id='".$login['admin_id']."'");
        $dtb->sysbox("成功提示","恭喜你，登录成功！",$links);
    }
}elseif ($action=='cp'){
    
    $outhtml=$tpl->fetch("admin_cp.html",$gourl);
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
}elseif ($action=='loginout'){    
    $dtb->login_out();
    $links=array('href'=>'admin.php?act=login','text'=>'返回重新登录');
    $dtb->sysbox("成功提示","恭喜你，你已经安全退出！",$links);
}elseif ($action=='wellcome'){
    $install_filecontent=file_get_contents($install_lockfile);
    $install_info=explode("\n",$install_filecontent);
    $temp=explode(" :",$install_info[0]);
    $install_info['installtime']=$temp[1];
    $setupallfile=new sundir();
    $install_info['fileditelsize']=$setupallfile->size_show(ROOT_PATH);
    
    $tpl->assign("install_info",$install_info);
    $tpl->assign('SER',$_SERVER);
    $outhtml=$tpl->fetch("wellcome.html",$gourl);
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
}elseif ($action=='phpinfo'){
    if(function_exists("phpinfo")){
        phpinfo();
    }else{
        die("对不起，该服务器不支持PHPINFO()函数。");
    }
}elseif ($action=='setting'){
   foreach ($siteconfig as $key=>$v){
       if($key!="setid"){
        $siteflist[$key]=$_POST[$key];
       }
   }
   if($save=="yes"){
       //print_r($siteflist);
       $dtb->autoupdate("setting",$siteflist," setid=1 ");
       
       $dtb->sysbox("成功提示","恭喜你，操作成功",$publinks);
   }
    $outhtml=$tpl->fetch("setting.html",$gourl);
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
}elseif($action=='nav'){
    $type=empty($_GET['type'])?"list":trim($_GET['type']);
    $sql="SELECT * FROM ".$dtb->table("nav")." LIMIT 0,1";
    $nav_fieldsarr=$db->getRow($sql);
    $nav_fields=$dtb->get_newarray($nav_fieldsarr,array('cid','system'),$_POST,'key');
    $nav_fieldskeyval=$dtb->get_newarray($nav_fieldsarr,array('cid'),$_POST,'keyval');
    //print_r($nav_fieldskeyval);
    $notnullfields=array("entitle","cntitle","nav_name","cn_url","en_url");
    $publinks=array(array('text'=>'菜单栏目管理','href'=>'admin.php?act=nav&type=list'),$publinks);
    if($type=='list'){
        $sql="SELECT * FROM ".$dtb->table("nav")." ORDER BY `order` ASC ";
        $list=$db->getAll($sql);
        if($savepost=='yes'){
            foreach ($list as $li){
                $orders=empty($_POST['order_'.$li['cid']])?0:intval($_POST['order_'.$li['cid']]);
                $sql="UPDATE ".$dtb->table('nav')." SET `order`='$orders' WHERE `cid`='".$li['cid']."'";
                $db->query($sql);
            }
            $dtb->sysbox("成功提示","恭喜你更新排序成功！",$publinks);
        }
        
        
        //print_r($list);
        $tpl->assign("list",$list);
        
    }elseif ($type=='edit'||$type=='add'){
        if($type=='edit'){
            $cid=trim($_GET['data']);
            if(empty($cid)){
                $dtb->sysbox("错误提示","对不起，参数错误！",$publinks);
            }
            $sql="SELECT * FROM ".$dtb->table("nav")." WHERE cid='$cid' ";
            $info=$db->getRow($sql);
            
            //print_r($info);
            
        }
        $info["cncontent"]=$dtb->create_html_editer("cncontent",$info["cncontent"]);
        $info["encontent"]=$dtb->create_html_editer("encontent",$info["encontent"]);
        $tpl->assign("data",$info);
    }elseif ($type=='eidtsave'){
        $cid=trim($_POST['cid']);
        if(empty($cid)||$_POST['save']!='yes'){
            $dtb->sysbox("错误提示","对不起，参数错误！",$publinks);
        }
        //print_r($nav_fieldskeyval);
        if(!$dtb->check_null($nav_fieldskeyval,$notnullfields)){
                $dtb->sysbox("错误提示","对不起，信息不完整！",$publinks);
        }
        foreach ($nav_fieldskeyval as $key=>$v){
              $nav_fieldskeyval[$key]=str_replace("public/template/","",$nav_fieldskeyval[$key]);
         }
        $dtb->autoupdate("nav",$nav_fieldskeyval," cid='$cid' ");
        $dtb->sysbox("成功提示","恭喜你保存成功！",$publinks);
    }elseif ($type=='insert'){
        if($_POST['save']=='yes'){
            if(!$dtb->check_null($nav_fieldskeyval,$notnullfields)){
                $dtb->sysbox("错误提示","对不起，信息不完整！",$publinks);
        }
            $dtb->inser_into($nav_fields,'nav');
            $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks);
        }else{
            $dtb->sysbox("错误提示","对不起，参数错误！",$publinks);
        }
    }elseif ($type=='del'){
        $cid=trim($_GET['data']);
        $sql="DELETE FROM ".$dtb->table("nav")." WHERE cid='$cid' and cid>1 AND system='0' ";
        $db->query($sql);
        $dtb->sysbox("成功提示","恭喜你，删除操作成功！",$publinks);
    }
    
    $outhtml=$tpl->fetch("nav.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
}elseif ($action=='add_goods'||$action=='edit_goods'){
    
    $publinks=array('text'=>"返回商品管理",'href'=>'admin.php?act=goods_manage');  
    $goodfileds=$dtb->getfiles("goods");
    $getcategroy_list=getcategroy_list();
    $tpl->assign('getcategroy_list',$getcategroy_list);;
    //print_r($getcategroy_list);
    $goodspost=array (
          'goods_cnanme' => !empty($_POST['goods_cnanme'])?trim($_POST['goods_cnanme']):'',
          'goods_enname' => !empty($_POST['goods_enname'])?trim($_POST['goods_enname']):'',
          'goods_sn' => !empty($_POST['goods_sn'])?trim($_POST['goods_sn']):'',
          'goods_number' => !empty($_POST['goods_number'])?intval($_POST['goods_number']):1,
          'goods_cate_id' => !empty($_POST['goods_cate_id'])?intval($_POST['goods_cate_id']):0,
          'ispass' => isset($_POST['ispass'])?intval($_POST['ispass']):0,
          'goods_encontent' => !empty($_POST['goods_encontent'])?trim($_POST['goods_encontent']):'',
          'goods_cncontent' => !empty($_POST['goods_cncontent'])?trim($_POST['goods_cncontent']):'',
          'goods_keywords' => !empty($_POST['goods_keywords'])?trim($_POST['goods_keywords']):'',
          'goods_des' => !empty($_POST['goods_des'])?trim($_POST['goods_des']):'',
          'goods_enkeywords' => !empty($_POST['goods_enkeywords'])?trim($_POST['goods_enkeywords']):'',
          'goods_endes' => !empty($_POST['goods_endes'])?trim($_POST['goods_endes']):'',
          'goods_price' => !empty($_POST['goods_price'])?floatval($_POST['goods_price']):"0.00",
          'goods_oldprice' => !empty($_POST['goods_oldprice'])?floatval($_POST['goods_oldprice']):"0.00",
          'is_hot' => isset($_POST['is_hot'])?intval($_POST['is_hot']):0,
          'mini_order' => !empty($_POST['mini_order'])?intval($_POST['mini_order']):1,
          'goods_length'=>$_POST['goods_length'],
          'goods_height'=>$_POST['goods_height'],
          'goods_weight'=>$_POST['goods_weight'],
          'goods_pack'=>$_POST['goods_pack'],
          'goods_enpack'=>$_POST['goods_enpack'],
          'goods_ennumber'=>!empty($_POST['goods_ennumber'])?intval($_POST['goods_ennumber']):1,
          'goods_enprice'=>!empty($_POST['goods_enprice'])?floatval($_POST['goods_enprice']):"0.00",
          'mini_enorder'=>!empty($_POST['mini_enorder'])?intval($_POST['mini_enorder']):1,
          
        );
    
    $prames=array('color','meta','price');
    foreach ($prames as $vxx){
        $temp=get_dball($vxx);
        $tpl->assign($vxx,$temp);
        $goodspost[$vxx]=empty($_POST[$vxx])?0:array_tostring($_POST[$vxx]);
        
    }
    $goodsfi=array('goods_cnanme','goods_sn','goods_number','goods_cate_id','goods_cncontent','goods_price');
   
    if($savepost=='yes'){
        if($goodspost['goods_number']<=0){
            $dtb->sysbox("错误提示3","对不起,商品库存不能为1.",$publinks);
        }
        if($goodspost['goods_price']<=0){
            $dtb->sysbox("错误提示4","对不起,商品价格不能为2.",$publinks);
        }
        if(!$dtb->check_empty($goodspost,$goodsfi)){
            $dtb->sysbox("错误提示2","对不起,商品信息不全(包括中文内容，分类，名称，货号).",$publinks);
        }
        $goodspost['bigimage']= upload_img('bigimagesupload',$siteconfig['goods_bigimg']);
        $goodspost['smallimage']=upload_img('smallimageupload',$siteconfig['goods_smallimg']);
        if(empty($goodspost['bigimage'])){unset($goodspost['bigimage']);}
        if(empty($goodspost['smallimage'])){unset($goodspost['smallimage']);}
        // 相关商品
        if(!empty($_POST['related_goods'])){
        $goodspost['related_goods']=implode(",",$_POST['related_goods']);
        }
        $goods_photo_list=upload_arrayimg('goods_photo');
    }
    
    if($action=='edit_goods'){
        // 老商品修改
        if($savepost=='yes'){
            $goods_id=!empty($_POST['goods_id'])?intval($_POST['goods_id']):0;
             if(!empty($goods_id)){
                $where=" goods_id='$goods_id'";
                $update=$db->autoExecute($dtb->table('goods'),$goodspost,'UPDATE',$where);
                if($update){
                    if(!empty($goods_photo_list)){
                    foreach ($goods_photo_list as $val){
                        add_goods_photo($goods_id,$val,$val);
                    }}
                    $dtb->sysbox("成功提示","恭喜你，编辑商品操作成功！",$publinks);
                }else{
                    $dtb->sysbox("错误提示","恭喜你，编辑商品操作失败！",$publinks);
                }
             }else{
                 $dtb->sysbox("错误提示","对不起,参数错误,无法修改此商品.",$publinks);
             }
            //var_export($_POST);
            die();
        }
        
        // 如果是修改商品
        $goods_id=empty($_GET['goods_id'])?0:intval($_GET['goods_id']);
        
        if(!empty($goods_id)){
        $sql="SELECT * FROM ".$dtb->table("goods")." WHERE goods_id='$goods_id'";
        $goodinfo=$db->getRow($sql);
            if(!empty($goodinfo)){
                if(!empty($goodinfo['related_goods'])){
                    $sql="SELECT goods_id,goods_cnanme,goods_enname,goods_sn,smallimage FROM ".$dtb->table("goods")." WHERE goods_id IN (".$goodinfo['related_goods'].")";
                    $goodinfo['related_goodslist']=$db->getAll($sql);
                }
                $goodinfo['photolist']=get_goods_photo($goods_id);
                $tpl->assign("goods",$goodinfo);
                $data['goods_encontent']=$dtb->create_html_editer("goods_encontent",$goodinfo["goods_encontent"]);
                $data['goods_cncontent']=$dtb->create_html_editer("goods_cncontent",$goodinfo["goods_cncontent"]);
                
            }else {
              $dtb->sysbox("错误提示","对不起,商品不存在,请返回重新选择商品.",$publinks);  
            }
        }else {
            $dtb->sysbox("错误提示","对不起,参数错误,请返回重新选择商品.",$publinks);
        }
        
    }
    
    //$goodsval=$dtb->get_newarray($goodspost,array('id'),$_POST,'val');
    if($action=='add_goods'){
        // 新商品添加
        $data['goods_encontent']=$dtb->create_html_editer("goods_encontent",'');
        $data['goods_cncontent']=$dtb->create_html_editer("goods_cncontent",'');
        $tpl->assign("goods",$goodspost);
        if($savepost=='yes'){
            if(empty($goodspost['smallimage'])){$goodspost['smallimage']=$goodspost['bigimage'];}
            $insert=$db->autoExecute($dtb->table('goods'),$goodspost);
            if($insert){
                
                if(!empty($goods_photo_list)){
                $goods_id=$db->getOne("SELECT MAX(goods_id) FROM ".$dtb->table("goods"));
                foreach ($goods_photo_list as $val){
                    add_goods_photo($goods_id,$val,$val);
                }}
                $dtb->sysbox("成功提示","恭喜你添加商品成功!",$publinks);
            }else{
                $dtb->sysbox("错误提示","对不起,添商品发生错误,请返回重新添加.",$publinks);
            }
        }
    }
    
    $tpl->assign('data',$data);
    $outhtml=$tpl->fetch("goodsinfo.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
}elseif ($action=='goods_manage'){
    $publinks=array('text'=>"返回商品管理",'href'=>'admin.php?act=goods_manage');  
    $categroy=intval($_GET['categroy']);
    $keywords=trim($_REQUEST['keywords']);
    $sql="SELECT * FROM ".$GLOBALS['dtb']->table("goods");
    if(!empty($categroy)){
        $sqlwhere=" WHERE goods_cate_id='$categroy'";
    }
    if(!empty($keywords)){
       if(!empty($categroy)){
            $sqlwhere.=" and (LOWER(goods_cnanme) LIKE LOWER('%$keywords%') OR LOWER(goods_enname) LIKE LOWER('%$keywords%')) ";
       }else {
            $sqlwhere=" WHERE LOWER(goods_cnanme) LIKE LOWER('%$keywords%') OR LOWER(goods_enname) LIKE LOWER('%$keywords%') "; 
       }
    }
    $pager['page']=intval($_GET['page']);
    $pager['pagesize']=20;
    $pager=get_page("goods",$sqlwhere,$pager);
    
    $sql=$sql.$sqlwhere." ORDER BY `goods_id` DESC LIMIT ".$pager['satrt']." , ".$pager['pagesize'];
    $list=$db->getAll($sql);
    //if($page['readcount']>$page['pagesize']){
    
            $page_arg=array('total'=>$pager['readcount'],
            'perpage'=>$pager['pagesize'],
            'page_name'=>'page',
            'url'=>$main_url);
            $pagex=new page($page_arg);
            $tpl->assign('page',$pagex->show());
    //} 
    $listmax=count($list);
    for ($i=0;$i<$listmax;$i++){
        $list[$i]['good_catename']=get_categroy($list[$i]['goods_cate_id'],'cnname');
    }
    $tpl->assign('pageinfo',$pager);
    $tpl->assign("list",$list);
    $outhtml=$tpl->fetch("goods_list.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
/*删除商品*/
}elseif ($action=='del_goods'){
    $goods_id=$_REQUEST['goods_id'];
    $publinks=array('text'=>"返回商品管理",'href'=>'admin.php?act=goods_manage&page='.$_GET['page']);  
    if(!empty($goods_id)){
        if(is_int($goods_id)){
            $del=del_goods_all($goods_id);
            if($del){ // 删除具体商品
                $dtb->sysbox("成功提示","恭喜你，删除商品成功！",$publinks);  
            }else{
                $dtb->sysbox("错误提示","对不起,商品不存在,或者删除发生错误！",$publinks);  
            }
        }
        if(is_array($goods_id)){
            foreach ($goods_id as $gid){
                del_goods_all($gid);
            }
            $dtb->sysbox("成功提示","恭喜你，集体删除操作完毕！(共删除".count($goods_id)."个商品)",$publinks); 
        }
    }
/*产品分类管理*/
}elseif ($action=='categroy_manage'){  
    $type=!empty($_GET['type'])?trim($_GET['type']):"list";
    $tpl->assign("type",$type);
    $publinks=array('text'=>"返回分类管理",'href'=>"?act=categroy_manage&type=list");
    $list=getcategroy_list(0);
    $tpl->assign('type',$type);
    if($type=='list'){
        $sql="SELECT cid FROM ".$dtb->table("categroy")." ORDER BY `order` ASC,`cid` DESC ";
        $flist=$db->getAll($sql);
        if($savepost=='yes'){
            foreach ($flist as $li){
                $orders=empty($_POST['order_'.$li['cid']])?0:intval($_POST['order_'.$li['cid']]);
                $sql="UPDATE ".$dtb->table('categroy')." SET `order`='$orders' WHERE `cid`='".$li['cid']."'";
                $db->query($sql);
            }
        }
        $tpl->assign('list',$list);
    }elseif ($type=='edit'){
        $datas=empty($_GET['data'])?"0":intval(trim($_GET['data']));
        if(empty($datas)){
            $dtb->sysbox("错误提示","对不起,参数错误,请返回重新选择分类.",$publinks);
        }
        /*保存操作     */
        if($savepost=='yes'){
            extract($_POST);
            $class_img_upload=upload_img("class_img_upload",$siteconfig['class_img']);
            $categoryid=empty($categoryid)?0:intval($categoryid);
            $ispass=!isset($ispass)?0:intval($ispass);
            $is_hot=!isset($is_hot)?0:intval($is_hot);
            $sqlkey=",cnkeywords='$cnkeywords',enkeywords='$cnkeywords',cndescription='$cnkeywords',endescription='$cnkeywords'";
            $sql="UPDATE ".$dtb->table("categroy")." SET cnname='$cnname',".
                " enname='$enname',cndes='$cndes',endes='$endes',categoryid='$categoryid',".
                " `order`='$order',ispass='$ispass',is_hot='$is_hot' $sqlkey WHERE cid='$datas'";
            if(!empty($class_img_upload)){
                $sql="UPDATE ".$dtb->table("categroy")." SET cnname='$cnname',".
                " enname='$enname',cndes='$cndes',endes='$endes',categoryid='$categoryid',".
                " `order`='$order',ispass='$ispass',is_hot='$is_hot',`class_img`='$class_img_upload' $sqlkey WHERE cid='$datas'";  
            }
            $modok=$db->query($sql);
            if($modok){
                $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks); 
            }else{
                $dtb->sysbox("错误提示","对不起，操作失败！");
            }
        }
        $data=get_categroy($datas);
        $tpl->assign('data',$data);
        $tpl->assign('datas',$datas);
        $tpl->assign('getcategroy_list',$list);
    }elseif ($type=='add'){upload_img("class_img_upload",$siteconfig['class_img']);
        /*保存操作     */
        
        if($savepost=='yes'){
            extract($_POST);
            $categoryid=empty($categoryid)?0:intval($categoryid);
            $class_img=upload_img("class_img_upload",$siteconfig['class_img']);
            $sqlkey=",cnkeywords='$cnkeywords',enkeywords='$cnkeywords',cndescription='$cnkeywords',endescription='$cnkeywords'";
            $sql="INSERT INTO  ".$dtb->table("categroy")." (cnname,enname,cndes,endes,categoryid,`order`,`ispass`,`class_img`,cnkeywords,enkeywords,cndescription,endescription) VALUES('$cnname',".
                " '$enname','$cndes','$endes','$categoryid', '$order','$ispass','$class_img','$cnkeywords','$enkeywords','$cndescription','$endescription') ";
            $modok=$db->query($sql);
            if($modok){
                $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks); 
            }else{
                $dtb->sysbox("错误提示","对不起，操作失败！");
            }
        }
        unset($data);
        $data['categoryid']=empty($_GET['data'])?"0":intval(trim($_GET['data']));
        $tpl->assign('data',$data);
        $tpl->assign('getcategroy_list',$list);
    }elseif ($type=='del'){
        $datas=empty($_GET['data'])?"0":intval(trim($_GET['data']));
        $good_count=$dtb->get_cate_googs_count($datas);
        $class_count=getcategroy_list($datas);
        if(!empty($good_count)||!empty($class_count)){
             $dtb->sysbox("错误提示","对不起,此分类不能删除，请先先移除里面商品和下级分类！",$publinks);
        }else {
             $sql="DELETE FROM ".$dtb->table("categroy")." WHERE cid='$datas'";
             $db->query($sql);
             $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks);
        }
    }
    
    $outhtml=$tpl->fetch("categroy.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);

}elseif ($action=='adminuser_manage'){
    $tablename="adminuser";
    $type=!empty($_GET['type'])?trim($_GET['type']):"list";
    $tpl->assign("type",$type);
    $publinks=array('text'=>"返回管理员管理",'href'=>"?act=$action&type=list");
    
    $tpl->assign('type',$type);
    if($type=='list'){
        $sql="SELECT * FROM ".$dtb->table($tablename)." ORDER BY `admin_id` ASC";
        $list=$db->getAll($sql);
        $tpl->assign('list',$list);
    }elseif ($type=='edit'){
        $datas=empty($_GET['data'])?"0":intval(trim($_GET['data']));
        if(empty($datas)){
            $dtb->sysbox("错误提示","对不起,参数错误,请返回重新选择颜色.",$publinks);
        }
        /*保存操作     */
        if($savepost=='yes'){
            
            $categoryid=empty($categoryid)?0:intval($categoryid);
            $sql="UPDATE ".$dtb->table($tablename)." SET ";
            if(!empty($_POST['user_name'])&&$_POST['user_name']!="admin"){
                $sql.="user_name='".$_POST['user_name']."',"; 
            }
            if(!empty($_POST['user_pass'])){
                $sql.=" user_pass='".md5($_POST['user_pass'])."',";
            }
            
            if($_POST['compall']==1){
                $usercomp="all";
            }else{
                $usercomplist=$_POST['privlist'];
                if(!empty($usercomplist)){
                    $usercomp=implode(",",$usercomplist);
                }else{
                    if($_POST['user_name']=="admin"){
                        $usercomp="all";
                    }
                }
            }
            $sql.="user_comp='".$usercomp."' WHERE admin_id='$datas'";
            $modok=$db->query($sql);
            if($modok){
                $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks); 
            }else{
                $dtb->sysbox("错误提示","对不起，操作失败！");
            }
        }
        $sql="SELECT * FROM ".$dtb->table($tablename)." WHERE admin_id='$datas'";
        $data=$db->getRow($sql);
        $tpl->assign('data',$data);
        $tpl->assign('datas',$datas);
    }elseif ($type=='add'){
        /*保存操作     */
        
        if($savepost=='yes'){
            extract($_POST);
            if(empty($_POST['user_name'])){
                $dtb->sysbox("错误提示","对不起，用户名不可为空！",$publinks);
            }
            if(empty($_POST['user_pass'])){
                $dtb->sysbox("错误提示","对不起，用户密码不可为空！",$publinks);
            }
            $user_pass=md5($user_pass);
            $sql="INSERT INTO  ".$dtb->table($tablename)." (user_name,user_pass,user_comp,user_lastip,`user_lasttime`,user_logincount) VALUES('".$_POST['user_name']."',".
                " '$user_pass','$user_comp','$ip', '".time()."','0') ";
            $modok=$db->query($sql);
            if($modok){
                $dtb->sysbox("成功提示","恭喜你，添加新用户操作成功！",$publinks); 
            }else{
                $dtb->sysbox("错误提示","对不起，添加新用户操作失败！",$publinks);
            }
        }
    }elseif ($type=='del'){
        $datas=empty($_GET['data'])?"0":intval(trim($_GET['data']));
         $sql="DELETE FROM ".$dtb->table($tablename)." WHERE admin_id='$datas' AND admin_id!='1'";
         $db->query($sql);
         $dtb->sysbox("成功提示","恭喜你，操作成功(但注意ID为1的admin为系统用户 不可删除)！",$publinks);
    }
    $tpl->assign('privlist',$privlist);
    $outhtml=$tpl->fetch("admin_user.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);    
}elseif ($action=='comp_manage'){
    $tablename="privileges";
    $type=!empty($_GET['type'])?trim($_GET['type']):"list";
    $tpl->assign("type",$type);
    $publinks=array('text'=>"返回权限管理",'href'=>"?act=$action&type=list");
    
    $tpl->assign('type',$type);
    
    if($type=='list'){
        if($savepost=='yes'){
           //print_r($privlist);
            
            $pvmax=count($privlist);
            foreach($privlist as $val){
                $tempid=$_POST['comid_'.$val['comid']];
                $name=$_POST['comid_'.$val['comid']];
                if(!empty($tempid)){
                 $sql="UPDATE ".$dtb->table($tablename)." SET `name`='$name' WHERE comid='".$val['comid']."'";
                 $db->query($sql);
                 if(!empty($val['twocom'])){
                     foreach($val['twocom'] as $val2){
                        $tempid2=$_POST['comid_'.$val2['comid']];
                        $name2=$_POST['comid_'.$val2['comid']];
                        if(!empty($tempid2)){
                            $sql="UPDATE ".$dtb->table($tablename)." SET  `name`='$name2' WHERE comid='".$val2['comid']."'";
                            $db->query($sql);
                        }
                     }
                 }
                 
                }
                 
            }
            $dtb->sysbox("成功提示","恭喜你，更新名称成功！",$publinks);
        }
       $tpl->assign('privlist',$privlist);
    }elseif ($type=='add'){
       
       if($savepost=='yes'){
       $parent_index=$_POST['parent_index'];
       $node_index=$_POST['node_index'];
       $name=$_POST['name'];
           if(!empty($parent_index)){
            $sql="INSERT INTO ".$dtb->table($tablename)." (parent_index,node_index,`name`) VALUES".
            " ('$parent_index','$node_index','$name',)";
            $db->query($sql);
            $dtb->sysbox("成功提示","恭喜你，添加权限操作成功！",$publinks);
           }
        }
    }elseif ($type=='del'){
        
    }
    
    
    $outhtml=$tpl->fetch("admin_usercomp.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace); 
/*颜色管理*/
}elseif ($action=='color_manage'){
    $tablename="color";
    $type=!empty($_GET['type'])?trim($_GET['type']):"list";
    $tpl->assign("type",$type);
    $publinks=array('text'=>"返回颜色管理",'href'=>"?act=$action&type=list");
    
    $tpl->assign('type',$type);
    if($type=='list'){
        $sql="SELECT * FROM ".$dtb->table($tablename)." ORDER BY `order` ASC,`id` DESC ";
        $list=$db->getAll($sql);
        if($savepost=='yes'){
            foreach ($list as $li){
                $orders=empty($_POST['order_'.$li['id']])?0:intval($_POST['order_'.$li['id']]);
                $sql="UPDATE ".$dtb->table($tablename)." SET `order`='$orders' WHERE `id`='".$li['id']."'";
                $db->query($sql);
            }$dtb->sysbox("成功提示","恭喜你更新排序成功！",$publinks);
        }
        $tpl->assign('list',$list);
    }elseif ($type=='edit'){
        $datas=empty($_GET['data'])?"0":intval(trim($_GET['data']));
        if(empty($datas)){
            $dtb->sysbox("错误提示","对不起,参数错误,请返回重新选择颜色.",$publinks);
        }
        /*保存操作     */
        if($savepost=='yes'){
            extract($_POST);
            $categoryid=empty($categoryid)?0:intval($categoryid);
            $sql="UPDATE ".$dtb->table($tablename)." SET cnname='$cnname',".
                " enname='$enname',cndes='$cndes',endes='$endes',".
                " `order`='$order',ispass='$ispass' WHERE id='$datas'";
            $modok=$db->query($sql);
            if($modok){
                $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks); 
            }else{
                $dtb->sysbox("错误提示","对不起，操作失败！");
            }
        }
        $data=get_dbinfo($tablename,$datas);
        $tpl->assign('data',$data);
        $tpl->assign('datas',$datas);
    }elseif ($type=='add'){
        /*保存操作     */
        
        if($savepost=='yes'){
            extract($_POST);
            $categoryid=empty($categoryid)?0:intval($categoryid);
            $sql="INSERT INTO  ".$dtb->table("color")." (cnname,enname,cndes,endes,`order`,ispass) VALUES('$cnname',".
                " '$enname','$cndes','$endes', '$order','$ispass') ";
            $modok=$db->query($sql);
            if($modok){
                $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks); 
            }else{
                $dtb->sysbox("错误提示","对不起，操作失败！");
            }
        }
    }elseif ($type=='del'){
        $datas=empty($_GET['data'])?"0":intval(trim($_GET['data']));
         $sql="DELETE FROM ".$dtb->table($tablename)." WHERE id='$datas'";
         $db->query($sql);
         $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks);
    }
    
    $outhtml=$tpl->fetch("color.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
/*材料管理*/
}elseif ($action=='mate_manage'){
    $tablename="meta";
    $type=!empty($_GET['type'])?trim($_GET['type']):"list";
    $tpl->assign("type",$type);
    $publinks=array('text'=>"返回材料管理",'href'=>"?act=$action&type=list");
    
    $tpl->assign('type',$type);
    if($type=='list'){
        $sql="SELECT * FROM ".$dtb->table($tablename)." ORDER BY `order` ASC,`id` DESC ";
        $list=$db->getAll($sql);
        if($savepost=='yes'){
            foreach ($list as $li){
                $orders=empty($_POST['order_'.$li['id']])?0:intval($_POST['order_'.$li['id']]);
                $sql="UPDATE ".$dtb->table($tablename)." SET `order`='$orders' WHERE `id`='".$li['id']."'";
                $db->query($sql);
            }$dtb->sysbox("成功提示","恭喜你更新排序成功！",$publinks);
        }
        $tpl->assign('list',$list);
    }elseif ($type=='edit'){
        $datas=empty($_GET['data'])?"0":intval(trim($_GET['data']));
        if(empty($datas)){
            $dtb->sysbox("错误提示","对不起,参数错误,请返回重新选择.",$publinks);
        }
        /*保存操作     */
        if($savepost=='yes'){
            extract($_POST);
            $categoryid=empty($categoryid)?0:intval($categoryid);
            $sql="UPDATE ".$dtb->table($tablename)." SET cnname='$cnname',".
                " enname='$enname',cndes='$cndes',endes='$endes',".
                " `order`='$order',ispass='$ispass' WHERE id='$datas'";
            $modok=$db->query($sql);
            if($modok){
                $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks); 
            }else{
                $dtb->sysbox("错误提示","对不起，操作失败！");
            }
        }
        $data=get_dbinfo($tablename,$datas);
        $tpl->assign('data',$data);
        $tpl->assign('datas',$datas);
    }elseif ($type=='add'){
        /*保存操作     */
        
        if($savepost=='yes'){
            extract($_POST);
            $order=empty($order)?0:intval($order);
            $sql="INSERT INTO  ".$dtb->table($tablename)." (cnname,enname,cndes,endes,`order`,ispass) VALUES('$cnname',".
                " '$enname','$cndes','$endes', '$order','$ispass') ";
            $modok=$db->query($sql);
            if($modok){
                $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks); 
            }else{
                $dtb->sysbox("错误提示","对不起，操作失败！");
            }
        }
    }elseif ($type=='del'){
        $datas=empty($_GET['data'])?"0":intval(trim($_GET['data']));
         $sql="DELETE FROM ".$dtb->table($tablename)." WHERE id='$datas'";
         $db->query($sql);
         $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks);
    }
    
    $outhtml=$tpl->fetch("meta.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
/*价格管理*/
}elseif ($action=='price_manage'){
    $tablename="price";
    $type=!empty($_GET['type'])?trim($_GET['type']):"list";
    $tpl->assign("type",$type);
    $publinks=array('text'=>"返回管理",'href'=>"?act=$action&type=list");
    
    $tpl->assign('type',$type);
    if($type=='list'){
        $sql="SELECT * FROM ".$dtb->table($tablename)." ORDER BY `order` ASC,`id` DESC ";
        $list=$db->getAll($sql);
        if($savepost=='yes'){
            foreach ($list as $li){
                $orders=empty($_POST['order_'.$li['id']])?0:intval($_POST['order_'.$li['id']]);
                $sql="UPDATE ".$dtb->table($tablename)." SET `order`='$orders' WHERE `id`='".$li['id']."'";
                $db->query($sql);
            }$dtb->sysbox("成功提示","恭喜你更新排序成功！",$publinks);
        }
        $tpl->assign('list',$list);
    }elseif ($type=='edit'){
        $datas=empty($_GET['data'])?"0":intval(trim($_GET['data']));
        if(empty($datas)){
            $dtb->sysbox("错误提示","对不起,参数错误,请返回重新选择.",$publinks);
        }
        /*保存操作     */
        if($savepost=='yes'){
            extract($_POST);
            $categoryid=empty($categoryid)?0:intval($categoryid);
            $sql="UPDATE ".$dtb->table($tablename)." SET cnname='$cnname',".
                " enname='$enname',cndes='$cndes',endes='$endes',".
                " `order`='$order',ispass='$ispass' WHERE id='$datas'";
            $modok=$db->query($sql);
            if($modok){
                $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks); 
            }else{
                $dtb->sysbox("错误提示","对不起，操作失败！");
            }
        }
        $data=get_dbinfo($tablename,$datas);
        $tpl->assign('data',$data);
        $tpl->assign('datas',$datas);
    }elseif ($type=='add'){
        /*保存操作     */
        
        if($savepost=='yes'){
            extract($_POST);
            $order=empty($order)?0:intval($order);
            $sql="INSERT INTO  ".$dtb->table($tablename)." (cnname,enname,cndes,endes,`order`,ispass) VALUES('$cnname',".
                " '$enname','$cndes','$endes', '$order','$ispass') ";
            $modok=$db->query($sql);
            if($modok){
                $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks); 
            }else{
                $dtb->sysbox("错误提示","对不起，操作失败！");
            }
        }
    }elseif ($type=='del'){
        $datas=empty($_GET['data'])?"0":intval(trim($_GET['data']));
         $sql="DELETE FROM ".$dtb->table($tablename)." WHERE id='$datas'";
         $db->query($sql);
         $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks);
    }
    
    $outhtml=$tpl->fetch("price.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
}elseif ($action=='order_manage'){
    $tablename="order";
    
    $order_id=!empty($_GET['order_id'])?0:intval(trim($_GET['order_id']));
    $tpl->assign("type",$type);
    $publinks=array('text'=>"返回订单管理",'href'=>"?act=$action&type=list");
    $type=!empty($_GET['type'])?trim($_GET['type']):"list";
    $tpl->assign('type',$type);
    if($type=='list'){
        $pager['page']=intval($_GET['page']);
        $pager['pagesize']=20;
        $pager=get_page($tablename,$sqlwhere,$pager);
            
        $sql="SELECT * FROM ".$dtb->table($tablename);
        $sql=$sql." ORDER BY `order_id` DESC LIMIT ".$pager['satrt']." , ".$pager['pagesize'];
        $list=$db->getAll($sql);
        
        if(!empty($list)){
        $listmax=count($list);
        $page_arg=array('total'=>$pager['readcount'],
            'perpage'=>$pager['pagesize'],
            'page_name'=>'page',
            'url'=>$main_url);
            $pagex=new page($page_arg);
            $tpl->assign('page',$pagex->show());
        for ($i=0;$i<$listmax;$i++){
            $list[$i]['pay_statustext']=$pay_status[$list[$i]['pay_stats']];
            $list[$i]['order_statustext']=$order_status[$list[$i]['order_stats']];
            $list[$i]['adddate']=date("Y-m-d H:i:s",$list[$i]['addtime']);
        }
        
        }
        //print_r($list);
        $tpl->assign('pageinfo',$pager);
        $tpl->assign("list",$list);
    }elseif ($type=='del'){
        $page=$_GET['page'];
        $order_sn=$_GET['data'];
        $sql="DELETE FROM ".$dtb->table("order_goods")." WHERE order_sn='$order_sn'";
        $delok=$db->query($sql);
        if($delok){
        $sql="DELETE FROM ".$dtb->table($tablename)." WHERE order_sn='$order_sn'";
        $delok=$db->query($sql);
        }
        if($delok){
            $dtb->sysbox("成功提示","恭喜你删除操作执行成功！",$publinks);
        }else{
            $dtb->sysbox("错误提示","对不起，删除订单出错！",$publinks);
        }
    }elseif ($type=='action') {
        $order_id=empty($_GET['data'])?0:$_GET['data'];
        if(empty($order_id)){
            $dtb->sysbox("错误提示","对不起，参数错误，请返回！",$publinks);
        }
        $order_info=get_order_info($order_id);
        if(empty($order_info)){
            $dtb->sysbox("错误提示","对不起，订单不存在，请返回！",$publinks);
        }else{
            $goods_info=get_order_goods($order_info['order_sn']);
            for ($i=0;$i<count($goods_info);$i++){
                $goods_info[$i]['goods_price']=format_price($goods_info[$i]['goods_price']);
                $goods_info[$i]['goods_enprice']=format_price($goods_info[$i]['enprice']);
                $goods_info[$i]['goods_info']=get_goods_info($goods_info[$i]['goods_id']);
            }
        }
        /*修改订单的状态*/
        if($savepost=='yes'){
            $orther_money=empty($_POST['orther_money'])?0:floatval($_POST['orther_money']);
            $order_status=empty($_POST['order_status'])?0:intval($_POST['order_status']);
            $pay_status=empty($_POST['pay_status'])?0:intval($_POST['pay_status']);
            $where=" order_stats='$order_status',pay_stats ='$pay_status',orther_money='$orther_money' ";
            $sql="UPDATE ".$dtb->table("order")." SET admin_user='$admin_user',$where WHERE order_id='$order_id'";
            $db->query($sql);
            
            $dtb->sysbox("成功提示","订单操作成功，请返回！",$publinks);
        }
        
        $order_info['pay']=get_dbinfo('paymethod',$order_info['pay_methods']);
        $order_info['post']=get_dbinfo('postmethod',$order_info['post_methods']);
        
        $tpl->assign('datas',$order_id);
        $tpl->assign('goodsinfo',$goods_info);
        $tpl->assign('data',$order_info);
        $tpl->assign('order_status',$order_status);
        $tpl->assign('pay_status',$pay_status);
    }
    $outhtml=$tpl->fetch("order.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
/*留言管理*/
}elseif ($action=='freeback_manage'){
    $tablename="freeback";
    $type=!empty($_GET['type'])?trim($_GET['type']):"list";
    $free_id=empty($_GET['data'])?0:intval(trim($_GET['data']));
    $tpl->assign("type",$type);
    $publinks=array('text'=>"返回留言管理",'href'=>"?act=$action&type=list");
    if($type=='list'){
        $page['page']=intval($_GET['page']);
        $page['pagesize']=20;
        $page=get_page($tablename,$sqlwhere,$page);
            
        $sql="SELECT * FROM ".$dtb->table($tablename);
        $sql=$sql." ORDER BY `id` DESC LIMIT ".$page['satrt']." , ".$page['pagesize'];
        $list=$db->getAll($sql);
        echo $main_url;
        if(!empty($list)){
        $page_arg=array('total'=>$page['readcount'],
            'perpage'=>$page['pagesize'],
            'page_name'=>'page',
            'url'=>$main_url);
            $pagex=new page($page_arg);
            $tpl->assign('page',$pagex->show());
        }
        $tpl->assign("list",$list);
        $tpl->assign('pageinfo',$page);
    }elseif ($type=='edit'){
        $sql="SELECT * FROM ".$dtb->table($tablename)." WHERE `id`='$free_id'";
        $data=$db->getRow($sql);
        if(empty($data)){
            $dtb->sysbox("错误提示","对不起，信息不存在！请返回。",$publinks);
        }
/*        回复留言保存*/
        if($savepost=='yes'){
            $recontent=$_POST['recontent'];
            $sql="UPDATE ".$dtb->table($tablename)." SET recontent='$recontent' WHERE `id`='$free_id'";
            $db->query($sql);
            $dtb->sysbox("成功提示","恭喜你，回复成功！请返回。",$publinks);
        }
        $tpl->assign("data",$data);
    }
    $tpl->assign("datas",$free_id);
    $outhtml=$tpl->fetch("freeback.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
/*SQL日志管理*/
}elseif ($action=='logs_manage'){
    $publinks=array('text'=>"返回日志管理",'href'=>"?act=$action&type=list");
    $fileurl=empty($_GET['data'])?"":$_GET['data'];
    if($type=='list'){
    $page['page']=empty($_GET['page'])?1:intval($_GET['page']);
    if($page['page']<=0){$page['page']=1;}
    $page['page_size']=15;
    $page['read_count']=read_dir_count(ROOT_PATH.$siteconfig['sql_logs_dir']."/");
    $page['page_count']=ceil($page['read_count']/$page['page_size']);
    if($page['page_count']*$page['page_size']<$page['read_count']){
        $page['page_count']++;
    }
    if($page['page']>$page['page_count']){$page['page']=1;}
    $start=($page['page']-1)*$page['page_size'];
    $endes=$start+$page['page_size'];
    if($endes>$page['read_count']){
        $endes=$page['read_count'];
    }
    $flist=read_dir(ROOT_PATH.$siteconfig['sql_logs_dir'],$start,$endes);
    
    if(!empty($flist)){
        $imax=count($flist);$i=0;
        foreach ($flist as $fileurls){
            $fileurls=$siteconfig['sql_logs_dir'].$fileurls;
            $list[$i]['id']=($start+$i)+1;
            $list[$i]['fileurl']=$fileurls;
            $list[$i]['adddate']=date("Y-m-d H:i:s",filemtime(ROOT_PATH.$fileurls));
            $list[$i]['fillsize']="0KB";
            $list[$i]['fillsize']=round(filesize(ROOT_PATH.$fileurls)/1024,2)."KB";
            $i++;
        }
    }
    $page['page_next']=$publinks['href']."&page=".($page['page']+1);
    $page['page_prev']=$publinks['href']."&page=".($page['page']-1);
    $tpl->assign('page',$page);
    $tpl->assign('list',$list);
    }elseif($type=='view'){
        if(empty($fileurl)||!file_exists(ROOT_PATH.$fileurl)){
            $dtb->sysbox("错误提示","对不起，日志文件不存在！",$publinks);
        }else{
            $data=file_get_contents(ROOT_PATH.$fileurl);
            $tpl->assign("data",$data);
            $tpl->assign('fileurl',$fileurl);
        }
    }elseif($type=='del'){
        if(empty($fileurl)||!file_exists(ROOT_PATH.$fileurl)){
            $dtb->sysbox("错误提示","对不起，日志文件不存在！",$publinks);
        }else{
            $unlink=unlink(ROOT_PATH.$fileurl);
            if(!$unlink){
                $dtb->sysbox("错误提示","对不起，删除日志文件[$fileurl]失败！",$publinks);
            }else{
                $dtb->sysbox("成功提示","恭喜你，删除日志文件[$fileurl]成功！",$publinks);
            }
        }
    }
    $outhtml=$tpl->fetch("logs.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);

/*语言包管理*/
}elseif ($action=='lang_manage'){
    $language=empty($_GET['data'])?$siteconfig['language'].".php":trim($_GET['data']);
    $languagefile=ROOT_PATH ."tools/language/".$language;
    $publinks=array('text'=>"返回语言包管理",'href'=>"?act=$action&type=list");
    /*加载语言包*/
    if(!file_exists($languagefile)){
        $languagefile=ROOT_PATH ."tools/language/".$siteconfig['language'].".php";
    }
    
    
    if($savepost=="yes"){
        $key=$_POST['key'];
        $value=$_POST['value'];
        $imax=count($key);
        for ($i=0;$i<$imax;$i++){
            if(!empty($key[$i])){
            $newlang[$key[$i]]=$value[$i];
            }
        }
        $oldfilecontent=file_get_contents($languagefile);
        $oldfileline=explode('return array',$oldfilecontent);
        $langfilecontent=var_export($newlang,true);
        $langfilecontent=$oldfileline[0]."\nreturn ".$langfilecontent."\n/**\n * autoupdate:".date("Y-m-d H:i:s",time())."\n * update user:software\n */\n?>";
        $update=@file_put_contents($languagefile,$langfilecontent);
        if($update){
            $dtb->sysbox("成功提示","恭喜你，更新语言包[$languagefile]成功！",$publinks);
        }else{
            $dtb->sysbox("错误提示","对不起，更新语言包[$languagefile]失败！",$publinks);
        }
    }
    $flist=read_dir(ROOT_PATH ."tools/language/");
    $imax=0;
    foreach ($flist as $l){
        if($l=="index.php"){
            unset($flist[$imax]);
        }$imax++;
    }
    $tpl->assign("flist",$flist);
    $tpl->assign("datas",$language);
    $tpl->assign("data",require($languagefile));
    $outhtml=$tpl->fetch("lang.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
/*插件管理*/
}elseif ($action=='plugins_manage'){
    $publinks=array('text'=>"返回插件管理",'href'=>"?act=$action&type=list");
    $pluginspath='tools/plugins/';
    $plugins_list=read_dir(ROOT_PATH.$pluginspath);
    $imax=0;
    foreach ($plugins_list as $f){
        if($f!='index.php'&&$f!='index.html'&&$f!='index.htm'){
        $plugins_flist[$imax]=array('fname'=>$f,'fsize'=>round(filesize(ROOT_PATH.$pluginspath.$f)/1024,2)."KB",'mtime'=>@filemtime(ROOT_PATH.$pluginspath.$f));
        $plugins_flist[$imax]['pubdate']=date("Y-m-d H:i:s",$plugins_flist[$imax]['mtime']);
        $imax++;}
    }
    if($savepost=='del'){
        $data=$_GET['data'];
        if(!empty($data)&&file_exists(ROOT_PATH.$data)){
            @unlink(ROOT_PATH.$pluginspath);
            $dtb->sysbox("成功提示","恭喜你，删除插件[$data]成功！",$publinks);
        }else{
            $dtb->sysbox("错误提示","对不起，删除插件[$data]成功！",$publinks);
        }
    }
    $tpl->assign('plugins_list',$plugins_flist);
    $outhtml=$tpl->fetch("plugins.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
    
}elseif ($action=='template_view'){
    $filecontent=empty($_REQUEST['filecontent'])?"对不起，请先输入模板内容！！！":$_REQUEST['filecontent'];
    die(stripslashes($filecontent));    
/*静态化文件管理*/
}elseif ($action=='htaccess_manage'){
    $publinks=array('text'=>"返回静态化管理",'href'=>"?act=$action&type=list");
    $file_path=".htaccess";
    $fcon=@file_get_contents(ROOT_PATH.$file_path);
    $fconsize=round(filesize(ROOT_PATH.$file_path)/1024,2)."KB";
    // 重新写入文件。
    if($savepost=="yes"){
        $fnewcon=$_POST['filecontent'];
        if(empty($fnewcon)){
            $dtb->sysbox("错误提示","对不起，请输入内容。",$publinks);
        }else{
            $fnewcon=stripslashes($fnewcon);
            $write=@file_put_contents(ROOT_PATH.$file_path,$fnewcon);
            if($write){
                $dtb->sysbox("成功提示","恭喜你，更新文件[$file_path]成功。",$publinks);
            }else{
                $dtb->sysbox("错误提示","对不起，写入文件[$file_path]失败，请手工FTP更新文件[".ROOT_PATH.$file_path."]。",$publinks);
            }
        }
    }
    
    $tpl->assign('fconsize',$fconsize);
    $tpl->assign('fcon',$fcon);
    $tpl->assign('file_path',$file_path);
    $outhtml=$tpl->fetch("htaccess.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
/*汇率管理*/
}elseif ($action=='usa_manage'){
    $tpl->assign("usaimage_url",'http://ichart.finance.yahoo.com/1y?usdcny=x');
    $tpl->assign("cnyimage_url",'http://ichart.finance.yahoo.com/1y?cnyusd=x');
    $outhtml=$tpl->fetch("usa_manage.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
/*模版管理*/
}elseif ($action=='template'){
    $publinks=array('text'=>"返回模版管理",'href'=>"?act=$action&type=list");
    $templatepath='template/';
    $template_list=read_dir(ROOT_PATH.$templatepath);
    $template_listselect=empty($_GET['template_listselect'])?"default":$_GET['template_listselect'];
    $template_listselect_langlist=read_dir(ROOT_PATH.$templatepath.$template_listselect."/");
    $filei=0;
    foreach ($template_listselect_langlist as $val){
       if(!is_dir(ROOT_PATH.$templatepath.$template_listselect."/".$val)){
            unset($template_listselect_langlist[$filei]);
       }
       $filei++;
    }
   
    $selectlang=empty($_GET['selectlang'])?"zh-cn":$_GET['selectlang'];
    $selectfile=empty($_GET['selectfile'])?"index.html":$_GET['selectfile'];
    $tpl_filepath=ROOT_PATH.$templatepath.$template_listselect."/".$selectlang."/";
    $template_file_list=array_merge(glob($tpl_filepath."*.html"),glob($tpl_filepath."style/*.css"));
    $template_file_list=array_merge($template_file_list,glob($tpl_filepath."orther/*.*"));
    $template_file_list=array_merge($template_file_list,glob($tpl_filepath."javascript/*.js"));
    for ($i=0;$i<count($template_file_list);$i++){
        $template_file_list[$i]=str_replace($tpl_filepath,"",$template_file_list[$i]);
    }
    if(in_array($selectfile,$template_file_list)){
        $template_selectfile=$tpl_filepath.$selectfile;
    }else{
        $selectfile="index.html";
        $template_selectfile=$tpl_filepath.$selectfile;
    }
        
        if($savepost=="yes"){
            $template_selectfile=$_POST['template_selectfile'];
            $filecontent=empty($_POST['filecontent'])?"":$_POST['filecontent'];
            $filecontent=stripslashes($filecontent);
            if(empty($filecontent)){
                $dtb->sysbox("错误提示","对不起，更新文件[$template_selectfile]失败。<br />原因如下：无内容!",$publinks);
            }
            $filecontent=textbox_code($filecontent,1);
            if(!empty($template_selectfile)&&file_exists($template_selectfile)){
                $update=@file_put_contents($template_selectfile,$filecontent);
                if($update){
                $dtb->sysbox("成功提示","恭喜你，更新文件[$template_selectfile]成功。",$publinks);
                }else{
                   $dtb->sysbox("错误提示","对不起，更新文件[$template_selectfile]失败。<br />原因如下：写入文件失败!",$publinks); 
                }
            }else{
                $dtb->sysbox("错误提示","对不起，更新文件[$template_selectfile]失败。<br />原因如下：文件不存在，或者路径错误!",$publinks);
            }
        }
       
        $file_path=$template_selectfile;
        $fcon=@file_get_contents($template_selectfile);
        $fconsize=round(@filesize($template_selectfile)/1024,2)."KB";
        $fcon=textbox_code($fcon);
        
    $fcon_replace=textbox_code($fcon,2);
    $tpl->assign('fconsize',$fconsize);
    $tpl->assign('fcon',$fcon);
    $tpl->assign('fcon_replace',$fcon_replace);
    $tpl->assign('file_path',$selectfile);
    $tpl->assign('template_selectfile',$template_selectfile);   
    $tpl->assign('template_listselect',$template_listselect);
    $tpl->assign('selectlang',$selectlang);
    $tpl->assign('template_list',$template_list);
    $tpl->assign('template_listselect_langlist',$template_listselect_langlist);
    $tpl->assign('file_list',$template_file_list);
    $tpl->assign('selectfile',$selectfile);
    $outhtml=$tpl->fetch("template.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
/*缓存管理*/
}elseif ($action=='cache_manage'){
    $publinks=array('text'=>"返回缓存管理",'href'=>"admin.php?act=$action&type=list");
    
    $cachearray=array('Tmp/cache','Tmp/caches','Tmp/compile','Tmp/logs','Tmp/orthers','Tmp/cookie_path');
    $data=$_GET['data'];
    if($type=='del'&&in_array($data,$cachearray)){
        if(!file_exists(ROOT_PATH.$data)){
            $dtb->sysbox("错误提示","对不起，目录[$data]不存在！",$publinks);
        }
        @rmdirR(ROOT_PATH.$data);
        automkdir(ROOT_PATH.$data);
        $dtb->sysbox("成功提示","恭喜你，清空缓存目录[$data]成功！",$publinks);
    }
    
    $fcache=new sundir();
    foreach ($cachearray as $flist){
        $total_size=0;
        $cachex[]=array('cachename'=>$flist,'cachesize'=>$fcache->size_show(ROOT_PATH.$flist));
    }
    
    $tpl->assign('cache',$cachex);
    $outhtml=$tpl->fetch("cache.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);

/*支付方式管理*/
}elseif ($action=='paymethod_manage'){
    $tablename="paymethod";
    $type=!empty($_GET['type'])?trim($_GET['type']):"list";
    $tpl->assign("type",$type);
    $publinks=array('text'=>"返回管理",'href'=>"?act=$action&type=list");
    if($savepost=='yes'&&$type!='list'&&$type!='del'){
        if(empty($_POST['filename'])||!file_exists(ROOT_PATH."tools/paymethod/".$_POST['filename'])){
            $dtb->sysbox("错误提示","对不起，支付方式文件不存在！",$publinks);
        }
    }
    $tpl->assign('type',$type);
    if($type=='list'){
        $sql="SELECT * FROM ".$dtb->table($tablename)." ORDER BY `order` ASC,`id` DESC ";
        $list=$db->getAll($sql);
        if($savepost=='yes'){
            foreach ($list as $li){
                $orders=empty($_POST['order_'.$li['id']])?0:intval($_POST['order_'.$li['id']]);
                $sql="UPDATE ".$dtb->table($tablename)." SET `order`='$orders' WHERE `id`='".$li['id']."'";
                $db->query($sql);
            }$dtb->sysbox("成功提示","恭喜你更新排序成功！",$publinks);
        }
        $tpl->assign('list',$list);
    }elseif ($type=='edit'){
        $datas=empty($_GET['data'])?"0":intval(trim($_GET['data']));
        if(empty($datas)){
            $dtb->sysbox("错误提示","对不起,参数错误,请返回重新选择.",$publinks);
        }
        /*保存操作     */
        if($savepost=='yes'){
            extract($_POST);
            
            $categoryid=empty($categoryid)?0:intval($categoryid);
            $sql="UPDATE ".$dtb->table($tablename)." SET cnname='$cnname',".
                " enname='$enname',cndes='$cndes',endes='$endes',".
                " `order`='$order',ispass='$ispass',enispass='$enispass',filename='$filename' ,class_name='$class_name',".
                " `payfees`='$payfees',`user_name`='$user_name',`user_pass`='$user_pass',".
                " `pay_key`='$pay_key',`pay_orther`='$pay_orther' WHERE id='$datas'";
            $modok=$db->query($sql);
            if($modok){
                $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks); 
            }else{
                $dtb->sysbox("错误提示","对不起，操作失败！");
            }
        }
        $data=get_dbinfo($tablename,$datas);
        $tpl->assign('data',$data);
        $tpl->assign('datas',$datas);
    }elseif ($type=='add'){
        /*保存操作     */
        
        if($savepost=='yes'){
            extract($_POST);
            $order=empty($order)?0:intval($order);
            $sql="INSERT INTO  ".$dtb->table($tablename).
            " (cnname,enname,cndes,endes,`order`,ispass,enispass,filename,class_name,payfees,user_name,user_pass,pay_key,pay_orther) VALUES('$cnname',".
                " '$enname','$cndes','$endes', '$order','$ispass','$enispass','$filename','$class_name','$payfees','$user_name','$user_pass','$pay_key','$pay_orther') ";
            $modok=$db->query($sql);
            if($modok){
                $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks); 
            }else{
                $dtb->sysbox("错误提示","对不起，操作失败！");
            }
        }
    }elseif ($type=='del'){
        $datas=empty($_GET['data'])?"0":intval(trim($_GET['data']));
         $sql="DELETE FROM ".$dtb->table($tablename)." WHERE id='$datas'";
         $db->query($sql);
         $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks);
    }
    
    $outhtml=$tpl->fetch("paymethod.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
/*配送方式管理*/
}elseif ($action=='postmethod_manage'){
    $tablename="postmethod";
    $type=!empty($_GET['type'])?trim($_GET['type']):"list";
    $tpl->assign("type",$type);
    $publinks=array('text'=>"返回管理",'href'=>"?act=$action&type=list");
    
    $tpl->assign('type',$type);
    if($type=='list'){
        $sql="SELECT * FROM ".$dtb->table($tablename)." ORDER BY `order` ASC,`id` DESC ";
        $list=$db->getAll($sql);
        if($savepost=='yes'){
            foreach ($list as $li){
                $orders=empty($_POST['order_'.$li['id']])?0:intval($_POST['order_'.$li['id']]);
                $sql="UPDATE ".$dtb->table($tablename)." SET `order`='$orders' WHERE `id`='".$li['id']."'";
                $db->query($sql);
            }$dtb->sysbox("成功提示","恭喜你更新排序成功！",$publinks);
        }
        $tpl->assign('list',$list);
    }elseif ($type=='edit'){
        $datas=empty($_GET['data'])?"0":intval(trim($_GET['data']));
        if(empty($datas)){
            $dtb->sysbox("错误提示","对不起,参数错误,请返回重新选择.",$publinks);
        }
        /*保存操作     */
        if($savepost=='yes'){
            extract($_POST);
            $categoryid=empty($categoryid)?0:intval($categoryid);
            $post_fees=floatval($_POST['post_fees']);
            $sql="UPDATE ".$dtb->table($tablename)." SET cnname='$cnname',".
                " enname='$enname',cndes='$cndes',endes='$endes',".
                " `order`='$order',ispass='$ispass',`enispass`='$enispass',`post_fees`='$post_fees' WHERE id='$datas'";
            $modok=$db->query($sql);
            if($modok){
                $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks); 
            }else{
                $dtb->sysbox("错误提示","对不起，操作失败！");
            }
        }
        $data=get_dbinfo($tablename,$datas);
        $tpl->assign('data',$data);
        $tpl->assign('datas',$datas);
    }elseif ($type=='add'){
        /*保存操作     */
        
        if($savepost=='yes'){
            extract($_POST);
            $order=empty($order)?0:intval($order);
            $sql="INSERT INTO  ".$dtb->table($tablename)." (cnname,enname,cndes,endes,`order`,ispass,post_fees,enispass) VALUES('$cnname',".
                " '$enname','$cndes','$endes', '$order','$ispass','$post_fees','$enispass') ";
            $modok=$db->query($sql);
            if($modok){
                $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks); 
            }else{
                $dtb->sysbox("错误提示","对不起，操作失败！");
            }
        }
    }elseif ($type=='del'){
        $datas=empty($_GET['data'])?"0":intval(trim($_GET['data']));
         $sql="DELETE FROM ".$dtb->table($tablename)." WHERE id='$datas'";
         $db->query($sql);
         $dtb->sysbox("成功提示","恭喜你，操作成功！",$publinks);
    }
    
    $outhtml=$tpl->fetch("postmethod.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
/*执行SQL语句*/
}elseif ($action=='execute_sql'){
    $sqldata=empty($_POST['sqldata'])?"":trim($_POST['sqldata']);
    if($savepost=='yes'&&!empty($sqldata)){
       $sqldata=stripslashes($sqldata);
       $sqlexecute=autoexecute_sql($sqldata);
       if(!empty($sqlexecute)){
       $tpl->assign("list",$sqlexecute); 
       }
    }
    
    $tpl->assign("sqldata",$sqldata);
    $outhtml=$tpl->fetch("execute_sql.html");
    $dtb->outhtml($outhtml,$admin_need,$admin_replace);
    
}elseif ($action=='user_manage'){    
    $publinks=array('text'=>"返回会员管理",'href'=>'admin.php?act='.$action);  
    $type=trim($_GET['type']);
    // 删除会员操作
    if($type=="del"){
        $deluser_id=intval($_GET['data']);
        if(!empty($deluser_id)){
            $sql="DELETE FROM ".$dtb->table("users")." WHERE user_id='$deluser_id'";
            $db->query($sql);
            $dtb->sysbox("成功提示","删除会员操作成功！",$publinks);
        }else{
            $dtb->sysbox("错误提示","删除会员操作失败，可能是参数不正确！",$publinks);   
        }
    // 编辑会员
    }elseif ($type=="edit"){
        $edituser_id=intval($_GET['data']);
        $sql="SELECT * FROM ".$dtb->table("users")." WHERE user_id='$edituser_id'";
        $userinfo=$db->getRow($sql);
        if(empty($userinfo)){
            $dtb->sysbox("错误提示","会员操作失败，可能是参数不正确！",$publinks);   
        }else{
            if($savepost=='yes'){
                if(empty($_POST['user_pass'])){
                    unset($_POST['user_pass']);
                }else{
                    $_POST['user_pass']=md5($_POST['user_pass']);$passwordischange="密码已经被修改！";
                }
                $modfyok=$db->autoExecute($dtb->table("users"),$_POST,"UPDATE"," user_id='$edituser_id'");
                if($modfyok){
                    $dtb->sysbox("成功提示","编辑会员操作成功！",$publinks);
                }else{
                    $dtb->sysbox("错误提示","编辑会员操作失败，可能是参数不正确！",$publinks);   
                }
            }
        $userlang=require("public/data/user_lang.php");
        $tpl->assign("userlang",$userlang);
        $tpl->assign("user_info",$userinfo);
        $outhtml=$tpl->fetch("user_info.html");
        $dtb->outhtml($outhtml,$admin_need,$admin_replace); 
        }
    // 会员列表加搜索
    }else{
        $keywords=trim($_REQUEST['keywords']);
        $sql="SELECT * FROM ".$GLOBALS['dtb']->table("users");
        if(!empty($keywords)){
            $sqlwhere=" WHERE LOWER(user_name) LIKE LOWER('%$keywords%') OR LOWER(user_address) LIKE LOWER('%$keywords%') "; 
        }
        $page['page']=intval($_GET['page']);
        $page['pagesize']=20;
        $page=get_page("users",$sqlwhere,$page);
        
        $sql=$sql.$sqlwhere." LIMIT ".$page['satrt']." , ".$page['pagesize'];
        $list=$db->getAll($sql);
            $page_arg=array('total'=>$page['readcount'],
            'perpage'=>$page['pagesize'],
            'page_name'=>'page',
            'url'=>$main_url);
            $pagex=new page($page_arg);
            $tpl->assign('page',$pagex->show());
        //print_r($page);
        $tpl->assign('pageinfo',$page);
        $tpl->assign("list",$list);
        $outhtml=$tpl->fetch("user_list.html");
        $dtb->outhtml($outhtml,$admin_need,$admin_replace); 
    }
}elseif ($action=='status_script'){
        $siteconfig['status_script']=str_replace(array("none",'NONE'),"",$siteconfig['status_script']);
        $tpl->assign("status_script",$siteconfig['status_script']);
        $outhtml=$tpl->fetch("status_script.html");
        $dtb->outhtml($outhtml,$admin_need,$admin_replace); 
/*  保留空位  */
}elseif($action=='sqls'){    

/*其它错误参数 */
}else {
    $reurl="http://".$_SERVER["SERVER_NAME"].$_SERVER['REQUEST_URI'];
    $dtb->sysbox("错误提示","<li>对不起，未定义的操作！</li>\n<li>你访问的地址[<a href=\"$reurl\" title='点击访问[$reurl]'>$reurl</a>]不存在</li>",$publinks);
}

?>