<?php
/** Copyright (c) 2008~2010 http://opensources.org.cn All rights reserved. 
 * ==========================================================================
 * Appname:     PHPdtb 开源网站系统
 * Verison:     1.0.0.1280
 * Update:      2008-12-11
 * Author:      xuwu(Changhe) <xuwu125@gmail.com> QQ:283573363
 * Website:     www.p-so.com opensources.org.cn
 * Description:	PHPdtb 开源网站系统是一个开源网站系统，本软件可以随意散发，修改，传播，
 * 				但在传播过程中，请注名是来自开源基地 p-so.com并且保证软件本身是完整未
 * 				被篡改过。本软件拒绝二次发布，细节请联系作者。 本软件下载地：
 * 				http://www.p-so.com/phpdtb/download
 * 				http://www.opensources.org.cn/phpdtb/download
 * 				PHPdtb open source web system is a system of open-source 
 * 				Web site, the software can distribute, modify, transmit,
 * 				However, in the dissemination process, please note who is 
 * 				from p-so.com revenue base and to ensure that software is 
 * 				not complete. Have been tampered with. The software refused
 * 				to release the second, details please contact the author. 
 * 				This software to download:
 * 				Http://www.p-so.com/phpdtb/download
 * 				Http://www.opensources.org.cn/phpdtb/download
 * Attention:	请在进行传播时不要删除以上信息，请尊重作者的作品。
 * 				Please do not delete when in the dissemination of this 
 * 				information, please respect the author's works.
 * ==========================================================================
 * */
/*
 *      ajax.php
 *      
 *      Copyright 2008 xuwu125 <xuwu125@gmail.com>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */

define('IN_SITE',true);
/**
 * ==flase 表示不使用Smarty 模板技术
 *
 */
define('SET_Smarty',false);
define('NOSET_AJAX',false);


include_once(dirname(__FILE__)."/include/init.php");

$action=empty($action)?"ajaxerror":trim($action);

if($action=="ajaxerror"){
	$result["error"]=1;
	$result["message"]="对不起，参数错误 ！";
	die($json->encode($result));

// Ajax search goods 
}elseif($action=="search_goods"){
	$keywords=$_GET["keywords"];
	if(empty($keywords)){
		$result["error"]=1;
		$result["message"]="对不起，请先输入关键字再进行搜索！";
		die($json->encode($result));
	}else{
		$limit=empty($_GET["limit"])?30:intval($_GET["limit"]);
		$keywords=str_replace(array(",",";","　","，")," ",$keywords);
		$keyarray=explode(" ",$keywords);
		foreach($keyarray as $keys){
			$wherearray[]=" ( `goods_cnanme` LIKE  '%$keywords%' OR `goods_enname` LIKE  '%$keywords%' OR `goods_sn` LIKE  '%$keywords%' ) ";
		}
		$where="( ".implode(" OR ",$wherearray)." ) ";
		$sql="SELECT goods_id,goods_cnanme,goods_enname,goods_sn,smallimage FROM ".$dtb->table("goods")." WHERE ispass='1' AND $where  ORDER BY 'goods_id' DESC LIMIT  0,$limit";
		$result["content"]=$db->getAll($sql);
		$result["count"]=count($result["content"]);
		die($json->encode($result));
	}
}elseif ($action='del_dbphoto'){
    $photo_id=empty($_GET['photo_id'])?0:intval($_GET['photo_id']);
    $result["error"]=1;
	$result["message"]="对不起，参数错误 ！";
	

    if(!empty($photo_id)){
        $delok=del_goods_photo($photo_id);
        if($delok){
           $result["error"]=0;
	       $result["message"]="恭喜你，删除相册图片成功 ！";
        }else{
           $result["error"]=1;
	       $result["message"]="对不起，删除相册图片失败 ！";
        }
        die($json->encode($result));
    }else{
        die($json->encode($result));
    }
}



?>
